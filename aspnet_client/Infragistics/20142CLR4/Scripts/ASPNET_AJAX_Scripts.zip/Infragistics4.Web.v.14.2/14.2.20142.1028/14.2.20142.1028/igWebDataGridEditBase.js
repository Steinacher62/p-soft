/*
* igWebDataGridEditBase.js
* Version 14.2.20142.1028
* Copyright(c) 2001-2014 Infragistics, Inc. All Rights Reserved.
*/


Type.registerNamespace("Infragistics.Web.UI");

$IG.GridEditBase = function (obj, objProps, control, parentCollection, editContainer)
{
	///<summary locid="T:J#Infragistics.Web.UI.GridEditBase">
	///Editing behavior object of the grid.
	///</summary>
	$IG.GridEditBase.initializeBase(this, [obj, objProps, control, parentCollection]);
	var grid = (typeof this._grid._get_mainGrid === 'function') ? this._grid._get_mainGrid() : this._grid;
	this._gridElement = grid._element;
	this._container = control._elements["container"];
	this._rows = this._owner.get_rows();
	this._editContainer = editContainer;
	if (!editContainer)
		this._editContainer = this._container;

	this._editCellCssClass = this._get_clientOnlyValue("ecc");
	
	this._cellInEditMode = null;
	this._currentEditor = null;
	this._isExitingEditMode = false;
	
	
	if (typeof ValidatorOnChange == 'function')
	{
		this._initValidators(this._gridElement);
	}
	this._horizontalScrollBar = control._elements["hScrBar"]; 
	this._verticalScrollBar = control._elements["vScrBar"]; 


	
	this._onChangingEPPoolLocationHandler = Function.createDelegate(this, this._forceExitEditMode);
	this._owner._gridUtil._registerEventListener(this._owner, "ChangingEPPoolLocation", this._onChangingEPPoolLocationHandler);
	
	this._owner._gridUtil._registerEventListener(this._owner, "RasingClientEventEnd", this._onChangingEPPoolLocationHandler);
	
	if (this._owner._thisType == "containerGrid")
		this._owner._gridUtil._registerEventListener(this._owner, "RowPopulating", this._onChangingEPPoolLocationHandler);
}

$IG.GridEditBase.prototype =
{
	
	get_editModeActions: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridEditBase.editModeActions">
		/// Returns/sets the actions that will cause the grid to enter edit mode.
		/// </summary>
		/// <value type="Infragistics.Web.UI.EditModeActions"></value>
		return this._editModeActions;
	},

	get_cellInEditMode: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridEditBase.cellInEditMode">
		/// Returns the cell that is currently in edit mode, if no cell is currently under
		/// edit, then null will be returned.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridCell" mayBeNull="true"></value>
		return this._cellInEditMode;
	},
	_now: function ()
	{
		return new Date().getTime();
	},

	


	

	enterEditMode: function (cell, key)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.GridEditBase.enterEditMode">
		/// Causes the grid to enter edit mode.
		/// </summary>
		/// <param name="cell" type="Infragistics.Web.UI.GridCell">The cell to enter edit mode.</param>
		/// <param name="key" type="String" optional="true">Optional.  Used internally to send pressed key to editor when entering
		/// via key press is used.</param>
		
		if (!this._canEdit(cell) || this._grid._re_obj)
			return;
		if (cell.get_column().get_isCheckbox() && !cell.__get_alwaysSetText())
			return;
		if (cell.get_row()._updated == $IG.RowUpdateStatus.AddedButDeleted || cell.get_row()._updated == $IG.RowUpdateStatus.Deleted)
			return;
		
		this._cellHeight = cell.get_element().offsetHeight;
		
		if (this._grid._delButtonOwner)
			this._grid._delButtonOwner.hideButton();
		

		setTimeout($util.createDelegate(this, this.__internalEnterEditMode, [cell, key]), 1);
	},
	_canEdit: function (cell)
	{
		var col = cell ? cell.get_column() : null;
		
		if (!col || this._cellInEditMode == cell || col.get_hidden() || col.get_isTemplated())
			return;
		
		col = this.get_columnSettings()._getObjectByAdr(col.get_key());
		if (col && col.get_readOnly())
			return;
		if (this._cellInEditMode)
			if (this.exitEditMode(true))
				return;
		
		if (!this._grid || this._grid._cellInEditMode)
			return;
		
		var child = cell._element;
		if (child.getAttribute("tmpl") == "1" || !child.offsetWidth)
			return;
		return true;
	},

	
	_forceExitEditMode: function ()
	{
		


		this.exitEditMode(true, true);
	},
	// force hiding eror message of validator
	_hideValidator: function (editor)
	{
		var validator = editor ? editor._validator : null;
		if (validator && validator.offsetHeight && validator.style && validator.style.visibility != 'hidden')
		{
			validator.isvalid = true;
			ValidatorUpdateDisplay(validator);
			return true;
		}
	},
	// trigger validation of editor
	_validate: function (editor, hide)
	{
		
		var elem = editor ? editor._element : null;
		var validator = elem ? editor._validator : null;
		
		if (!validator || !this.Validators || this.create_columnFilter)
			return;
		
		var input = editor.get_inputElement ? editor.get_inputElement() : elem, val = editor.get_value();
		
		editor._old_validator_id = editor._old_validator_id || validator.controltovalidate;
		
		var targetElem = this._grid._re_obj ? elem : this._gridElement;
		
		targetElem.value = (val == null) ? '' : '' + val;
		
		validator.controltovalidate = targetElem.id;
		
		ValidatorOnChange({ srcElement: this });
		if (!validator.isvalid)
		{
			targetElem.value = val;
			ValidatorOnChange({ srcElement: this });
		}
		delete editor._invalid;
		
		var invalid = !validator.isvalid;
		if (invalid && !hide)
		{
			
			editor._invalid = this._now();
			var oldScroll = this._grid.get_scrollLeft();
			
			if (input && input.focus) try
			{
				input.focus();
			} catch (e) { }
			

			if ($util.IsIE7 && this._grid.get_scrollLeft() != oldScroll)
				this._grid._gridUtil.scrollCellIntoViewIE(cell);
		}
		else
			this._hideValidator(editor);
		return invalid;
	},

	exitEditMode: function (update, force)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.GridEditBase.exitEditMode">
		/// Causes the grid to exit edit mode.
		/// </summary>
		/// <param name="update" type="Boolean">Request to update value.</param>
		/// <returns type="Boolean" mayBeNull="true">Returns true if exit edit mode was canceled.</returns>

		
		
		if (this._isExitingEditMode && this._now() - this._isExitingEditMode < 100)
		{
			return;
		}
		var cell = this._cellInEditMode, editor = this._currentEditor, grid = this._grid;
		var util = grid ? grid._gridUtil : null;
		
		var rowEditing = this._grid._re_obj;
		if (!cell || !editor || !editor.get_value || !util)
			return;
		if (!rowEditing && update && this._validate(editor, force))
		{
			if (!force)
				return true;
			update = false;
		}
		
		
		this._isExitingEditMode = this._now();
		var args = rowEditing ? null : this.__raiseClientEvent("ExitingEditMode", $IG.CancelEditModeEventArgs, [cell, editor.get_value()]);
		if (args && args.get_cancel() && !force)
		{
			
			
			this._isExitingEditMode = this._now();
			return true;
		}
		
		
		if (editor._originalNotifyLostFocus != null)
		{
			editor.notifyLostFocus = editor._originalNotifyLostFocus;
			editor._originalNotifyLostFocus = null;
		}
		if (this._stopEditHandler)
		{
			
			
			var i = this._scrollDIVs ? this._scrollDIVs.length : 0;
			while (i-- > 0)
				$removeHandler(this._scrollDIVs[i], 'scroll', this._stopEditHandler);
			delete this._scrollDIVs;
			
			util._unregisterEventListener(grid, "Resize", this._stopEditHandler);
			util._unregisterEventListener(grid, "MouseWheel", this._stopEditHandler);
			util._unregisterEventListener(grid, "ScrollLeftChange", this._stopEditHandler);
			util._unregisterEventListener(grid, "ScrollTopChange", this._stopEditHandler);
			
			this._addRemoveHGridHandlers(grid, util, false);
			util._unregisterEventListener(grid, "SelectStartContainer", this._onGridSelectStartHandler);
			delete this._stopEditHandler;
			delete this._onGridSelectStartHandler;
		}
		this._container.style.position = "";
		var valueChanged = false, val = null;
		if (update)
		{
			val = editor.get_value();
			var columnType = cell.get_column().get_type();
			
			var cellValue = (columnType != "number" ? cell.get_value() : cell._parseNumberValue());

			
			
			var parsedVal = cell.__parseValue(val);
			
			
			
			if (columnType == "string" && !parsedVal && !cellValue && cell.get_column().get_nullable())
				parsedVal = cellValue;
			if ((columnType != "date" && parsedVal != cellValue) || (columnType == "date" && !util._valuesAreEqual(parsedVal, cellValue)) || (columnType == "boolean" && cellValue === ""))
			{
				valueChanged = true;
				if (rowEditing)
					rowEditing._newCellVal = val;
				else
					cell.set_value(val, editor.get_text(val));
			}
		}
		if (editor._validator && editor._old_validator_id)
			editor._validator.controltovalidate = editor._old_validator_id;
		editor.hideEditor();
		
		
		var pool = editor._element.parentNode, cont = grid._poolHolder;
		var par = pool ? pool.parentNode : null;
		if (par && cont && par != cont && this._container.nodeName == 'TR')
		{
			par.removeChild(pool);
			cont.insertBefore(pool, cont.firstChild);
		}
		
		if (!rowEditing)
		{
			if (this._cellInEditMode.get_element().offsetHeight > this._cellHeight)
				this._grid._onResize({ "clientHeight": this._grid._element.clientHeight }, false);
			util._fireEvent(this, "ExitedEdit", { cell: cell, update: update, valueChanged: valueChanged, inputValue: val });
			this.__raiseClientEvent("ExitedEditMode", $IG.EditModeEventArgs, [cell, editor._editor ? editor._editor : editor._input]);
		}

		
		var triggerCommit = false;
	    

		var row = cell.get_row();
		
		
		if (!rowEditing && this._activation && !grid._isAuxRow(row) && grid.get_rows().get_length() - 1 == row.get_index() &&
			cell.get_column().get_visibleIndex() == grid._gridUtil._findLastVisibleColumn().get_visibleIndex())
			triggerCommit = true;

		this._cellInEditMode = null;
		this._currentEditor = null;
		
		grid._cellInEditMode = false;
		this._cellHeight = null;
		this._isExitingEditMode = false;
		if (triggerCommit)
			util._fireEvent(grid, "TriggerCommit", null);
	},

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	_initValidators: function (elem)
	{
		
		if (this._gridElement._validators_)
			return;
		var nodes = elem ? elem.childNodes : null;
		if (!nodes)
			return;
		
		for (var i = 0; i < nodes.length; i++)
		{
			elem = nodes[i];
			var vals = elem ? elem.Validators : null;
			
			if (vals && vals[0])// && (elem.tagName == 'INPUT' || elem.tagName == 'SELECT' || elem.tagName == 'TEXTAREA'))
			{
				
				if (vals[0].controltovalidate != this._gridElement.id)
					continue;
				
				this._moveValidators(this._gridElement, vals);
				elem.Validators = null;

				
				
				elem.onchange = null;
				return;
			}
			
			this._initValidators(elem);
		}
	},
	
	
	
	
	
	_moveValidators: function (elem, vals)
	{
		elem._validators_ = vals;
		var i = vals.length;
		var div = elem._validators_div = document.createElement('DIV');
		div.style.display = 'none';
		div.style.visibility = 'hidden';
		elem.appendChild(div);
		while (i-- > 0)
		{
			elem = vals[i];
			elem.parentNode.removeChild(elem);
			div.appendChild(elem);
			
			if (elem.evaluationfunction && elem.evaluationfunction.toString().indexOf("RegularExpressionValidator") > -1)
				elem.controltovalidate = this._gridElement.id + "_clientState";
		}
		this._onBeforeAsyncFn = Function.createDelegate(this, this._onBeforeAsyncRender);
		this._grid._gridUtil._registerEventListener(this._grid, "BeforeAsyncRender", this._onBeforeAsyncFn);
	},
	_onBeforeAsyncRender: function ()
	{
		
		var vals = this._gridElement._validators_, div = this._gridElement._validators_div;
		if (!vals || !div)
			return;
		var parent, val, i = vals.length;
		while (i-- > 0)
		{
			val = vals[i];
			if ((parent = val.parentNode) != div)
			{
				parent.removeChild(val);
				div.appendChild(val);
			}
		}
	},
	get_isInEditMode: function (cell)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridEditBase.isInEditMode">
		/// Gets a value that indicates whether the cell is in edit mode.
		/// </summary>
		/// <param name="cell" type="Infragistics.Web.UI.GridCell">WebDataGrid cell object to check if is in edit mode.</param>
		/// <returns type="Boolean"></returns>
		return (this._cellInEditMode == cell);
	},

	







	_addEnteringEditEventListener: function (handler)
	{
		/// <summary>
		/// Listen for when the grid enters edit mode. For internal use only. 
		/// </summary>
		this._grid._gridUtil._registerEventListener(this, "EnteringEdit", handler);
	},

	_addExitedEditEventListener: function (handler)
	{
		/// <summary>
		/// Listen for when the grid exits edit mode. For internal use only. 
		/// </summary>
		this._grid._gridUtil._registerEventListener(this, "ExitedEdit", handler);
	},

	

	
	_onClickHandler: function (evnt)
	{


		if (this._currentEditor != null && evnt.target == this._currentEditor._element)
			return;

		if (this._editModeActions.get_mouseClick() == $IG.EditMouseClickAction.Single)
			this.__enterEditModeEvntHandler(evnt);

	},

	_onDblclickHandler: function (evnt)
	{

		if (this._currentEditor != null && evnt.target == this._currentEditor._element)
			return;

		if (this._editModeActions.get_mouseClick() == $IG.EditMouseClickAction.Double)
			this.__enterEditModeEvntHandler(evnt);
	},

	_onKeypressHandler: function (evnt)
	{
		if (this._cellInEditMode || !this._grid || this._grid._cellInEditMode || !this._activation || !this._editModeActions.get_enableOnKeyPress())
			return;

		var key = evnt ? evnt.charCode : 0;
		var shift = evnt ? evnt.shiftKey : false;
		var stringChar = evnt ? String.fromCharCode(key) : null;
		
		if (key == 27 || (evnt.ctrlKey && key < 30))
			return;
		
		
		
		
		
		//if (key < 43 || ($util.IsOpera && key < 48) || (this._grid._get_mainGrid && (key < 46 || key == 95 || key == 61)))
		//	return;
		


		if ((!shift && !stringChar && (key == Sys.UI.Key.esc || key == Sys.UI.Key.left || key == Sys.UI.Key.tab || key == Sys.UI.Key.up || key == Sys.UI.Key.right || key == Sys.UI.Key.down
					|| key == Sys.UI.Key.enter)) || (this._grid._get_mainGrid && key < 46) || ($util.IsFireFox && ((!shift && key < 46) || (key == Sys.UI.Key.tab && shift))))
			return;
		this.enterEditMode(this._activation.get_activeCell(), key);
	},

	__onActivationDelay: function (cell)
	{
		this.__activationDelay = null;
		if (this._activation && cell === this._activation.get_activeCell())
			this.enterEditMode(cell);
	},

	_onKeydownHandler: function (evnt)
	{
		if (!this._activation)
			return;
		var key = evnt.keyCode;
		
		if (this._keyPressTR && key == Sys.UI.Key.esc)
			this._grid._gridUtil._fireEvent(this, "ExitKey", { Cell: this._activation.get_activeCell(), Evnt: evnt });
		
		if (key < 48)
			return;
		
		if (key == 113)
		{
			if (!this._editModeActions.get_enableF2())
				return;
		}
		
		else if (!this._keyPressTR || !this._editModeActions.get_enableOnKeyPress())
			return;
		
		else if ((key > 57 && key < 65) || (key > 105 && key < 128))
			return;
		this.enterEditMode(this._activation.get_activeCell());
	},

	_activeCellChanged: function (args)
	{
		this.exitEditMode(true);

		
		if (args.cell && this._editModeActions.get_enableOnActive() && $util.isChild(this._container, args.cell._element))
		{
			if (this.__activationDelay)
				window.clearTimeout(this.__activationDelay);
			this.__activationDelay = window.setTimeout($util.createDelegate(this, this.__onActivationDelay, [args.cell]), 0);
		}
	},
	

	
	
	_addRemoveHGridHandlers: function (grid, util, add)
	{
		var topGrid = grid._getTopGrid();
		if (!topGrid)
			return;
		
		
		var events = ["Resize", "MouseWheel", "ScrollLeftChange", "ScrollLeftChange"];
		try
		{
			
			while (topGrid != grid)
			{
				
				grid = grid.get_parentRow();
				if (!grid)
					break;
				grid = grid.get_grid();
				if (!grid)
					break;
				for (var i = 0; i < events.length; i++)
				{
					if (add)
						util._registerEventListener(grid, events[i], this._stopEditHandler);
					else
						util._unregisterEventListener(grid, events[i], this._stopEditHandler);
				}
			}
		} catch (ex) { }
	},
	
	
	
	__internalEnterEditMode: function (cell, key, rowEditing)
	{
		var grid = this._grid;
		var util = grid ? grid._gridUtil : null;
		var elem = cell ? cell._element : null;
		
		if (!util || !elem || elem.offsetWidth == 0 || elem.offsetHeight == 0)
			return;
		
		
		if (grid.getEditingOn() == 2 || (!rowEditing && $util._re_may_start && $util._re_may_start + 100 > this._now()))
			return;
		
		
		if (grid._cellInEditMode || this._cellInEditMode != null || grid._get_isAjaxCallInProgress() || grid._get_isPostBackInProgress())
			return;
		var editor = this.__resolveEditor(cell);
		if (editor == null)
			return;

		var customDisplay = { cancel: null, top: null, left: null, height: null, width: null, text: null };
		
		if (!rowEditing)
			util._fireEvent(this, "EnteringEdit", { cell: cell, customDisplay: customDisplay });
		var height = customDisplay.height;
		var width = customDisplay.width;
		if (customDisplay.cancel || (width && width < 0) || (height && height < 0))
			return;

		var displayText = customDisplay.text;
		var args = rowEditing ? null : this.__raiseClientEvent("EnteringEditMode", $IG.CancelEditModeEventArgs, [cell, displayText]);
		if (args == null || !args.get_cancel())
		{
			if (args)
				customDisplay.text = args.get_displayText();
			var container = cell.get_row()._container;
			if (!container)
				container = this._container;
			//container.style.position = "relative";
			this._cellInEditMode = cell;
			this._currentEditor = editor;
			
			grid._cellInEditMode = true;
			var top = customDisplay.top;
			var left = customDisplay.left;
			if (width == null)
				width = elem.offsetWidth;
			if (left == null)
				left = elem.offsetLeft;
			if (height == null)
				height = elem.offsetHeight;
			
			left -= $util.toIntPX(null, 'borderRightWidth', 0, elem);
			var fix = $util.toIntPX(null, 'borderBottomWidth', 0, elem);
			if (top == null)
			{
				if (elem.nodeName == 'TD')
					elem = elem.parentNode;
				top = elem.offsetTop;
			}
			top -= fix;
			
			
			
			editor._charKey = key && key > 31 ? key : undefined;
			editor.set_value((customDisplay.text == null) ? (editor._dataType ? cell.get_text() : cell.get_value()) : customDisplay.text);
			if (this.__enterEditFilter)
				this.__enterEditFilter(cell, editor);
			
			editor._startTime = this._now();
			editor.showEditor(top, left, width, height, this._editCellCssClass, container, cell);
			this._hideValidator(editor);
			if (!rowEditing)
				this.__raiseClientEvent("EnteredEditMode", $IG.EditModeEventArgs, [cell, editor._editor ? editor._editor : editor._input]);

			if (!this._stopEditHandler)
			{
				this._stopEditHandler = Function.createDelegate(this, this._onGridStopEditing);
				this._onGridSelectStartHandler = Function.createDelegate(this, this._onGridSelectStart);
				util._registerEventListener(grid, "Resize", this._stopEditHandler);
				util._registerEventListener(grid, "MouseWheel", this._stopEditHandler);
				util._registerEventListener(grid, "ScrollLeftChange", this._stopEditHandler);
				util._registerEventListener(grid, "ScrollTopChange", this._stopEditHandler);
				util._registerEventListener(grid, "SelectStartContainer", this._onGridSelectStartHandler);
				
				this._addRemoveHGridHandlers(grid, util, true);
				
				
				var i = 0, div = grid._element;
				while (div = div.parentNode)
				{
					var tag = div.nodeName;
					if (tag == 'BODY' || tag == 'FORM' || tag == 'HTML')
						break;
					if (tag != 'DIV')
						continue;
					var scroll = $util.getStyleValue(null, 'overflow', div);
					if (scroll != 'auto' && scroll != 'scroll')
						continue;
					$addHandler(div, 'scroll', this._stopEditHandler);
					if (i == 0)
						this._scrollDIVs = new Array();
					this._scrollDIVs[i++] = div;
				}
			}
		}
	},

	_onGridStopEditing: function (args)
	{
		
		if (!args || args.scrollDelta != 0)
			this.exitEditMode(true);
	},

	_onGridSelectStart: function (evnt)
	{
		var elem = evnt.target;
		var isEppool = false;
		while (!isEppool && elem && typeof (elem.id) != "undefined")
		{
			elem = elem.parentNode;
			isEppool = (elem.id == this._grid._element.id + "_eppool");
		}

		if (!isEppool)
			this._onGridStopEditing();
	},

	__enterEditModeEvntHandler: function (evnt)
	{
		if (evnt.button == 0)
		{
			var cell = this._grid._gridUtil.getCellFromElem(evnt.target);
			this.enterEditMode(cell);
		}
	},

	__editorLostFocus: function (evnt)
	{
		$util._browser_evt = evnt;
		
		if (this._currentEditor)
			this._stopEdit(evnt);
		$util._browser_evt = null;
	},
	
	_stopEdit: function (evnt)
	{
		this._currentEditor._originalNotifyLostFocus(evnt);
		var key = (evnt && evnt.type == 'keydown') ? evnt.keyCode : null;
		if (!key)
			return this.exitEditMode(true);
		var util = this._grid._gridUtil;
		var cell = this._cellInEditMode;
		if (key == Sys.UI.Key.tab)
		{
			var nextCell = evnt.shiftKey ? util.getPrevCell(cell) : util.getNextCell(cell);
			if (this.exitEditMode(true))
				return;
			util._fireEvent(this, "ExitKey", { Cell: cell, Evnt: evnt });
			if (nextCell)
			{
				
				this._activate(nextCell, $util.IsIE ? 150 : 0);
				
				//$util.cancelEvent(evnt);
				$util.preventDefaults(evnt);
			}
		}
		else
		{
			var delay = 0;
			if (key == Sys.UI.Key.esc)
			{
				if (this.exitEditMode(false))
					return;
				delay = ($util.IsIE && this._keyPressTR) ? 200 : 10;
			}
			
			else if (key == Sys.UI.Key.enter && !evnt.shiftKey && !evnt.ctrlKey)
			{
				if (this.exitEditMode(true))
					return;
				util._fireEvent(this, "ExitKey", { Cell: cell, Evnt: evnt });
			}
			
			//$util.cancelEvent(evnt);
			$util.preventDefaults(evnt);
			this._activate(null, delay);
		}
	},
	
	_activate: function (cell, delay)
	{
		var activation = this._activation;
		if (!activation)
			return;
		if (!cell)
			if (!(cell = activation.get_activeCell()))
				return;
		var same = cell == activation.get_activeCell();
		
		if (delay == -2)
		{
			
			if (same && !this._cellInEditMode && this._grid && !this._grid._cellInEditMode) try
			{
				cell.get_element().focus();
			}
			catch (delay) { }
			return;
		}
		if (same)
			activation.__focusCell(cell);
		else
			activation.set_activeCell(cell, true);
		
		
		if (!$util.IsIE7 && activation._grid._isAuxRow(cell.get_row()))
			setTimeout($util.createDelegate(this, this._activate, [cell, -2]), delay);
	},

	__resolveEditor: function (cell)
	{
		var column = cell.get_column();
		return this.__resolveEditorForColumn(column);
	},

	__resolveEditorForColumn: function (column)
	{
		if (!column)
			return this._varifyEP();
		
		var id, elem, grid = this._grid,
			
			editor = column._editor_,
			
			rowEditing = grid._re_obj,
			type = column.get_dataType(),
			pool = this._grid._editorProvidersPool,
			key = column.get_key(),
			
			validatorID = column._validatorID_,
			
			validators = this._gridElement._validators_;
		
		if (!rowEditing)
			delete this.Validators;
		
		if (!editor)
		{
			
			if (type == 15 || !pool) //byte[] do not allow edit
				return null;
			var colSetting = this.get_columnSettings()._getObjectByAdr(key);
			if (colSetting)
			{
				if (colSetting.get_readOnly())
					return null;
				if (validators)
					column._validatorID_ = validatorID = colSetting.get_validatorID();
				elem = colSetting._get_editor();
			}
			
			var num = type > 0 && type < 12;
			
			var shared = !elem && (num || type == 12) ? $util.findControl('_ig_def_ep_' + (num ? 'n' : 'd')) : null;
			if (shared)
			{
				if (!rowEditing)
				{
					
					elem = shared._element;
				}
				else
				{
					
					id = grid._element.id + '_auto_' + key;
					
					editor = $util.findControl(id);
					if (editor)
						elem = editor._element;
					if (!elem)
					{
						
						elem = document.createElement('INPUT');
						elem.id = id;
						
						elem.className = shared._ep_css || shared._elem.className || 'igte_Edit';
						elem.style.textAlign = shared._elem.style.textAlign;
						
						editor = $create(num ? Infragistics.Web.UI.WebNumericEditor : Infragistics.Web.UI.WebDateTimeEditor, {
							id:id,
							name:id,
							props:[[[],{c:{
								vse:0,
								prop:shared._get_clientOnlyValue('prop'),
								prop1:shared._get_clientOnlyValue('prop1'),
								uid:id
							}}],,,[]]},null, null, elem);
						
						var div = document.createElement('DIV');
						div.id = id + '_ep';
						pool.appendChild(div);
						div.appendChild(elem);
						
						elem.control = new $IG.TextEditorProvider(id, div);
					}
					
					shared = editor;
					
					editor = column._editor_ = elem.control;
				}
				
				if (num && shared.set_dataMode)
					shared.set_dataMode(type);
			}
			
			if (elem && !editor)
			{
				
				editor = elem.control;
				
				var parent = elem.parentNode;
				
				grid._oldParent_IEBug(parent);
				var oldParent = parent ? parent.parentNode : null;
				
				
				if (!editor || !editor.showEditor || !editor._getWrapper)
				{
					if (!oldParent)
						return null;
					editor = elem.control = new $IG.TextEditorProvider(elem.id, parent);
					
					editor._shared = true;
					
					
					if (!parent._oldParent)
						parent._oldParent = oldParent;
				}
				

				

				
				if ((editor._shared || (grid._thisType != "webDataGrid" && oldParent && oldParent.id.indexOf("_eppool") > 0)) && oldParent != pool)
				{
					
					
					try
					{
						
						//if (oldParent && (editor._shared || (oldParent && oldParent.id.indexOf("_eppool") > 0)))
						oldParent.removeChild(parent);
						pool.appendChild(parent);
					} catch (ex) { }
				}
				
				else if (editor._owner != grid)
				{
					
					if (elem.parentNode != pool)
					{
						
						grid._oldParent_IEBug(elem);
						
						
						elem._oldParent = oldParent = elem.parentNode;
						oldParent.removeChild(elem);
						pool.appendChild(elem);
					}
				}
			}
		}
		if (!editor && rowEditing)
		{
			id = grid._element.id + "_" + type + key;
			if (type == 13)
				editor = new $IG.CheckboxEditProvider(id, grid, column);
			else
				editor = new $IG.EditorProvider(id, null, null, grid, null, type);
			column._editor_ = editor;
		}
		editor = this._varifyEP(editor, type);
		
		if (validators)
		{
			for (var i = 0; i < validators.length; i++)
			{
				if (validators[i].id == validatorID)
				{
					this.Validators = this.Validators || [];
					this.Validators[this.Validators.length] = editor._validator = validators[i];
					break;
				}
			}
		}
		return editor;
	},
	
	_varifyEP: function (editor, type)
	{
		if (!editor)
		{
			editor = this._getDefEditor();
			elem = editor._input;
			
			if (type == 14)
				elem.maxLength = 1;
			else
				elem.removeAttribute('maxLength');
		}
		if (!editor._originalNotifyLostFocus)
		{
			editor._originalNotifyLostFocus = editor.notifyLostFocus;
			editor.notifyLostFocus = Function.createDelegate(this, this.__editorLostFocus);
		}
		editor._owner = this._grid;
		delete editor._validator;
		return editor;
	},
	_getDefEditor: function ()
	{
		if (!this._defaultEditor)
			this._defaultEditor = new $IG.EditorProvider('ed0', null, null, this._grid);
		return this._defaultEditor;
	},
	








	_addExitKeyHandledEventListener: function (handler)
	{
		/// <summary>
		/// Listen for when the grid leaves edit mode. For internal use only. 
		/// </summary>
		this._grid._gridUtil._registerEventListener(this, "ExitKey", handler);
	},
	

	
	_createObjects: function (objectManager)
	{
		$IG.GridEditBase.callBaseMethod(this, "_createObjects", [objectManager]);
		this._editModeActions = new $IG.EditModeActions("EditModeActions", null, objectManager.get_objectProps(0), this);
		
		if (this._editModeActions.get_enableOnKeyPress() && $util.IsSafari)
			this._getDefEditor();
		objectManager.register_object(0, this._editModeActions);
		objectManager.__createdObjectCount = 1;
	},

	_createCollections: function (collectionsManager)
	{
		this._columnSettings = collectionsManager.register_collection(0, $IG.ObjectCollection);
		var collectionItems = collectionsManager._collections[0];
		for (var columnKey in collectionItems)
			this._columnSettings._addObject($IG.ColumnEditableSetting, null, columnKey);
	},

	_initializeComplete: function ()
	{
		this._connectContainerEvents();
		this._activation = this._grid.get_behaviors().getBehaviorFromInterface($IG.IActivationBehavior);
		if (this._activation)
			this._activation._addActiveCellChangedEventHandler(Function.createDelegate(this, this._activeCellChanged), true);
		
		
		
		
		if ($util.IsFireFox4Plus || $util.IsChrome)
		{
			this._onpostnotify = Function.createDelegate(this, this._onPostNotify);
			this._grid._gridUtil._registerEventListener(this._grid, "PostBackStart", this._onpostnotify);
		}
	},

	_connectContainerEvents: function ()
	{
		var elem = this._get_editContainer();
		if (!elem || this._containerClickHandler)
			return;
		this._containerClickHandler = Function.createDelegate(this, this._onClickHandler);
		this._containerDoubleClickHandler = Function.createDelegate(this, this._onDblclickHandler);
		this._grid._addElementEventHandler(elem, "click", this._containerClickHandler);
		this._grid._addElementEventHandler(elem, "dblclick", this._containerDoubleClickHandler);
		this._gridElementKeyDownHandler = Function.createDelegate(this, this._onKeydownHandler);
		this._grid._addElementEventHandler(elem, "keydown", this._gridElementKeyDownHandler);
		this._keyPressTR = elem.nodeName == 'TR';
		
		if (!this._keyPressTR)
		{
			this._gridElementKeyPress = Function.createDelegate(this, this._onKeypressHandler);
			this._grid._addElementEventHandler(elem, "keypress", this._gridElementKeyPress);
		}
	},

	_disconnectContainerEvents: function ()
	{
	    var elem = this._get_editContainer();
	    //A.T. 27 August 2014 - fix for #174671
		if (!elem || !this._containerClickHandler || !elem._events)
			return;
		this._grid._removeElementEventHandler(elem, "click", this._containerClickHandler);
		this._grid._removeElementEventHandler(elem, "dblclick", this._containerDoubleClickHandler);
		delete this._containerClickHandler;
		delete this._containerDoubleClickHandler;
		this._grid._removeElementEventHandler(elem, "keydown", this._gridElementKeyDownHandler);
		delete this._gridElementKeyDownHandler;
		if (!this._keyPressTR)
		{
			this._grid._removeElementEventHandler(elem, "keypress", this._gridElementKeyPress);
			delete this._gridElementKeyPress;
		}
	},

	
	
	_onPostNotify: function ()
	{
		if (!this.get_cellInEditMode() || this._isExitingEditMode)
			return;
		
		this.exitEditMode(true);
	},

	dispose: function ()
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridEditBase.dispose">
		/// For internal use.
		///</summary>
		if (!this._grid)
			return;
		if (this._onBeforeAsyncFn)
			this._grid._gridUtil._unregisterEventListener(this._grid, "BeforeAsyncRender", this._onBeforeAsyncFn);
		this._onBeforeAsyncFn = null;
		if (!Sys.Application._disposing)
		{
			this._editModeActions.dispose();
			this._editModeActions = null;
		}
		this._disconnectContainerEvents();
		if (this._defaultEditor)
			this._defaultEditor.dispose();
		
		if (this._onpostnotify)
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "PostBackStart", this._onpostnotify);
			delete this._onpostnotify;
		}
		



		
		this._owner._gridUtil._unregisterEventListener(this._owner, "ChangingEPPoolLocation", this._onChangingEPPoolLocationHandler);
		this._owner._gridUtil._unregisterEventListener(this._owner, "RasingClientEventEnd", this._onChangingEPPoolLocationHandler);
		
		if (this._owner._thisType == "containerGrid")
			this._owner._gridUtil._unregisterEventListener(this._owner, "RowPopulating", this._onChangingEPPoolLocationHandler);
		delete this._onChangingEPPoolLocationHandler;

		$IG.GridEditBase.callBaseMethod(this, "dispose");
	},
	

	
	_columnSettings: null,
	get_columnSettings: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.GridEditBase.columnSettings">
		/// Returns the column settings.
		///</summary>
		return this._columnSettings;
	},
	get_columnSettingFromKey: function (columnKey)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.GridEditBase.get_columnSettingFromKey">
		/// Gets the column summary setting object that is tied to the column with the specified column key.
		/// </summary>
		///<param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the editable column setting is tied to.
		///</param>
		/// <value type="Infragistics.Web.UI.ColumnEditableSetting">The editing column setting tied to the specified column key</value>

		if (this._columnSettings && this._columnSettings._items)
		{
			for (var i = 0; i < this._columnSettings._items.length; i++)
			{
				if (this._columnSettings._items[i].get_columnKey() === columnKey)
					return this._columnSettings._items[i];
			}
		}
		return null;
	},
	
	_get_editContainer: function ()
	{
		return this._editContainer;
	}
}
$IG.GridEditBase.registerClass('Infragistics.Web.UI.GridEditBase', $IG.GridBehavior, $IG.IColumnSettings);


$IG.EditMouseClickAction = function ()
{
	/// <summary locid="T:J#Infragistics.Web.UI.EditMouseClickAction">
	/// The enumeration defines mouse action that enters the grid into edit mode.
	/// </summary>
	/// <field name="None" type="Number" integer="true" static="true">
	/// No editing should be started when the grid is clicked.
	/// </field>
	/// <field name="Single" type="Number" integer="true" static="true">
	/// Edit mode should be entered on a single mouse click.
	/// </field>
	/// <field name="Double" type="Number" integer="true" static="true">
	/// Edit mode should be entered on a double mouse click.
	/// </field>
}
$IG.EditMouseClickAction.prototype =
{
	None: 0,
	Single: 1,
	Double: 2

};
$IG.EditMouseClickAction.registerEnum("Infragistics.Web.UI.EditMouseClickAction");



$IG.EditModeActionsProps = new function ()
{
	this.MouseClick = [$IG.ObjectBaseProps.Count + 0, $IG.EditMouseClickAction.Double];
	this.EnableF2 = [$IG.ObjectBaseProps.Count + 1, true];
	this.EnableOnActive = [$IG.ObjectBaseProps.Count + 2, false];
	this.EnableOnKeyPress = [$IG.ObjectBaseProps.Count + 3, false];
	this.Count = $IG.ObjectBaseProps.Count + 4;
};



$IG.EditModeActions = function (obj, element, props, control)
{
	/// <summary locid="T:J#Infragistics.Web.UI.EditModeActions">
	/// The object contains actions that will cause the grid to enter edit mode.
	/// </summary>
	var csm = obj ? new $IG.ObjectClientStateManager(props[0]) : null;
	$IG.EditModeActions.initializeBase(this, [obj, element, props, control, csm]);
}

$IG.EditModeActions.prototype =
{
	get_mouseClick: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditModeActions.mouseClick">
		/// Gets/sets the value determining whether single clicks, or double clicks
		/// will cause the cell to enter edit mode.
		/// </summary>
		/// <value type="Infragistics.Web.UI.EditMouseClickAction"></value>
		return this._get_value($IG.EditModeActionsProps.MouseClick);
	},
	set_mouseClick: function (value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditModeActions.mouseClick">
		/// Sets the value determining whether single clicks, or double clicks
		/// will cause the cell to enter edit mode.
		/// </summary>
		/// <param name="value" type="Infragistics.Web.UI.EditMouseClickAction">The new value for entering edit mode on mouse click.</param>
		this._set_value($IG.EditModeActionsProps.MouseClick, value);
	},

	get_enableF2: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditModeActions.enableF2">
		/// Gets/sets the value determining whether keying F2
		/// will cause the cell to enter edit mode.
		/// </summary>
		/// <value type="Boolean"></value>
		return this._get_value($IG.EditModeActionsProps.EnableF2, true);
	},
	set_enableF2: function (value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditModeActions.enableF2">
		/// Sets the value determining whether keying F2
		/// will cause the cell to enter edit mode.
		/// </summary>
		/// <param name="value" type="Boolean">The new value for whether to enter edit mode on F2 press.</param>
		this._set_value($IG.EditModeActionsProps.EnableF2, value);
	},

	get_enableOnActive: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditModeActions.enableOnActive">
		/// Gets/sets the value determining whether the cell will enter edit mode
		/// upon being activated.
		/// </summary>
		/// <value type="Boolean"></value>
		return this._get_value($IG.EditModeActionsProps.EnableOnActive, true);
	},
	set_enableOnActive: function (value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditModeActions.enableOnActive">
		/// Sets the value determining whether the cell will enter edit mode
		/// upon being activated.
		/// </summary>
		/// <param name="value" type="Boolean">The new value for whether to enter edit mode on cell activation.</param>
		this._set_value($IG.EditModeActionsProps.EnableOnActive, value);
	},

	get_enableOnKeyPress: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditModeActions.enableOnKeyPress">
		/// Gets/sets the value determining whether the cell will enter edit mode
		/// when it is active and a key is pressed.
		/// </summary>
		/// <value type="Boolean"></value>
		return this._get_value($IG.EditModeActionsProps.EnableOnKeyPress, true);
	},
	set_enableOnKeyPress: function (value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditModeActions.enableOnKeyPress">
		/// Sets the value determining whether the cell will enter edit mode
		/// when it is active and a key is pressed.
		/// </summary>
		/// <param name="value" type="Boolean">The new value for whether to enter edit mode on key press.</param>
		this._set_value($IG.EditModeActionsProps.EnableOnKeyPress, value);
	}

}

$IG.EditModeActions.registerClass('Infragistics.Web.UI.EditModeActions', $IG.ObjectBase);




$IG.CancelEditModeEventArgs = function (params)
{
	/// <summary locid="T:J#Infragistics.Web.UI.CancelEditModeEventArgs">
	/// Event arguments object that is passed into the EnteringEditMode and ExitingEditMode event handlers. Provides an option to cancel the events.
	/// </summary>
	$IG.CancelEditModeEventArgs.initializeBase(this);
	this._cell = params[0];
	this._text = params[1];
	this._props[0] = $util._browser_evt;
}
$IG.CancelEditModeEventArgs.prototype =
{
	getCell: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CancelEditModeEventArgs.getCell">
		/// Returns the cell that is about to enter edit mode.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.GridCell"></returns>
		return this._cell;
	},

	get_displayText: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.CancelEditModeEventArgs.displayText">
		///Allows providing custom display text for an editor. Null means default value should be used.
		///</summary>
		///<value type="String" mayBeNull="true"></value>
		return this._text;
	},

	set_displayText: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.CancelEditModeEventArgs.displayText">
		///Allows providing custom display text for an editor. Null means default value should be used.
		///</summary>
		///<param name="value" type="String" mayBeNull="true">The custom text to set for the editor.</param>
		this._text = value;
	}
}
$IG.CancelEditModeEventArgs.registerClass('Infragistics.Web.UI.CancelEditModeEventArgs', $IG.CancelEventArgs);


$IG.EditModeEventArgs = function (params)
{
	/// <summary locid="T:J#Infragistics.Web.UI.EditModeEventArgs">
	/// Event arguments object that is passed into the EnteredEditMode and ExitedEditMode event handlers.
	/// </summary>
	$IG.EditModeEventArgs.initializeBase(this);
	this._cell = params[0];
	this._editor = params[1];
	this._props[0] = $util._browser_evt;
}
$IG.EditModeEventArgs.prototype =
{
	getCell: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.EditModeEventArgs.getCell">
		/// Returns the cell that has entered edit mode.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.GridCell"></returns>
		return this._cell;
	},
	getEditor: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.EditModeEventArgs.getEditor">
		/// Returns the reference to html element or javascript object which is used as editor.
		/// </summary>
		/// <value></value>
		return this._editor;
	}
}
$IG.EditModeEventArgs.registerClass('Infragistics.Web.UI.EditModeEventArgs', $IG.EventArgs);



$IG.ColumnEditableSetting = function (adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ColumnEditableSetting">
	/// Object that defines a column editable setting for a grid behavior.
	/// </summary>
	$IG.ColumnEditableSetting.initializeBase(this, [adr, element, props, owner, csm]);

	this._editorID = this._get_clientOnlyValue("eid");
	this._validatorID = this._get_clientOnlyValue("vid");
	this._readOnly = this._get_clientOnlyValue("ro");
}

$IG.ColumnEditableSetting.prototype =
{
	get_editorID: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnEditableSetting.editorID">
		/// Gets the editor ID.
		/// </summary>
		/// <value type="String"></value>
		return this._editorID;
	},
	
	_get_editor: function ()
	{
		
		var grid = this._owner._grid, id = this._editorID;
		if (!grid || !id)
			return null;
		
		var elem = $get(grid._id + '_' + id);
		if (!elem)
			elem = $get(id);
		if (elem)
			return elem;
		
		if (grid = grid._getTopGrid())
			elem = $get(grid._id + '_' + id);
		return elem;
	},

	get_validatorID: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnEditableSetting.validatorID">
		/// Gets the ClientID of validator associated with editor.
		/// </summary>
		/// <value type="String"></value>
		return this._validatorID;
	},
	get_readOnly: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnEditableSetting.readOnly">
		/// Indicates whether the column is read-only.
		/// </summary>
		/// <value type="Boolean"></value>
		return this._readOnly;
	},
	dispose: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnEditableSetting.dispose">
		/// Dispose of the object.
		/// </summary>

		$IG.ColumnSetting.callBaseMethod(this, "dispose");
		delete this._editorID;
		delete this._validatorID;
		delete this._readOnly;
	}

}
$IG.ColumnEditableSetting.registerClass('Infragistics.Web.UI.ColumnEditableSetting', $IG.ColumnSetting);



$IG.ColumnEditableSettingProps = new function ()
{
	this.ReadOnly = [$IG.ColumnSettingProps.Count + 0, false];
	this.Count = $IG.ColumnSettingProps.Count + 1;
};

