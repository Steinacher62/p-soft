/*
* igWebDataGridPaging.js
* Version 14.2.20142.1028
* Copyright(c) 2001-2014 Infragistics, Inc. All Rights Reserved.
*/



$IG.Paging = function(obj, objProps, control, parentCollection)
{
	/// <summary locid="T:J#Infragistics.Web.UI.Paging">
	/// Paging behavior object of the grid. 
	/// </summary>
	$IG.Paging.initializeBase(this, [obj, objProps, control, parentCollection]);

	this._pageIndex = this._get_clientOnlyValue("pi");
	this._pageCount = this._get_clientOnlyValue("pc");
	this._pageSize = this._get_clientOnlyValue("ps");
	this._pagerAppearance = this._get_clientOnlyValue("pa");

	this._elementTop = this._get_owner()._elements["pager_top"];
	this._elementBottom = this._get_owner()._elements["pager_bottom"];

	if (this._elementTop)
	//$addHandler(this._elementTop, "click", Function.createDelegate(this, this._onPagerClick));
		this._grid._addElementEventHandler(this._elementTop, "click", Function.createDelegate(this, this._onPagerClick));

	if (this._elementBottom)
	//$addHandler(this._elementBottom, "click", Function.createDelegate(this, this._onPagerClick));
		this._grid._addElementEventHandler(this._elementBottom, "click", Function.createDelegate(this, this._onPagerClick));
}

$IG.Paging.prototype =
{
	get_pageIndex: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.Paging.pageIndex">
		///Returns/sets current page index.
		///By setting a new page index the paging will update rows accordingly to the
		///index that is set.
		///</summary>
		///<value type="Number" integer="true"></value>
		return this._pageIndex;
	},

	set_pageIndex: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.Paging.pageIndex">
		///Sets current page index.  By setting a new page index the paging will update rows accordingly to the
		///index that is set.
		///</summary>
		///<param name="value" type="Number" integer="true">The new page index</value>
		// Second parameter is assumed to be a raise event flag.
		// Not in the param list so it is not documented.
		
		if (this.getEditingOn())
			return;
		var raiseEvent = arguments[1];

		if (value == this.get_pageIndex())
			return;

		//
		var oldPageIndex = this.get_pageIndex();

		var eventArgs = null;
		if (raiseEvent)
		{
			eventArgs = new $IG.PagerEventArgs(this, value);
			this._owner._raiseSenderClientEventStart(this, this._clientEvents["PageIndexChanging"], eventArgs);
		}
		if (!eventArgs || !eventArgs.get_cancel())
		{
			this._pageIndex = eventArgs ? eventArgs.get_newPageIndex() : value;
			if (oldPageIndex != this._pageIndex)
			{
				this._owner._actionList.add_transaction(new $IG.GridAction("PageChange", this.get_name(), this, this._pageIndex, oldPageIndex));
				if (raiseEvent)
					this._owner._raiseClientEventEnd(eventArgs);
				else if (!this._grid._enableAjax)
					this._owner._postAction(1);
				else
				{
					eventArgs = new $IG.PagerEventArgs(this, value);
					eventArgs._props[1] = 2;
					this._owner._postAction(eventArgs);
				}
			}
		}
		if (eventArgs)
			eventArgs.dispose();
	},

	_set_pageIndexInternal: function (value)
	{
		this.set_pageIndex(value, true);
	},

	get_pageCount: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.Paging.pageCount">
		///Returns total pages count.
		///</summary>
		///<value type="Number" integer="true"></value>
		return this._pageCount;
	},

	get_pagerAppearance: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.Paging.pagerAppearance">
		///Returns grid's pager appearance.
		///The returned value corresponds to the server's PagerAppearance enumeration: 
		///0 - Top, 1 - Bottom, 2 - Both.
		///</summary>
		///<value type="Number" integer="true"></value>
		return this._pagerAppearance;
	},

	get_pageSize: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.Paging.pageSize">
		///Returns page size.
		///</summary>
		///<value type="Number" integer="true"></value>
		return this._pageSize;
	},

	_onPagerClick: function (evnt)
	{
		//
		var pageIndex = evnt.target.getAttribute("idx");
		if (typeof (pageIndex) != "undefined" && pageIndex != null)
		{
			pageIndex = parseInt(pageIndex, 10);
			this._set_pageIndexInternal(pageIndex);
		}
	},

	get_topPagerElement: function ()
	{
		///<summary>
		/// Returns the top pager HTML element.
		///</summary>
		return this._elementTop;
	},

	get_bottomPagerElement: function ()
	{
		///<summary>
		/// Returns the bottom pager HTML element.
		///</summary>
		return this._elementBottom;
	},
	updatePager: function (pageSize, pageIndex, pageCount)
	{
		///<summary>
		/// This method could be used only when WedDataGrid is bound
		/// at the client and EnableClientRendering property is set to
		/// true. The method updates the navigation bar of WebDataGrid
		/// pager. WebDataGrid page size(number of the rows per page) is
		/// defined by the pageSize parameter, pageIndex indicates the
		/// index of the new current page, pageCount is the number of 
		/// pages the data source is being divided. This method does not update the pager UI if PagerTemplate is used.
		///</summary>
		///<param name="pageSize" type="Number" integer="true">WebDataGrid page size(number of the rows per page)</value>
		///<param name="pageIndex" type="Number" integer="true">Indicates the index of the new current page</value>
		///<param name="pageCount" type="Number" integer="true">The number of pages the data source is being divided.</value>

		var grid = this._get_owner();
		if (!grid.get_enableClientRendering())
			return;

		this._pageIndex = pageIndex;
		this._pageSize = pageSize;
		this._pageCount = pageCount;

		if (!this._get_clientOnlyValue("pcus"))
		{
			if (this._pagerAppearance == 0 || this._pagerAppearance == 2)
				this._elementTop.innerHTML = "";
			if (this._pagerAppearance == 1 || this._pagerAppearance == 2)
				this._elementBottom.innerHTML = "";

			var innerHTML = "";
			var pagerMode = this._get_clientOnlyValue("pm");
			var quickPages = this._get_clientOnlyValue("pqp");

			switch (pagerMode)
			{
				case 0: innerHTML = this._renderNumericTemplate(pageCount, pageIndex, quickPages); break;
				case 1: innerHTML = this._renderNextPrevTemplate(pageCount, pageIndex, quickPages); break;
				case 2: innerHTML = this._renderNextPrevFirsLastTemplate(pageCount, pageIndex, quickPages); break;
				case 3: innerHTML = this._renderNumericFirsLastTemplate(pageCount, pageIndex, quickPages); break;
			}

			if (this._pagerAppearance == 0 || this._pagerAppearance == 2)
				this._elementTop.innerHTML = innerHTML;
			if (this._pagerAppearance == 1 || this._pagerAppearance == 2)
				this._elementBottom.innerHTML = innerHTML;
		}
		var rowSelectors = this._grid.get_behaviors().get_rowSelectors();
		if (rowSelectors)
			rowSelectors._applyRowNumbering();

		grid._onDataTblResize({ "clientHeight": grid._elements.dataTbl.clientHeight }, null);
		grid._onResize({ "clientHeight": grid._element.clientHeight }, false);
	},

	_renderNumericTemplate: function (pageCount, pageIndex, quickPages)
	{
		var innerHTML = "";
		var pageClass = "";
		var startIndex = 0;
		var endIndex;

		if (quickPages > 0 && quickPages < pageIndex)
			startIndex = pageIndex - quickPages;

		if (quickPages > 0 && pageIndex + quickPages < pageCount - 1)
			endIndex = pageIndex + quickPages;
		else
			endIndex = pageCount - 1;

		if (startIndex > 0)
			innerHTML = innerHTML + "<span class='" + this._get_clientOnlyValue("plp") + "' idx='" + (startIndex - 1) + "'>...</span>";

		if (pageCount > 1)
		{
			for (var i = startIndex; i < endIndex + 1; i++)
			{
				if (pageIndex == i)
					pageClass = this._get_clientOnlyValue("pcp");
				else
					pageClass = this._get_clientOnlyValue("plp");
				if (innerHTML != "")
					innerHTML += "&nbsp;";
				innerHTML += "<span class='" + pageClass + "' idx='" + i + "'>" + (i + 1) + "</span>";
			}
		}

		if (pageIndex == 0 && pageCount == 1)
			innerHTML += "<span class='" + this._get_clientOnlyValue("pcp") + "' idx='0'>1</span>";

		if (endIndex < pageCount - 1)
		{
			if (innerHTML != "")
				innerHTML += "&nbsp;&nbsp;";
			innerHTML += "<span class='" + this._get_clientOnlyValue("plp") + "' idx='" + (endIndex + 1) + "'>...</span>";
		}

		return innerHTML;
	},

	_renderNextPrevTemplate: function (pageCount, pageIndex, quickPages)
	{
		var innerHTML = "";
		if (pageCount < 2)
			return innerHTML;

		var pageClass = this._get_clientOnlyValue("plp");
		var nextText = this._get_clientOnlyValue("pnxtTxt");
		var prevText = this._get_clientOnlyValue("pprvTxt");

		if (pageIndex > 0)
			innerHTML = "<span class='" + pageClass + "' idx='" + (pageIndex - 1) + "'>" + prevText + "</span>";

		if (pageIndex < pageCount - 1)
		{
			if (innerHTML != "")
				innerHTML += "&nbsp;";
			innerHTML += "<span class='" + pageClass + "' idx='" + (pageIndex + 1) + "'>" + nextText + "</span>";
		}

		return innerHTML;
	},

	_renderNextPrevFirsLastTemplate: function (pageCount, pageIndex, quickPages)
	{
		var innerHTML = "";
		if (pageCount < 2)
			return innerHTML;

		var pageClass = this._get_clientOnlyValue("plp");
		var nextText = this._get_clientOnlyValue("pnxtTxt");
		var prevText = this._get_clientOnlyValue("pprvTxt");
		var firstPageText = this._get_clientOnlyValue("pfstTxt");
		var lastPageText = this._get_clientOnlyValue("plstTxt");

		if (pageIndex > 0)
		{
			innerHTML = "<span class='" + pageClass + "' idx='0'>" + firstPageText + "</span>";
			innerHTML += "&nbsp;<span class='" + pageClass + "' idx='" + (pageIndex - 1) + "'>" + prevText + "</span>";
		}

		if (pageIndex < pageCount - 1)
		{
			if (innerHTML != "")
				innerHTML += "&nbsp;";
			innerHTML += "<span class='" + pageClass + "' idx='" + (pageIndex + 1) + "'>" + nextText + "</span>";
			innerHTML += "&nbsp;<span class='" + pageClass + "' idx='" + (pageCount - 1) + "'>" + lastPageText + "</span>";
		}

		return innerHTML;
	},

	_renderNumericFirsLastTemplate: function (pageCount, pageIndex, quickPages)
	{
		var innerHTML = "";
		var pageClass = this._get_clientOnlyValue("plp");
		var firstPageText = this._get_clientOnlyValue("pfstTxt");
		var lastPageText = this._get_clientOnlyValue("plstTxt");

		if (pageIndex > 0)
			innerHTML = "<span class='" + pageClass + "' idx='0'>" + firstPageText + "</span>&nbsp;";

		innerHTML = innerHTML + this._renderNumericTemplate(pageCount, pageIndex, quickPages);

		if (pageIndex < pageCount - 1)
			innerHTML += "&nbsp;<span class='" + pageClass + "' idx='" + (pageCount - 1) + "'>" + lastPageText + "</span>";

		return innerHTML;
	},

	
	dispose: function ()
	{
		///<summary locid="M:J#Infragistics.Web.UI.Paging.dispose">
		/// Disposes of the Paging behavior.
		///</summary>
		if (this._elementTop)
			$clearHandlers(this._elementTop);

		if (this._elementBottom)
			$clearHandlers(this._elementBottom);

		$IG.Paging.callBaseMethod(this, "dispose");

		this._elementTop = null;

		this._elementBottom = null;
	},
	
	_initializeComplete: function ()
	{
		var isPageIndexChanged = this._get_clientOnlyValue("pic");
		
		if (this._clientEvents["PageIndexChanged"] && isPageIndexChanged)
		{
			this.__raiseClientEvent('PageIndexChanged');
		}
	}
	
}

$IG.Paging.registerClass('Infragistics.Web.UI.Paging', $IG.GridBehavior, $IG.IPagingBehavior);











$IG.PagerEventArgs = function(pager, newPageIndex)
{
	///<summary locid="T:J#Infragistics.Web.UI.PagerEventArgs">
	///Event arguments object that is passed into the PageIndexChanging event handler.
	///</summary>

	// First parameter of the event args object associated with the 
	// behavior must be a reference to the behavior itself. This is essential
	// for proper async call back handling.

	$IG.PagerEventArgs.initializeBase(this, [pager]);
	this._props[2] = newPageIndex;
}
$IG.PagerEventArgs.prototype =
{
	get_newPageIndex: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.PagerEventArgs.newPageIndex">
		///Returns/sets new page index. The index may vary from the originally
		///changed index and therefore the pager can redirect to yet another page than the one
		///that is clicked by the user.
		///</summary>
		///<value type="Number" integer="true"></value>
		return this._props[2];
	},
	set_newPageIndex: function(value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.PagerEventArgs.newPageIndex">
		///Ssets new page index. The index may vary from the originally
		///changed index and therefore the pager can redirect to yet another page than the one
		///that is clicked by the user.
		///</summary>
		///<param name="value" type="Number" integer="true"></param>
		this._props[2] = value;
	}
}
$IG.PagerEventArgs.registerClass('Infragistics.Web.UI.PagerEventArgs', $IG.CancelBehaviorEventArgs);
