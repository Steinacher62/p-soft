/*
* igProgressBar.js
* Version 14.2.20142.1028
* Copyright(c) 2001-2014 Infragistics, Inc. All Rights Reserved.
*/


Type.registerNamespace('Infragistics.Web.UI');

$IG.WebProgressBar = function(element)
{
	/// <summary locid="T:J#Infragistics.Web.UI.WebProgressBar">
	/// Displays a progress bar. 
	/// </summary>
	$IG.WebProgressBar.initializeBase(this, [element]);

	if (this._ResizeTimerId == null)
		this._ResizeTimerId = setInterval(Function.createDelegate(this, this._ResizeProgressBar), 100);

	$IG.WebProgressBar.find = $find;
	$IG.WebProgressBar.from = $IG._from;
}

$IG.WebProgressBar.prototype =
{
	_thisType: 'progressBar',

	
	initialize: function()
	{
		$IG.WebProgressBar.callBaseMethod(this, 'initialize');

		this._f_label = this._elements["f_label"];  //Foreground label span
		this._b_label = this._elements["b_label"];  //Background label span
		this._fillDiv = this._elements["fill"];     //Div containing fill image

		this._innerDiv = this._elements["back"];
		this._container = this._element.firstChild;


		
		if ($util.IsIE6 && this._container.offsetHeight == 0)
		{
			//Search up to the TD element for a parent node that has an offset height greater than 0
			var _cont = this._element.parentNode;
			var parentHeight = 0;
			while (_cont)
			{
				if (_cont.offsetHeight > 0)
				{
					parentHeight = _cont.offsetHeight;
				}
				if (_cont.tagName == "TD")
					break;
				_cont = _cont.parentNode;
			}
			this._container.style.height = parentHeight + "px";
			setTimeout($util.createDelegate(this, this._ResizeProgressBar, [true]), 100);
		}

		

		this._clientHeight = this._element.offsetHeight;
		this._clientWidth = this._element.offsetWidth;

		this._height = this._get_clientOnlyValue("pbh");
		this._width = this._get_clientOnlyValue("pbw");

		this._tokens = Sys.Serialization.JavaScriptSerializer.deserialize(this._get_clientOnlyValue("pbt"));

		if (this._thisType == 'progressBar')
			this._raiseClientEvent('Initialize');

		$addHandlers(this._element, { 'dblclick': this._onDblclick, 'click': this._onClick, 'mouseover': this._onMouseOver, 'mouseout': this._onMouseOut }, this);

		this._initialize = true;
		this._snapToInterval();
		this._initialize = false;
	},
	

	

	get_progressValue: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebProgressBar.progressValue">
		/// Gets the Value property of the control.
	    ///</summary>
		///<value type="Number"></value>
		return this._get_value($IG.WebProgressBarProps.Value);
	},

	set_progressValue: function(val)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebProgressBar.progressValue">
		/// Sets the Value property of the control and then calls _snapToInterval to start the control update process.
	    ///</summary>
		///<param name="val" type="Number">The new value</param>
		var oldval = this.get_progressValue();
		if (!val)
			val = 0;
		else if (typeof val != 'number')
			val = parseFloat(val.toString());
		if (isNaN(val))
			val = 0;
		val = Math.min(Math.max(val, this.get_minimum()), this.get_maximum());
		if (val == oldval)
			return;
		var args = this._raiseClientEvent('ProgressChanging', 'ProgressChanging', null, null, oldval, val);
		if (!args || !args.get_cancel())
		{
			this._set_value($IG.WebProgressBarProps.Value, val);
			this._snapToInterval();
			this._raiseClientEvent('ProgressChanged', 'ProgressChanged', null, null, oldval, val);
		}
	},

	get_labelFormat: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebProgressBar.labelFormat">
		/// Returns the LabelFormatString of the control.
	    ///</summary>
	    ///<value type="String"></value>
		return this._get_value($IG.WebProgressBarProps.LabelFormatString);
	},

	set_labelFormat: function(val)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebProgressBar.labelFormat">
		/// Sets the LabelFormatString of the control.
	    ///</summary>
	    ///<param name="val" type="String">The new label format string</param>
		this._set_value($IG.WebProgressBarProps.LabelFormatString, val);
		this._set_value($IG.WebProgressBarProps.TokenizedLabelFormatString, this._tokenize(val));

		this._updateLabel();

		//Set label position styles to new values.
		this._moveLabel();
	},

	get_snapInterval: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebProgressBar.snapInterval">
		/// Gets the SnapInterval property of the control.
	    ///</summary>
		///<value type="String"></value>
		return this._get_value($IG.WebProgressBarProps.SnapInterval);
	},

	set_snapInterval: function(val)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebProgressBar.snapInterval">
		/// Sets the SnapInterval property of the control (either percent or pixel value).
	    ///</summary>
	    ///<param name="val" type="String">The new snap interval value (either percent or pixel)</param>
		this._set_value($IG.WebProgressBarProps.SnapInterval, val);
		this._snapToInterval();
	},

	get_labelAlignment: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebProgressBar.labelAlignment">
		/// Returns the LabelAlignment property of the control.
	    ///</summary>
	    ///<value type="Infragistics.Web.UI.LabelAlignment"></value>
		return this._get_value($IG.WebProgressBarProps.LabelAlignment);
	},

	set_labelAlignment: function(val)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebProgressBar.labelAlignment">
		/// Sets the LabelAlignment property of the control.
	    ///</summary>
	    ///<param name="val" type="Infragistics.Web.UI.LabelAlignment"></param>
		this._set_value($IG.WebProgressBarProps.LabelAlignment, val);

		this._alignLabel();

		//Set label position styles to new values
		this._moveLabel();
	},

	get_maximum: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebProgressBar.maximum">
		/// Returns Maximum property of the control
	    ///</summary>
		///<value type="Number"></value>
		return this._get_value($IG.WebProgressBarProps.Maximum);
	},

	get_minimum: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebProgressBar.minimum">
		/// Returns Minimum property of the control
	    ///</summary>
	    ///<value type="Number"></value>
		return this._get_value($IG.WebProgressBarProps.Minimum);
	},

	get_orientation: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebProgressBar.orientation">
		/// Gets Orientation of the control
	    ///</summary>
	    ///<value type="Infragistics.Web.UI.Orientation"></value>
		return this._get_value($IG.WebProgressBarProps.Orientation);
	},

	get_fillDirection: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebProgressBar.fillDirection">
		/// Returns the direction that the bar fills
	    ///</summary>
	    ///<value type="Infragistics.Web.UI.FillDirection"></value>
		return this._get_value($IG.WebProgressBarProps.FillDirection);
	},

	get_width: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebProgressBar.width">
		/// Returns the width of the control in pixels
	    ///</summary>
	    ///<value type="Number" integer="true"></value>
		return this._width;
	},

	get_height: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebProgressBar.height">
		/// Returns the height of the control in pixels
	    ///</summary>
		///<value type="Number" integer="true"></value>
		return this._height;
	},

	get_fillMode: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebProgressBar.fillMode">
		/// Returns mode of fill
	    ///</summary>
	    ///<value type="Infragistics.Web.UI.FillMode"></value>
		return this._get_value($IG.WebProgressBarProps.FillMode);
	},

	get_animationThreshold: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebProgressBar.animationThreshold">
		/// Returns the minimum value change that will result in an animation
	    ///</summary>
	    ///<value type="Number"></value>
		return this._get_value($IG.WebProgressBarProps.AnimationThreshold);
	},

	get_animationType: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebProgressBar.animationType">
		/// Returns the animation equation used.
	    ///</summary>
	    ///<value type="Infragistics.Web.UI.AnimationEquationType"></value>
		return this._get_value($IG.WebProgressBarProps.AnimationType);
	},

	get_animationDuration: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebProgressBar.animationDuration">
		/// Returns the length in milliseconds of the animations.
	    ///</summary>
	    ///<value type="Number" integer="true"></value>
		return this._get_value($IG.WebProgressBarProps.AnimationDuration);
	},
	

	

	get_remainingValue: function(percent)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebProgressBar.remainingValue">
		/// Returns the unfilled value, either as a percentage (if percent is true) or as a quantity
	    ///</summary>
	    ///<param name="percent" type="Boolean">Whether to return unfilled value as percentage or not</param>
		///<returns type="Number"></returns>

		var rval = this.get_maximum() - this.get_progressValue();
		if (!percent)
		{
			return rval;
		}
		return 100 * rval / (this.get_maximum() - this.get_minimum());
	},

	get_formattedLabel: function(formatString)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebProgressBar.formattedLabel">
		/// Returns the formatted label string with the current values inserted
	    ///</summary>
	    ///<param name="formatString" type="String">The format string to use for the label</param>
		///<returns type="String"></returns>

		var label;
		if (formatString == null)
			label = this._get_TokenizedLabelFormat();
		else
			label = this._tokenize(formatString);

		var max = this.get_maximum();
		var min = this.get_minimum();
		var val = this.get_progressValue();
		var val_perc = Math.floor((100 * (val - min) / (max - min))); //value percent
		var rval = max - val; //remaining value
		var rval_perc = 100 - val_perc; //remaining value percent

		label = String.format(label, val, val_perc, rval, rval_perc, min, max);
		return label;
	},

	get_formattedTooltip: function(formatString)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebProgressBar.formattedTooltip">
		/// Returns the formatted tooltip string with the current values inserted
	    ///</summary>
	    ///<param name="formatString" type="String">The format string to use for the tooltip</param>
	    ///<returns type="String"></returns>

		var tooltip;
		if (formatString == null)
			tooltip = this._get_TokenizedTooltipFormat();
		else
			tooltip = this._tokenize(formatString);

		var max = this.get_maximum();
		var min = this.get_minimum();
		var val = this.get_progressValue();
		var val_perc = Math.floor((100 * (val - min) / (max - min))); //value percent
		var rval = max - val; //remaining value
		var rval_perc = 100 - val_perc; //remaining value percent

		tooltip = String.format(tooltip, val, val_perc, rval, rval_perc, min, max);
		return tooltip;
	},

	reset_progressValue: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebProgressBar.reset_progressValue">
		/// Resets the Value property of the control and then calls _snapToInterval to start the control update process.
		///</summary>
		var oldval = this.get_progressValue();
		var args = this._raiseClientEvent('ProgressChanging', 'ProgressChanging', null, null, oldval, this.get_minimum());
		if (args == null || !args.get_cancel())
		{
			this._set_value($IG.WebProgressBarProps.Value, this.get_minimum());
			this._snapToInterval(false);
			this._raiseClientEvent('ProgressChanged', 'ProgressChanged', null, null, oldval, this.get_minimum());
		}
	},
	

	

	_setFillPosition: function()
	{
		///<summary>
		/// Sets fill bar position(percent) based on the _fill variable
		///</summary> 
		if (this._animate && !this._initialize)  //Don't animate on initialization
		{
			var newLeft = null;
			var newTop = null;
			if (this.get_orientation() == $IG.Orientation.Horizontal)
				newLeft = this._offset;
			else
				newTop = this._offset;

			this._animation = new $IG.FillAnimation(this, this.get_fillMode(), this._f_label, this._b_label, this._fillDiv, this._newFlabTop, this._newFlabLeft, -newTop, -newLeft, newTop, newLeft, this._newBlabTop, this._newBlabLeft)
			this._animation.play(this.get_animationDuration());  //Animation will take this number of ms
		}
		else
		{
			//Set new styles directly if not animating.
			if (this.get_orientation() == $IG.Orientation.Horizontal)
			{

				this._f_label.parentNode.style.left = -this._offset + "px";
				if ($util.IsIE && !$util.IsIE8)
					this._b_label.parentNode.style.left = "0px"; //-this._offset / 2 + "px";
				
				if (this.get_fillMode() == $IG.FillMode.Expose)
				{
					this._fillDiv.style.left = this._offset + "px";
					this._fillDiv.parentNode.style.left = -this._offset + "px";
				}
				else
				{
					this._fillDiv.style.left = -this._offset + "px";
					this._fillDiv.parentNode.style.left = "0px";
				}
			}
			else
			{
				this._f_label.parentNode.style.top = -this._offset + "px";
				if ($util.IsIE && !$util.IsIE8)
				{
					this._b_label.parentNode.style.top = "0px"; //-this._offset / 2 + "px";
					this._b_label.parentNode.style.left = "0px";
				}
				if (this.get_fillMode() == $IG.FillMode.Expose)
				{
					this._fillDiv.style.top = this._offset + "px";
					this._fillDiv.parentNode.style.top = -this._offset + "px";
				}
				else
				{
					this._fillDiv.style.top = -this._offset + "px";
					this._fillDiv.parentNode.style.top = "0px";
				}

			}
			this._moveLabel();
		}

		this._newFlabTop = null;
		this._newFlabLeft = null;
		this._newBlabLeft = null;
		this._newBlabTop = null;
	},

	_moveLabel: function()
	///<summary>
	/// Assigns new positional style values to the labels.
	///</summary>
	{
		this._f_label.style.left = this._newFlabLeft + "px";
		this._f_label.style.top = this._newFlabTop + "px";
		this._b_label.style.left = this._newBlabLeft + "px";
		this._b_label.style.top = this._newBlabTop + "px";
	},

	_snapToInterval: function()
	{
		///<summary>
		/// Called by set_Value(), sets _fill variable based on SnapInterval and Value properties, triggers ProgressChanging event if _fill changed
		///</summary>
		this._oldoffset = this._offset;
		var _fill;
		var size = (this.get_orientation() == $IG.Orientation.Vertical) ? this._fillDiv.offsetHeight : this._fillDiv.offsetWidth;
		var percent = 100 * (this.get_progressValue() - this.get_minimum()) / (this.get_maximum() - this.get_minimum());
		if (percent < 100 && percent > 0)
		{
			var snap = this.get_snapInterval();
			var snapval = parseInt(snap)
			if (snapval > 0) //If SnapInterval is zero or below then there is no snapping.
			{
				if (snap.match("%"))
				{
					var temp = Math.floor(percent / snapval);
					_fill = ((temp * snapval) / 100) * size;
				}
				else
				{
					var pixels = (percent / 100) * size;
					var temp = Math.floor(pixels / snapval);
					_fill = temp * snapval;
				}
			}
			else
			{
				_fill = (percent / 100) * size;
			}
		}
		else if (percent >= 100)
		{
			_fill = size;
		}
		else
		{
			_fill = 0;
		}

		_fill = Math.round(_fill);   //To avoid floating point inaccuracies

		this._offset = size - _fill;
		if (this.get_fillDirection() == $IG.FillDirection.FromRightOrBottom)
		{
			this._offset = -this._offset;
		}

		this._animate = true;  //Start as true, if change is smaller than the threshold it will be set to false in _updateLabel

		this._updateLabel(); //Label may need to change even if bar position remains constant.

		if (this._oldoffset != this._offset)
		{
			this._setFillPosition();  //No point in recalculating the fill if it's the same value.
		}

	},

	isAnimating: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebProgressBar.isAnimating">
		/// Returns true if the animation is currently running.
	    /// </summary>
		///<returns type="Boolean"></returns>

		if (this._animation == null)
		{
			return false;
		}
		else
		{
			return this._animation.get_isAnimating();
		}
	},

	_assignCurrentOffsets: function()
	{
		///<summary>
		/// Sets this._FlabTop and this._FlabLeft based on Orientation, FillDirection, and this._offset
		///</summary>
		if (this.get_orientation() == $IG.Orientation.Horizontal)
		{
			this._newFlabLeft = this._offset;  //_newFlabLeft is the new Foreground Label Left style value

			//If change is small, don't animate.
			if ((Math.abs(this._offset + this._fillDiv.offsetLeft) < this.get_animationThreshold()) || (this.get_animationThreshold() < 0))
			{
				this._animate = false;
			}
		}
		else
		{
			this._newFlabTop = this._offset;  //_newFlabTop is the new Foreground Label Top style value

			//If change is small, don't animate.
			if ((Math.abs(this._offset + this._fillDiv.offsetTop) < this.get_animationThreshold()) || (this.get_animationThreshold() < 0))
			{
				this._animate = false;
			}
		}

	},

	_updateLabel: function()
	{
		///<summary>
		/// Updates the label value and position on the browser
		///</summary>
		var label = this.get_formattedLabel();
		var tooltip = this.get_formattedTooltip();
		if (this._b_label.firstChild)
		{
			this._b_label.firstChild.nodeValue = label;
			this._f_label.firstChild.nodeValue = label;
		}

		this._element.title = tooltip;
		this._alignLabel();
	},

	_alignLabel: function()
	{
		///<summary>
		/// Aligns the label based on the LabelAlign property.  
		/// Assumes control enters function without any prior label alignment, meaning the label is in the top left.
		///</summary>

		var alignment = this.get_labelAlignment();
		var orientation = this.get_orientation();



		if (alignment == $IG.LabelAlignment.None)
		{
			this._b_label.style.display = "none";
			this._f_label.style.display = "none";
			this._newFlabTop = 0;
			this._newFlabLeft = 0;
			this._newBlabTop = 0;
			this._newBlabLeft = 0;
			return;
		}
		else
		{
			//Wipe out any display value of "none" that may have been there.
			this._b_label.style.display = "";
			this._f_label.style.display = "";
		}

		this._assignCurrentOffsets();

		var vertical = 0;
		var horizontal = 0;
		if (orientation == 1)
		{
			switch (alignment)
			{
				case $IG.LabelAlignment.LeftOrTop:
					vertical = 0;
					break;
				case $IG.LabelAlignment.Center:
					vertical = 1;
					break;
				case $IG.LabelAlignment.RightOrBottom:
					vertical = 2;
					break;
				default:
					vertical = -1;
			}
			horizontal = 1;

		}
		else
		{

			switch (alignment)
			{
				case $IG.LabelAlignment.LeftOrTop:
					horizontal = 0;
					break;
				case $IG.LabelAlignment.Center:
					horizontal = 1;
					break;
				case $IG.LabelAlignment.RightOrBottom:
					horizontal = 2;
					break;
				default:
					horizontal = -1
			}
			vertical = 1;

		}
		this._verticalAlign(vertical);
		this._horizontalAlign(horizontal);
	},

	_verticalAlign: function(alignment)
	{
		///<summary>
		/// Align label along the vertical axis.  This will set the "top" style value on both the fore and background labels
		///</summary>
		///<param name="alignment">An integer where 0 = Top, 1 = Middle, 2 = Bottom, 3 = Running</param>

		var diff; //Negative displacement in pixels from current position values
		var label_height = this._b_label.offsetHeight;
		var total_height = this._fillDiv.offsetHeight;
		if (alignment == 0) //Top
		{
			diff = 0;
		}
		else if (alignment == 1) //Middle
		{
			diff = (total_height - label_height) / 2;
		}
		else if (alignment == 2) //Bottom
		{
			diff = total_height - label_height;
		}
		else //Running
		{
			if (this.get_fillDirection() == $IG.FillDirection.FromLeftOrTop)
			{
				diff = total_height - this._newFlabTop;
				if (total_height < (diff + this._f_label.offsetHeight))
					diff = total_height - this._f_label.offsetHeight;
			}
			else
			{
				diff = -(this._newFlabTop + label_height);
				if (diff < 0)
					diff = 0;
			}
			this._newBlabTop = diff;  //_newBlabTop is the new Background Label Top style value
			//vertically oriented, need to maintain foreground label offset from its parent div.
			this._newFlabTop = (this._newFlabTop + diff);
			return;
		}
		this._newBlabTop = diff;  //_newBlabTop is the new Background Label Top style value
		if (this.get_orientation() == $IG.Orientation.Horizontal)
		{
			this._newFlabTop = diff;
		}
		else
		{
			//vertically oriented, then need to maintain foreground label offset from its parent div.
			this._newFlabTop = (this._newFlabTop + diff);
		}

	},

	_horizontalAlign: function(alignment)
	{
		///<summary>
		/// Align label along the horizontal axis.  This will set the "left" style value on both the fore and background labels
		///</summary>
		///<param name="alignment">An integer where 0 = Top, 1 = Middle, 2 = Bottom, 3 = Running</param>
		var diff; //Negative displacement in pixels from current position values
		var label_width = this._b_label.offsetWidth;
		var total_width = this._fillDiv.offsetWidth;
		if (alignment == 0) //Left
		{
			diff = 0;
		}
		else if (alignment == 1) //Center
		{
			diff = (total_width - label_width) / 2;
		}
		else if (alignment == 2) //Right
		{
			diff = total_width - label_width;
		}
		else //Running
		{
			if (this.get_fillDirection() == $IG.FillDirection.FromLeftOrTop)
			{
				diff = total_width - this._newFlabLeft;
				if (total_width < (diff + this._f_label.offsetWidth))
					diff = total_width - this._f_label.offsetWidth;
			}
			else
			{
				diff = -(this._newFlabLeft + label_width);
				if (diff < 0)
					diff = 0;
			}
			this._newBlabLeft = diff;  //_newBlabLeft is the new Background Label Left style value
			// horizontally oriented, need to maintain foreground label offset from its parent div.
			this._newFlabLeft = (this._newFlabLeft + diff);
			return;
		}
		this._newBlabLeft = diff;  //_newBlabLeft is the new Background Label Left style value
		if (this.get_orientation() == $IG.Orientation.Vertical)
		{
			this._newFlabLeft = diff;
		}
		else
		{
			//If horizontally oriented, then need to maintain foreground label offset from its parent div.
			this._newFlabLeft = (this._newFlabLeft + diff);
		}
	},

	_ResizeProgressBar: function(override)
	{
		//If the client height or width of the bar has changed we need to reset the progress of the progressbar.

		// Fix for bug: 128956 - Do not set the _clientWidth and _clientHeight for cases where the element gets hidden
		// and hence has offsetHeight and/or offsetWidth as zero
		var offsetHeight = this._element.offsetHeight, offsetWidth = this._element.offsetWidth;
		if ((offsetHeight && offsetWidth && (this._clientHeight != offsetHeight || this._clientWidth != offsetWidth)) || override) {
			this._snapToInterval();
			this._clientHeight = offsetHeight;
			this._clientWidth = offsetWidth;
		}
	},

	_get_TokenizedLabelFormat: function()
	{
		///<summary>
		/// Returns the LabelFormatString of the control.
		///</summary>
		return this._get_value($IG.WebProgressBarProps.TokenizedLabelFormatString);
	},

	_get_TokenizedTooltipFormat: function()
	{
		///<summary>
		/// Returns the LabelFormatString of the control.
		///</summary>
		return this._get_value($IG.WebProgressBarProps.TokenizedTooltipFormatString);
	},

	_tokenize: function(LabelFormatString)
	{
		///<summary>
		/// Removes the custom tokens and replaces them their equivalents.
		///</summary>

		var tokenizedLabelFormatString = LabelFormatString;
		var tokenMatcher;
		for (var i = 0; i < this._tokens.length; i++)
		{
			tokenMatcher = new RegExp(this._tokens[i].key, "gi");
			tokenizedLabelFormatString = tokenizedLabelFormatString.replace(tokenMatcher, this._tokens[i].value);
		}
		return tokenizedLabelFormatString;
	},

	dispose: function() {
	    ///<summary locid="M:J#Infragistics.Web.UI.WebProgressBar.dispose">Disposes of this WebProgressBar instance</summary>
		if (this._ResizeTimerId != null)
			this._ResizeTimerId = clearInterval(this._ResizeTimerId);

		$IG.WebProgressBar.callBaseMethod(this, "dispose");
	},

	

	

	
	_onDblclick: function(e)
	{
		this._onClick(e, true);
	},
	
	_onClick: function(e, dbl)
	{
		this._raiseClientEvent((dbl ? 'DoubleClick' : 'Click'), null, e);
	},
	
	_onMouseOver: function(e, dbl)
	{
		this._raiseClientEvent('MouseOver', null, e);
	},
	
	_onMouseOut: function(e, dbl)
	{
		this._raiseClientEvent('MouseOut', null, e);
	}

	
}

$IG.WebProgressBar.registerClass('Infragistics.Web.UI.WebProgressBar', $IG.ControlMain);

$IG.WebProgressBar.find = function (clientID)
{
	///<summary locid="M:J#Infragistics.Web.UI.WebProgressBar.find">Finds WebProgressBar by its client ID.</summary>
	///<param name="clientID" type="String">Client ID of the control to look for.</param>
	///<returns type="Infragistics.Web.UI.WebProgressBar">Reference to the WebProgressBar control object that corresponds to specified client ID.</returns>
};

$IG.WebProgressBar.from = function (obj)
{
	///<summary locid="M:J#Infragistics.Web.UI.WebProgressBar.from">Casts passed in object to the WebProgressBar type.</summary>
	///<param name="obj">Object to convert to the WebProgressBar type.</param>
	///<returns type="Infragistics.Web.UI.WebProgressBar">Reference to the same object that is passed in, only type converted to the WebProgressBar type.</returns>
};


$IG.ProgressChangingEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.ProgressChangingEventArgs">
	/// EventArgs that contain the old and new fill percentages.
	/// </summary>
	$IG.ProgressChangingEventArgs.initializeBase(this);
}
$IG.ProgressChangingEventArgs.prototype =
{
	getCurrentFill: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ProgressChangingEventArgs.getCurrentFill">
		/// Returns the current fill value of the bar.
	    /// </summary>
	    /// <returns type="Number" />
		return this._props[2];
	},
	getNewFill: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ProgressChangingEventArgs.getNewFill">
		/// Returns the new fill value of the bar.
	    /// </summary>
	    /// <returns type="Number" />
		return this._props[3];
	}
}
$IG.ProgressChangingEventArgs.registerClass('Infragistics.Web.UI.ProgressChangingEventArgs', $IG.CancelEventArgs);

$IG.ProgressChangedEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.ProgressChangedEventArgs">
	/// EventArgs that contain the old and new fill percentages.
	/// </summary>
	$IG.ProgressChangedEventArgs.initializeBase(this);
}
$IG.ProgressChangedEventArgs.prototype =
{
	getOldFill: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ProgressChangedEventArgs.getOldFill">
		/// Returns the old fill value of the bar.
	    /// </summary>
	    /// <returns type="Number" />
		return this._props[2];
	},
	getNewFill: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ProgressChangedEventArgs.getNewFill">
		/// Returns the new fill value of the bar.
	    /// </summary>
	    /// <returns type="Number" />
		return this._props[3];
	}
}
$IG.ProgressChangedEventArgs.registerClass('Infragistics.Web.UI.ProgressChangedEventArgs', $IG.EventArgs);




$IG.FillAnimation = function(elem, fillMode, f_label, b_label, fillDiv, fL_endTop, fL_endLeft, fLpar_endTop, fLpar_endLeft, fillValue_endTop, fillValue_endLeft, bL_endTop, bL_endLeft)
{
	$IG.FillAnimation.initializeBase(this, [elem]);
	this._f_label = f_label;  //Foreground label span
	this._b_label = b_label;  //Background label span
	this._fillDiv = fillDiv;  //Fill Div
	this._fillMode = fillMode; //Fill Mode
	this._fL_endTop = fL_endTop;   //Ending Top value of foreground label
	this._fL_endLeft = fL_endLeft; //Ending Left value of foreground label
	this._fillValue_endTop = fillValue_endTop;   //Ending top value of Fill Div
	this._fillValue_endLeft = fillValue_endLeft; //Ending left value of Fill Div
	this._bL_endTop = bL_endTop;  //Ending Top value of background label
	this._bL_endLeft = bL_endLeft; //Ending Left value of background label
	this._fLpar_endTop = fLpar_endTop;   //Ending top value of the parent div for the foreground label
	this._fLpar_endLeft = fLpar_endLeft; //Ending left value of the parent div for the foreground label
};

$IG.FillAnimation.prototype =
{
	_init: function()
	///<summary>
	/// Initializes starting values for the animation based on current browser offsets
	///</summary>
	{
		this._fL_startTop = parseInt(this._f_label.offsetTop);
		this._fL_startLeft = parseInt(this._f_label.offsetLeft);
		this._fLpar_startTop = parseInt(this._f_label.parentNode.offsetTop);
		this._fLpar_startLeft = parseInt(this._f_label.parentNode.offsetLeft);
		this._fill_startTop = parseInt(this._fillDiv.offsetTop);
		this._fill_startLeft = parseInt(this._fillDiv.offsetLeft);
		this._fillPar_startTop = parseInt(this._fillDiv.parentNode.offsetTop);
		this._fillPar_startLeft = parseInt(this._fillDiv.parentNode.offsetLeft);
		this._bL_startTop = parseInt(this._b_label.offsetTop);
		this._bL_startLeft = parseInt(this._b_label.offsetLeft);
	},
	_calc2: function(start, end)
	///<summary>
	/// Calculates the next value of an animation.
	///</summary>
	///<param name="start">Starting value of the animation</param>
	///<param name="end">Ending value of the animation</param>
	{
		return this._calc(this._element.get_animationType(), this._time, start, end, this._duration);
	},

	play: function(duration)
	///<summary locid="M:J#Infragistics.Web.UI.ProgressChangedEventArgs.play">
	/// Overrides the play function of the animation framework to allow the setting of duration.
	///</summary>
	///<param name="duration">Length of animation in milliseconds.</param>
	{
		this.set_duration(duration);
		$IG.FillAnimation.callBaseMethod(this, "play", [duration]);
	},

	_next: function()
	{
		var newTop, newLeft;
		if (this._fL_endTop != null)
		{
			newTop = this._calc2(this._fL_startTop, this._fL_endTop);
			this._f_label.style.top = newTop + "px";
		}

		if (this._fLpar_endTop != null)
		{
			newTop = this._calc2(this._fLpar_startTop, this._fLpar_endTop);
			this._f_label.parentNode.style.top = newTop + "px";
		}

		if (this._fillValue_endTop != null)
		{
			if (this._fillMode == $IG.FillMode.Expose)
			{
				newTop = this._calc2(this._fill_startTop, this._fillValue_endTop);
				this._fillDiv.style.top = newTop + "px";
				this._fillDiv.parentNode.style.top = -(newTop) + "px";
			} else
			{
				newTop = this._calc2(this._fill_startTop, -this._fillValue_endTop);
				this._fillDiv.parentNode.style.top = "0px";
				this._fillDiv.style.top = newTop + "px";
			}
		}

		if (this._bL_endTop != null)
		{
			newTop = this._calc2(this._bL_startTop, this._bL_endTop);
			this._b_label.style.top = newTop + "px";
		}

		if (this._fL_endLeft != null)
		{
			newLeft = this._calc2(this._fL_startLeft, this._fL_endLeft);
			this._f_label.style.left = newLeft + "px";
		}

		if (this._fLpar_endLeft != null)
		{
			newLeft = this._calc2(this._fLpar_startLeft, this._fLpar_endLeft);
			this._f_label.parentNode.style.left = newLeft + "px";
		}

		if (this._fillValue_endLeft != null)
		{
			if (this._fillMode == $IG.FillMode.Expose)
			{
				newLeft = this._calc2(this._fill_startLeft, this._fillValue_endLeft);
				this._fillDiv.style.left = newLeft + "px";
				this._fillDiv.parentNode.style.left = -(newLeft) + "px";
			} else
			{
				newLeft = this._calc2(this._fill_startLeft, -this._fillValue_endLeft);
				this._fillDiv.parentNode.style.left = "0px";
				this._fillDiv.style.left = newLeft + "px";
			}
		}

		if (this._bL_endLeft != null)
		{
			newLeft = this._calc2(this._bL_startLeft, this._bL_endLeft);
			this._b_label.style.left = newLeft + "px";
		}

		if (this._time >= this._duration)
			this.stop();
	}

};
$IG.FillAnimation.registerClass("Infragistics.Web.UI.FillAnimation", $IG.AnimationBase);





$IG.FillDirection = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.FillDirection">
	/// Direction that the bar will fill
    ///</summary>
    /// <field name="FromLeftOrTop" type="Number" integer="true" static="true">The fill bar will move from the left or the top depending on orientation.</field>
    /// <field name="FromRightOrBottom" type="Number" integer="true" static="true">The fill bar will move from the right or the bottom depending on orientation.</field>
}
$IG.FillDirection.prototype =
{
	///<summary>
	/// The fill bar will move from the left or the top depending on orientation.
	///</summary>
	FromLeftOrTop: 0,
	///<summary>
	/// The fill bar will move from the right or the bottom depending on orientation.
	///</summary>
	FromRightOrBottom: 1
};
$IG.FillDirection.registerEnum("Infragistics.Web.UI.FillDirection");



$IG.FillMode = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.FillMode">
	/// Method of fill
	///</summary>
    /// <field name="Expose" type="Number" integer="true" static="true">Fill image will remain stationary and be revealed gradually.</field>
    /// <field name="Advance" type="Number" integer="true" static="true">Fill image will move across the bar.</field>
}
$IG.FillMode.prototype =
{
	///<summary>
	/// Fill image will remain stationary and be revealed gradually.
	///</summary>
	Expose: 0,
	///<summary>
	/// Fill image will move across the bar.
	///</summary>
	Advance: 1
};
$IG.FillMode.registerEnum("Infragistics.Web.UI.FillMode");



$IG.LabelAlignment = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.LabelAlignment">
	/// Alignment of the label within the bar.
	///</summary>
    /// <field name="None" type="Number" integer="true" static="true">No label is displayed..</field>
    /// <field name="LeftOrTop" type="Number" integer="true" static="true">Label is displayed on the left or top of the control.</field>
    /// <field name="Center" type="Number" integer="true" static="true">Label is displayed centered.</field>
    /// <field name="RightOrBottom" type="Number" integer="true" static="true">Label is displayed on the right or bottom of the control.</field>
    /// <field name="Running" type="Number" integer="true" static="true">Label is at the top of the control and if horizontal then it will run along the edge
    /// of the progress.  If Vertical then it will appear as TopCenter.</field>
}
$IG.LabelAlignment.prototype =
{
	/// <summary>
	/// No label is displayed.
	/// </summary>
	None: 0,
	
	/// <summary>
	/// Label is displayed on the left or top of the control.
	/// </summary>
	LeftOrTop: 1,
	
	/// <summary>
	/// Label is displayed centered.
	/// </summary>
	Center: 2,
	
	/// <summary>
	/// Label is displayed on the right or bottom of the control.
	/// </summary>
	RightOrBottom: 3,
	
	/// <summary>
	/// Label is at the top of the control and if horizontal then it will run along the edge
	/// of the progress.  If Vertical then it will appear as TopCenter.
	/// </summary>
	Running: 4	
	
};
$IG.LabelAlignment.registerEnum("Infragistics.Web.UI.LabelAlignment");



$IG.WebProgressBarProps = new function()
{
	this.Orientation = [$IG.ControlMainProps.Count + 0, 0];
	this.FillDirection = [$IG.ControlMainProps.Count + 1, 0];
	this.LabelFormatString = [$IG.ControlMainProps.Count + 2, "{1}%"];
	this.TokenizedLabelFormatString = [$IG.ControlMainProps.Count + 3, "{1}%"];
	this.LabelAlignment = [$IG.ControlMainProps.Count + 4, 1];
	this.Value = [$IG.ControlMainProps.Count + 5, 0.0];
	this.Minimum = [$IG.ControlMainProps.Count + 6, 0.0];
	this.Maximum = [$IG.ControlMainProps.Count + 7, 100.0];
	this.SnapInterval = [$IG.ControlMainProps.Count + 8, 0];
	this.FillMode = [$IG.ControlMainProps.Count + 9, 0];
	this.AnimationThreshold = [$IG.ControlMainProps.Count + 10, 5.0];
	this.AnimationType = [$IG.ControlMainProps.Count + 11, $IG.AnimationEquationType.EaseIn];
	this.AnimationDuration = [$IG.ControlMainProps.Count + 12, 200];
	this.Tooltip = [$IG.ControlMainProps.Count + 13, ""];
	this.TokenizedTooltipFormatString = [$IG.ControlMainProps.Count + 14, "{1}%"];
	this.Control = $IG.ControlMainProps.Count + 15;
};

