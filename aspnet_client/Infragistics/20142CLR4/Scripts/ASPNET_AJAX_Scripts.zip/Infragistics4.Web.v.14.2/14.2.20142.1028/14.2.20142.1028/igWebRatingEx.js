/*
* igWebRatingEx.js
* Version 14.2.20142.1028
* Copyright(c) 2001-2014 Infragistics, Inc. All Rights Reserved.
*/


$IG.WebRating.prototype._valueFromPoint = function(x, y)
{
	var importantVal = this.__isHor ? x : y;
	var val = (importantVal + 1) / this.__critLength;
	if (this.__isRev)
		val = this.get_itemCount() - val;
	return val;
}

$IG.WebRating.prototype._baseInitialize = $IG.WebRating.prototype.initialize;
$IG.WebRating.prototype.initialize = function()
{
	this._baseInitialize();

	if (!this.get_enableHtml5Rendering())
		return;
	this._canvas = this._elements['canvas'];
	this._context = this._canvas.getContext('2d');
	this._spanCss = this._get_clientOnlyValue("wrsc") + ' ';
	var enabled = this.get_enabled();

	if (this.get_enableAnimations())
	{
		this._canvasHoverAnimation = new $IG.CanvasFadeAnimation(this._canvas, this);
		this._canvasHoverAnimation.set_duration(this._hoverAnimationDuration);
		this._canvasSlideAnimation = new $IG.CanvasSlideAnimation(this._canvas, this);
		this._canvasSlideAnimation.set_duration(1000);
		this._canvasKeyboardFadeAnimation = new $IG.CanvasKeyBoardFadeAnimation(this._hoveredDiv, this);
		this._canvasKeyboardFadeAnimation.set_duration(500);
	}

	this._span = document.createElement("span");
	this._span.style.display = "none";
	this._element.appendChild(this._span);

	if (this.__isCustom)
	{
		this._customClasses = [];
		this._customSelClasses = [];
		this._customHovClasses = [];
		this._imgs = [];
		this._imgsS = [];
		this._imgsH = [];
		values = this._get_clientOnlyValue("wriic");
		if (values.length > 0)
		{
			values = values.split('|');
			for (var x = 0; x < values.length; ++x)
			{
				this._customClasses[x] = values[x];
				if (this._customClasses[x].length == 0)
					this._customClasses[x] = this._ratingImage.get_imageCss();
				if (this._customClasses[x].length == 0)
					this._customClasses[x] = this._ratingImage._defaultEmpty;
				this._span.className = this._spanCss + this._customClasses[x];
				this._imgs[x] = new Image();
				this._imgs[x].src = this._imageFromSpan();
				this._imgs[x]._offsetX = this._offsetFromSpan(true);
				this._imgs[x]._offsetY = this._offsetFromSpan(false);
			}
		}
		values = this._get_clientOnlyValue("wrisc");
		if (values.length > 0)
		{
			values = values.split('|');
			for (var x = 0; x < values.length; ++x)
			{
				this._customSelClasses[x] = values[x];
				if (this._customSelClasses[x].length == 0)
					this._customSelClasses[x] = this._ratingImage.get_selectedImageCss();
				if (this._customSelClasses[x].length == 0)
					this._customSelClasses[x] = this._ratingImage._defaultSelected;
				this._span.className = this._spanCss + this._customSelClasses[x];
				this._imgsS[x] = new Image();
				this._imgsS[x].src = this._imageFromSpan();
				this._imgsS[x]._offsetX = this._offsetFromSpan(true);
				this._imgsS[x]._offsetY = this._offsetFromSpan(false);
			}
		}
		values = this._get_clientOnlyValue("wrihc");
		if (values.length > 0)
		{
			values = values.split('|');
			for (var x = 0; x < values.length; ++x)
			{
				this._customHovClasses[x] = values[x];
				if (this._customHovClasses[x].length == 0)
					this._customHovClasses[x] = this._ratingImage.get_hoveredImageCss();
				if (this._customHovClasses[x].length == 0)
					this._customHovClasses[x] = this._ratingImage._defaultHovered;
				this._span.className = this._spanCss + this._customHovClasses[x];
				this._imgsH[x] = new Image();
				this._imgsH[x].src = this._imageFromSpan();
				this._imgsH[x]._offsetX = this._offsetFromSpan(true);
				this._imgsH[x]._offsetY = this._offsetFromSpan(false);
			}
		}
	}
	if (enabled)
		$addHandlers(this._canvas, { 'mousedown': this._onClick5, 'mouseover': this._onMouseOver5, 'mouseout': this._onMouseOut5, 'mousemove': this._onMouseMove5 }, this);
	this._onWindowLoadedHandler = Function.createDelegate(this, this._onWindowLoaded);
	$addHandler(window, 'load', this._onWindowLoadedHandler);
	this._initEmptyImg();
	this._initSelectedImg();
	this._initHoveredImg();
	
	if ($util.IsChrome || $util.IsIE9Plus)
		$addHandler(this._emptyImg, 'load', this._onWindowLoadedHandler);
	this._selectedOpacity = 1;
	this._hoveredOpacity = 1;
}

$IG.WebRating.prototype._initEmptyImg = function()
{
	this._emptyImg = new Image();
	this._span.className = this._spanCss;
	if (this.get_enabled())
	{
		if (this._ratingImage.get_imageCss().length > 0)
			this._span.className += this._ratingImage.get_imageCss();
		else
			this._span.className += this._ratingImage._defaultEmpty;
	}
	else
	{
		if (this._ratingImage.get_disabledImageCss().length > 0)
			this._span.className += this._ratingImage.get_disabledImageCss();
		else
			this._span.className += this._ratingImage._defaultDisabledEmpty;
	}
	this._emptyImg.src = this._imageFromSpan();
	this._emptyImg._offsetX = this._offsetFromSpan(true);
	this._emptyImg._offsetY = this._offsetFromSpan(false);
}

$IG.WebRating.prototype._initSelectedImg = function()
{
	this._selectedImg = new Image();
	this._span.className = this._spanCss;
	if (this.get_enabled())
	{
		if (this._ratingImage.get_selectedImageCss().length > 0)
			this._span.className += this._ratingImage.get_selectedImageCss();
		else
			this._span.className += this._ratingImage._defaultSelected;
	}
	else
	{
		if (this._ratingImage.get_disabledSelectedImageCss().length > 0)
			this._span.className += this._ratingImage.get_disabledSelectedImageCss();
		else
			this._span.className += this._ratingImage._defaultDisabledSelected;
	}
	this._selectedImg.src = this._imageFromSpan();
	this._selectedImg._offsetX = this._offsetFromSpan(true);
	this._selectedImg._offsetY = this._offsetFromSpan(false);
}

$IG.WebRating.prototype._initHoveredImg = function()
{
	this._hoveredImg = new Image();
	this._span.className = this._spanCss;
	if (this._ratingImage.get_hoveredImageCss().length > 0)
		this._span.className += this._ratingImage.get_hoveredImageCss();
	else
		this._span.className += this._ratingImage._defaultHovered;
	this._hoveredImg.src = this._imageFromSpan();
	this._hoveredImg._offsetX = this._offsetFromSpan(true);
	this._hoveredImg._offsetY = this._offsetFromSpan(false);
}

$IG.WebRating.prototype._onWindowLoaded = function(e)
{
	this._drawEmpty();
	this._drawSelected(this._lengthValFromRealVal(this._oldValue));
	this._adjustCanvasTooltip(this._oldValue);
}

$IG.WebRating.prototype._baseDispose = $IG.WebRating.prototype.dispose;
$IG.WebRating.prototype.dispose = function()
{
	if (this._element == null)
		return;

	this._baseDispose();

	if (!this.get_enableHtml5Rendering() || typeof(this._canvas) == 'undefined')
		return;

	$clearHandlers(this._canvas);

	delete this._canvas;
	delete this._context;
	delete this._emptyImg;
	delete this._selectedImg;
	delete this._hoveredImg;
	delete this._span;
	delete this._selectedOpacity;
	delete this._hoveredOpacity;
	delete this._onBodyLoadedHandler;

	if (this._canvasHoverAnimation)
	{
		this._canvasHoverAnimation.dispose();
		delete this._canvasHoverAnimation;
	}
	if (this._canvasSlideAnimation)
	{
		this._canvasSlideAnimation.dispose();
		delete this._canvasSlideAnimation;
	}
	if (this._canvasKeyboardFadeAnimation)
	{
		this._canvasKeyboardFadeAnimation.dispose();
		delete this._canvasKeyboardFadeAnimation;
	}

	if (this._imgs)
	{
		for (var x = 0; x < this._imgs.length; ++x)
			delete this._imgs[x];
		delete this._imgs;
	}
	if (this._imgS)
	{
		for (var x = 0; x < this._imgS.length; ++x)
			delete this._imgS[x];
		delete this._imgS;
	}
	if (this._imgsH)
	{
		for (var x = 0; x < this._imgsH.length; ++x)
			delete this._imgsH[x];
		delete this._imgsH;
	}
}

$IG.WebRating.prototype._imageFromSpan = function()
{
	var url = $util.getStyleValue(null, "backgroundImage", this._span);
	url = url.substring(url.indexOf('(') + 1, url.lastIndexOf(')'));
	url = url.replace('"', '').replace('"', '');
	return url;
}

$IG.WebRating.prototype._offsetFromSpan = function(getX)
{
	var prop = "backgroundPosition", offset = $util.getStyleValue(null, prop, this._span);
	if (offset && offset.length > 2)
		offset = offset.split(' ')[getX ? 0 : 1];
	if (!offset)
	{
		offset = $util.getStyleValue(null, prop + (getX ? "X" : "Y"), this._span);
		if (!offset)
			return 0;
	}
	offset = parseInt(offset, 10);
	return !offset || isNaN(offset) ? 0 : -offset;
}

$IG.WebRating.prototype._drawEmpty = function()
{
	if (!this._canvas || !this._context)
		return;
	var index = this.__isRev ? this.get_itemCount() - 1 : 0;
	var increment = this.__isRev ? -1 : 1;
	if (this.__isHor)
	{
		for (var x = 0; x < this.get_itemCount(); ++x)
		{
			if (this.__isCustom)
			{
				this._emptyImg = this._imgs[x];
			}
			this._context.drawImage(this._emptyImg, this._emptyImg._offsetX, this._emptyImg._offsetY, this.get_imageWidth(), this.get_imageHeight(), index * this.__critLength, 0, this.get_imageWidth(), this.get_imageHeight());
			index += increment;
		}
	}
	else
	{
		for (var x = 0; x < this.get_itemCount(); ++x)
		{
			if (this.__isCustom)
			{
				this._emptyImg = this._imgs[x];
			}
			this._context.drawImage(this._emptyImg, this._emptyImg._offsetX, this._emptyImg._offsetY, this.get_imageWidth(), this.get_imageHeight(), 0, index * this.__critLength, this.get_imageWidth(), this.get_imageHeight());
			index += increment;
		}
	}
}

$IG.WebRating.prototype._drawSelected = function(valWidth)
{
	if (!this._canvas || !this._context)
		return;
	if (!valWidth)
		valWidth = this._lengthValFromRealVal(this.get_value());
	if (this._selectedOpacity == 0 || valWidth == 0)
		return;
	var under = this._underForVal(valWidth);
	var remaining = valWidth - under;
	var index = this.__isRev ? this.get_itemCount() - 1 : 0;
	var increment = this.__isRev ? -1 : 1;
	this._context.globalAlpha = this._selectedOpacity;
	if (this.__isHor)
	{
		if (this.get_enableContinuousSelection())
		{
			for (var x = 0; x < under; ++x)
			{
				if (this.__isCustom)
				{
					this._selectedImg = this._imgsS[x];
				}
				var startX = 0;
				if (this.__isRev)
					startX = (this.get_itemCount() - x - 1) * this.__critLength;
				else
					startX = index * this.__critLength;
				this._context.drawImage(this._selectedImg, this._selectedImg._offsetX, this._selectedImg._offsetY, this.get_imageWidth(), this.get_imageHeight(), startX, 0, this.get_imageWidth(), this.get_imageHeight());
				index += increment;
			}
		}
		var width = Math.round(remaining * this.__critLength);
		
		if (width == 0)
			return;
		if (this.__isCustom)
		{
			this._selectedImg = this._imgsS[under];
		}
		if (this.__isRev)
			this._context.drawImage(this._selectedImg, this._selectedImg._offsetX + this.get_imageWidth() - width, this._selectedImg._offsetY, width, this.get_imageHeight(), Math.round((this.get_itemCount() - valWidth) * this.__critLength), 0, width, this.get_imageHeight());
		else
			this._context.drawImage(this._selectedImg, this._selectedImg._offsetX, this._selectedImg._offsetY, width, this.get_imageHeight(), under * this.__critLength, 0, width, this.get_imageHeight());
	}
	else
	{
		if (this.get_enableContinuousSelection())
		{
			for (var x = 0; x < under; ++x)
			{
				if (this.__isCustom)
				{
					this._selectedImg = this._imgsS[x];
				}
				var startY = 0;
				if (this.__isRev)
					startY = (this.get_itemCount() - x - 1) * this.__critLength;
				else
					startY = index * this.__critLength;
				this._context.drawImage(this._selectedImg, this._selectedImg._offsetX, this._selectedImg._offsetY, this.get_imageWidth(), this.get_imageHeight(), 0, startY, this.get_imageWidth(), this.get_imageHeight());
				index += increment;
			}
		}
		var height = Math.round(remaining * this.__critLength);
		
		if (height == 0)
			return;
		if (this.__isCustom)
		{
			this._selectedImg = this._imgsS[under];
		}
		if (this.__isRev)
			this._context.drawImage(this._selectedImg, this._selectedImg._offsetX, this._selectedImg._offsetY + this.get_imageHeight() - height, this.get_imageWidth(), height, 0, Math.round((this.get_itemCount() - valWidth) * this.__critLength), this.get_imageWidth(), height);
		else
			this._context.drawImage(this._selectedImg, this._selectedImg._offsetX, this._selectedImg._offsetY, this.get_imageWidth(), height, 0, under * this.__critLength, this.get_imageWidth(), height);
	}
	this._context.globalAlpha = 1;
}

$IG.WebRating.prototype._drawHovered = function(valWidth)
{
	if (!this._canvas || !this._context)
		return;
	if (valWidth == 0)
		return;
	var under = this._underForVal(valWidth);
	var remaining = valWidth - under;
	var index = this.__isRev ? this.get_itemCount() - 1 : 0;
	var increment = this.__isRev ? -1 : 1;
	this._context.globalAlpha = this._hoveredOpacity;
	if (this.__isHor)
	{
		if (this.get_enableContinuousSelection())
		{
			for (var x = 0; x < under; ++x)
			{
				if (this.__isCustom)
				{
					this._hoveredImg = this._imgsH[x];
				}
				var startX = 0;
				if (this.__isRev)
					startX = (this.get_itemCount() - x - 1) * this.__critLength;
				else
					startX = x * this.__critLength;
				this._context.drawImage(this._hoveredImg, this._hoveredImg._offsetX, this._hoveredImg._offsetY, this.get_imageWidth(), this.get_imageHeight(), startX, 0, this.get_imageWidth(), this.get_imageHeight());
			}
		}
		var width = Math.round(remaining * this.__critLength);
		
		if (width == 0)
			return;
		if (this.__isCustom)
		{
			this._hoveredImg = this._imgsH[under];
		}
		if (this.__isRev)
			this._context.drawImage(this._hoveredImg, this._hoveredImg._offsetX + this.get_imageWidth() - width, this._hoveredImg._offsetY, width, this.get_imageHeight(), Math.round((this.get_itemCount() - valWidth) * this.__critLength), 0, width, this.get_imageHeight());
		else
			this._context.drawImage(this._hoveredImg, this._hoveredImg._offsetX, this._hoveredImg._offsetY, width, this.get_imageHeight(), under * this.__critLength, 0, width, this.get_imageHeight());
	}
	else
	{
		if (this.get_enableContinuousSelection())
		{
			for (var x = 0; x < under; ++x)
			{
				if (this.__isCustom)
				{
					this._hoveredImg = this._imgsH[x];
				}
				var startY = 0;
				if (this.__isRev)
					startY = (this.get_itemCount() - x - 1) * this.__critLength;
				else
					startY = x * this.__critLength;
				this._context.drawImage(this._hoveredImg, this._hoveredImg._offsetX, this._hoveredImg._offsetY, this.get_imageWidth(), this.get_imageHeight(), 0, startY, this.get_imageWidth(), this.get_imageHeight());
			}
		}
		var height = Math.round(remaining * this.__critLength);
		
		if (height == 0)
			return;
		if (this.__isCustom)
		{
			this._hoveredImg = this._imgsH[under];
		}
		if (this.__isRev)
			this._context.drawImage(this._hoveredImg, this._hoveredImg._offsetX, this._hoveredImg._offsetY + this.get_imageHeight() - height, this.get_imageWidth(), height, 0, Math.round((this.get_itemCount() - valWidth) * this.__critLength), this.get_imageWidth(), height);
		else
			this._context.drawImage(this._hoveredImg, this._hoveredImg._offsetX, this._hoveredImg._offsetY, this.get_imageWidth(), height, 0, under * this.__critLength, this.get_imageWidth(), height);
	}
	this._context.globalAlpha = 1;
}

$IG.WebRating.prototype._onClick5 = function(e)
{
	if (this.get_readOnly() || !this._isHovered)
		return;
	var oldVal = this.get_value();
	var newVal = this._valueFromPoint(e.offsetX, e.offsetY);
	if (newVal < 0)
		return;
	newVal = this._adjustValueForPrecision(newVal);
	newVal = this._realValFromLengthVal(newVal);

	this._changeValUI(oldVal, newVal);

	this._cancelFocus = false;
	if (!this._hasFocus && !this._focusOnClick)
		this._cancelFocus = true;
}

$IG.WebRating.prototype._onMouseOver5 = function(e)
{
	if (this._isHovered)
		return;
	var target = e.target;
	this._isHovered = true;
	this._raiseClientEvent('MouseOver', null, e);
	if (this.get_readOnly())
		return;
	var newVal = this._valueFromPoint(e.offsetX, e.offsetY);
	newVal = this._adjustValueForPrecision(newVal);
	this._keyHover = newVal;
	this._oldHover = newVal;
	if (!this._hasFocus)
		this._showHovered();
}

$IG.WebRating.prototype._onMouseOut5 = function(e)
{
	if (!this._isHovered)
		return;
	this._isHovered = false;
	this._raiseClientEvent('MouseOut', null, e);
	if (!this._hasFocus)
	{
		this._hideHovered();
		this._adjustCanvasTooltip(this.get_value());
	}
	else
		this._keyHover = this._oldHover;
}

$IG.WebRating.prototype._onMouseMove5 = function(e)
{
	this._raiseClientEvent('MouseMove', null, e);
	if (this.get_readOnly())
		return;
	var newVal = this._valueFromPoint(e.offsetX, e.offsetY);
	if (newVal <= 0 || newVal > this.get_itemCount())
		return;
	newVal = this._adjustValueForPrecision(newVal);
	if (this._oldHover != newVal)
	{
		this._drawEmpty();
		if (this.get_enableShowSelectionOnHover() || this.get_enableAnimations())
			this._drawSelected();
		this._drawHovered(newVal);
		this._adjustCanvasTooltip(this._realValFromLengthVal(newVal));
		this._keyHover = newVal;
		this._oldHover = newVal;
	}
}

$IG.WebRating.prototype._adjustCanvasKeyboard = function(oldVal, newVal, goingUp)
{
	var adjust = true;
	if (this.get_enableAnimations())
	{
		if (this.get_enableContinuousSelection() && this.get_precision() != $IG.RatingPrecision.Exact)
		{
			this._canvasSlideAnimation.play(oldVal, newVal);
			adjust = false;
		}
		else if (!this.get_enableContinuousSelection())
		{
			var remainder = newVal - this._underForVal(newVal);
			var oldRemainder = oldVal - this._underForVal(oldVal);
			if (this.get_precision() == $IG.RatingPrecision.Half && ((remainder < 1) ^ goingUp))
			{
				this._canvasSlideAnimation.play(oldVal, newVal);
				adjust = false;
			}
			else if (this.get_precision() != $IG.RatingPrecision.Exact || (goingUp && remainder < oldRemainder && remainder != 0) || (!goingUp && remainder > oldRemainder))
			{
				this._canvasKeyboardFadeAnimation.play(oldVal, newVal);
				adjust = false;
			}
		}
	}
	if (adjust)
	{
		this._drawEmpty();
		if (this.get_enableShowSelectionOnHover() || this.get_enableAnimations())
			this._drawSelected();
		this._drawHovered(this._keyHover);
	}
	this._adjustCanvasTooltip(this._realValFromLengthVal(this._keyHover));

}

$IG.WebRating.prototype._adjustCanvasTooltip = function(value)
{
	var tooltip;
	if (this.__isCustom)
	{
		var lengthVal = this._lengthValFromRealVal(value);
		var index = this._underForVal(lengthVal);
		tooltip = this._customTooltips[index];
	}
	else
		tooltip = this._itemTooltipFormat;
	tooltip = this._formatTooltip(tooltip, value);
	this._canvas.title = tooltip;
}




$IG.CanvasSlideAnimation = function(elem, owner)
{
	$IG.CanvasSlideAnimation.initializeBase(this, [elem]);
	this._equationType = $IG.AnimationEquationType.Linear;
	this._owner = owner;
};


$IG.CanvasSlideAnimation.prototype =
{
	play: function(oldHover, newHover)
	{
		this._oldHover = oldHover;
		this._newHover = newHover;
		$IG.CanvasSlideAnimation.callBaseMethod(this, "play");
	},

	_next: function()
	{
		var start = this._oldHover, end = this._newHover;
		var newLength = this._calc(this._equationType, this._time, start, end, this._duration);

		this._owner._drawEmpty();
		if (this._owner.get_enableShowSelectionOnHover())
			this._owner._drawSelected();
		this._owner._drawHovered(newLength);

		if ((start < end && newLength >= end) || (start > end && newLength <= end))
			this.stop();
	},

	stop: function()
	{
		$IG.CanvasSlideAnimation.callBaseMethod(this, "stop");
	}
};
$IG.CanvasSlideAnimation.registerClass("Infragistics.Web.UI.CanvasSlideAnimation", $IG.AnimationBase);






$IG.CanvasKeyBoardFadeAnimation = function(elem, owner)
{
	$IG.CanvasKeyBoardFadeAnimation.initializeBase(this, [elem]);
	this._equationType = $IG.AnimationEquationType.Linear;
	this._owner = owner;
};

$IG.CanvasKeyBoardFadeAnimation.prototype =
{
	play: function(oldVal, newVal)
	{
		this._oldVal = oldVal;
		this._newVal = newVal;
		
		$IG.CanvasKeyBoardFadeAnimation.callBaseMethod(this, "play");
	},

	_next: function()
	{
		var opacFade = this._calc(this._equationType, this._time, 100, 0, this._duration);
		var opacShow = 100 - opacFade;

		this._owner._drawEmpty();
		if (this._owner.get_enableShowSelectionOnHover())
			this._owner._drawSelected();
		this._owner._hoveredOpacity = opacFade / 100;
		this._owner._drawHovered(this._oldVal);
		this._owner._hoveredOpacity = opacShow / 100;
		this._owner._drawHovered(this._newVal);

		if (opacShow >= 100)
			this.stop();
	},

	stop: function()
	{
		this._owner._hoveredOpacity = 1;
		this._owner._drawEmpty();
		if (this._owner.get_enableShowSelectionOnHover())
			this._owner._drawSelected();
		this._owner._drawHovered(this._newVal);
		
		$IG.CanvasKeyBoardFadeAnimation.callBaseMethod(this, "stop");
	}

};
$IG.CanvasKeyBoardFadeAnimation.registerClass("Infragistics.Web.UI.CanvasKeyBoardFadeAnimation", $IG.AnimationBase);







$IG.CanvasFadeAnimation = function(elem, owner)
{
	$IG.CanvasFadeAnimation.initializeBase(this, [elem]);
	this._equationType = $IG.AnimationEquationType.Linear;
	this._owner = owner;
};


$IG.CanvasFadeAnimation.prototype =
{
	play: function(startOpacity, endOpacity)
	{
		this._startOpacity = startOpacity;
		this._endOpacity = endOpacity;

		if (!this._owner.get_enableShowSelectionOnHover())
			this._owner._selectedOpacity = endOpacity / 100;
		else
			this._owner._selectedOpacity = 1;
		this._owner._hoveredOpacity = startOpacity / 100;

		$IG.CanvasFadeAnimation.callBaseMethod(this, "play");
	},


	_next: function()
	{
		var start = this._startOpacity, end = this._endOpacity;
		var opacFade = this._calc(this._equationType, this._time, this._endOpacity, this._startOpacity, this._duration);
		var opacShow = 100 - opacFade;

		if (!this._owner.get_enableShowSelectionOnHover())
			this._owner._selectedOpacity = opacFade / 100;
		else
			this._owner._selectedOpacity = 1;
		this._owner._hoveredOpacity = opacShow / 100;

		this._owner._drawEmpty();
		this._owner._drawSelected();
		this._owner._drawHovered(this._owner._oldHover);

		if ((start < end && opacShow >= end) || (start > end && opacShow <= end))
			this.stop();
	},


	stop: function()
	{
		if (!this._owner.get_enableShowSelectionOnHover())
			this._owner._selectedOpacity = this._startOpacity;
		else
			this._owner._selectedOpacity = 1;
		this._owner._hoveredOpacity = this._endOpacity;

		$IG.CanvasFadeAnimation.callBaseMethod(this, "stop");
	}
};
$IG.CanvasFadeAnimation.registerClass("Infragistics.Web.UI.CanvasFadeAnimation", $IG.AnimationBase);


