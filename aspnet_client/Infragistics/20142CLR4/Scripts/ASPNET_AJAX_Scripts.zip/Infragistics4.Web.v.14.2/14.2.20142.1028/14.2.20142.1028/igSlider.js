/*
* igSlider.js
* Version 14.2.20142.1028
* Copyright(c) 2001-2014 Infragistics, Inc. All Rights Reserved.
*/


Type.registerNamespace('Infragistics.Web.UI');

$IG.WebSlider = function(element)
{
	/// <summary locid="T:J#Infragistics.Web.UI.WebSlider">Class which implements client side functionality of WebSlider.</summary>
	/// <param name="elem" domElement="true" mayBeNull="false">Reference to html element.</param>
	$IG.WebSlider.initializeBase(this, [element]);

	$IG.WebSlider.find = $find;
	$IG.WebSlider.from = $IG._from;
}
$IG.WebSlider.prototype =
{
	_thisType:'slide',
	initialize:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebSlider.initialize">Initializes instance of WebSlider.</summary>
		$IG.WebSlider.callBaseMethod(this, 'initialize');
		
		this._valCurPerc = 0;
		
		this._curMouseDown = -1;
		
		this._curMouseOver = -1;
		
		this._focus = -1;
		
		this._tabs = 0;
		var prop = this._get_clientOnlyValue('prop').split('|');
		
		this._fix2 = prop[0].charCodeAt(0) - 48;
		
		
		this._acts = prop[0];
		
		this._float = prop[0].charCodeAt(9) == 49;
		
		this._vert = prop[0].charCodeAt(10) == 49;
		
		this._valsPerc = [parseFloat(prop[1]),parseFloat(prop[2])];
		
		this._min = parseFloat(prop[3]);
		
		this._max = parseFloat(prop[4]);
		
		this._small = parseFloat(prop[5]);
		
		this._smallPerc = this._small / (this._max - this._min) * 100;
		
		this._smallKey = this._smallPerc;
		if(this._smallKey == 0)
			this._smallKey = (this._max - this._min) * 100;
		
		this._large = parseFloat(prop[6]);
		
		this._largePerc = this._large / (this._max - this._min) * 100;
		
		this._largeKey = this._largePerc;
		if(this._largePerc == 0)
			this._largePerc = (this._max - this._min) * 5;
		
		var foc = parseInt(prop[7]);
		this._focusable = foc > 0;
		
		
		this._enabled = [prop[8].charAt(0) == '1', prop[8].charAt(1) == '1', prop[8].charAt(2) == '1'];
		
		this._align = prop[9];
		
		var val = parseInt(prop[10]);
		this._snap = (val & 1) == 1;
		if((val & 2) == 2)
		{
			var div = this._element;
			while(div = div.parentNode)
			{
				if((val = div.nodeName) == 'TD')
					break;
				if(val != 'DIV')
					continue;
				val = $util.getStyleValue(null, 'overflow', div);
				if(val == '' || val == 'visible')
					continue;
				val = $util.getStyleValue(null, 'position', div);
				if(val == '' || val == 'static')
				{
					div.style.position = 'relative';
					break;
				}
			}
		}
		
		this._trackRange = prop[11] == '1';
		
		this._type = 1;
		
		this._formatStr = (prop[13].length > 0) ? prop[13] : '{0}';
		
		val = prop[12];
		if(!val) val = '12.';
		this._type = val.charCodeAt(0) - 48;
		var ch = (val.length > 1) ? val.charCodeAt(1) - 48 : 0;
		this._dec = (ch > 0 && ch <= 9) ? ch : 0;
		this._sep = (val.length > 2) ? val.charAt(2) : '.';
		if(this._type == 3)
		{
			this._dateFormat = val.substring(1);
			
			val = prop[14].split('-');
			var date = new Date();
			if(val.length == 7)
			{
				date.setFullYear(val[0]);
				date.setMonth(val[1]);
				date.setDate(val[2]);
				date.setHours(val[3]);
				date.setMinutes(val[4]);
				date.setSeconds(val[5]);
				date.setMilliseconds(val[6]);
			}
			this._dateShift = this._min - date.getTime();
		}
		
		this._bothValsLbl = this._formatStr.indexOf('{1}') >= 0;
		this._input = document.getElementById(this._id + '_i');
		if(this._focusable)
			this._focusable = this._input;
		
		prop = this._imgs = this._get_clientOnlyValue('img').split('|');
		
		var i = -1, elems = this._elements;
		this._sizeElem = elems[9];
		
		this._is2 = elems[3];
		
		this._isRange = this._is2 && !this.getLabelElem(1);
		
		while(++i < prop.length)
			if(prop[i] && prop[i].length > 2)
				try{(new Image()).src = prop[i];}catch(val){}
		if(this._is2)
		{
			var z = 0;
			for(i = 2; i < 4; i++)
				if((val = $util.toInt($util.getStyleValue(null, 'zIndex', elems[i]), 0)) > z)
					z = val;
			this._zIndex = z ? z : 1;
		}
		
		
		
		
		
		for(i = 0; i < 4; i++) if(elems[i])
		{
			elems[i]._cur = $util.getStyleValue(null, 'cursor', elems[i]);
			prop[i * 5] = elems[i]._src = elems[i].src;
		}
		
		prop = this._get_clientOnlyValue('css');
		if(prop)
		{
			prop = prop.split('|');
			var css = prop[0], lbl = this.getLabelElem(0);
			if(this._float && lbl && css)
			{
				lbl = lbl.className;
				this._floatCss = [lbl, lbl + ' ' + css];
			}
			i = prop.length;
			if(i > 2)
			{
				css = this._css = new Array();
				
				
				
				
				while(--i > 1)
					css[parseInt(prop[i - 1])] = prop[i];
				css[0] = this._element.className;
				css[5] = this.getTrackElem().className;
				if(css[1] && css[2]) css[3] = css[1] + ' ' + css[2];
				if(css[6] && css[7]) css[8] = css[6] + ' ' + css[7];
			}
		}
		
		prop = this._input ? this._input.value : '';
		prop = prop.split('|');
		
		
		if(prop.length == 6 && prop[0].charAt(0) != '[')
		{
			
			this._enabled[0] = prop[3] == '1';
			
			this._enabled[1] = prop[4] == '1';
			
			this._enabled[2] = prop[2] == '1';
			
			for(i = 0; i < 2; i++) if(prop[i] != null)
				this.setValueAsPercent(prop[i], i, true);
		}
		
		i = -1;
		
		if(!this._enabled[2])
		{
			this._setState(4);
			
			i = 1;
		}
		
		while(++i < 4)
			this._setSrc(i);
		if(this._is2 && this._fix2 == 0 && this._valsPerc[1] < 1.5)
			this._fixZ(this._focus = 3);
		
		this._lastFocus = this._lastBlur = 0;
		if(this._onTimer(true, foc > 1))
			delete this._onTimer;
		else
		{
			ig_ui_timer(this);
			this._timerOn = 1;
		}
		if(!this._once)
			this._raiseClientEvent('Initialize');
	},
	get_valueLabelFormat:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebSlider.valueLabelFormat">Gets format used for value labels. String that contains {0} and/or {1} substrings. All other parts of format are used as static characters.</summary>
		/// <value type="String">Format string</value>
		return this._formatStr;
	},
	get_thumbEnabled:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebSlider.thumbEnabled">Gets sets ability to move main thumb by end user as Boolean.</summary>
		/// <value type="Boolean">True: thumb is enabled</value>
		
		return this._enabled[0];
	},
	set_thumbEnabled:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebSlider.thumbEnabled">Sets ability to move main thumb by end user.</summary>
		/// <param name="val" type="Boolean">True: thumb is enabled</param>
		
		this._enabled[0] = val;
		
		this._setSrc(2);
		this._saveCS();
	},
	get_secondaryThumbEnabled:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebSlider.secondaryThumbEnabled">Gets sets ability to move secondary thumb by end user as Boolean.</summary>
		/// <value type="Boolean">True: thumb is enabled</value>
		
		return this._enabled[1];
	},
	set_secondaryThumbEnabled:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebSlider.secondaryThumbEnabled">Sets ability to move secondary thumb by end user.</summary>
		/// <param name="val" type="Boolean">True: thumb is enabled</param>
		this._enabled[1] = val;
		
		this._setSrc(3);
		this._saveCS();
	},
	get_enabled:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebSlider.enabled">Gets sets enabled state of control as Boolean.</summary>
		/// <value type="Boolean">True: control is enabled</value>
		
		return this._enabled[2];
	},
	set_enabled:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebSlider.enabled">Sets enabled state.</summary>
		/// <param name="val" type="Boolean">True: control is enabled</param>
		
		this._enabled[2] = val;
		val = val ? (this._hasMouse ? 2 : 0) : 4;
		
		this._setState(val);
		
		this._setSrc(2);
		this._setSrc(3);
		this._saveCS();
	},
	
	setValueAsPercent:function(val, id, fix)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebSlider.setValueAsPercent">Sets value of main or secondary thumb using percentage.</summary>
		/// <param name="val" type="Number">New value as percent in range from 0 to 100.</param>
		/// <param name="id" type="Number">The id of thumb or track. 0 means main thumb, 1 means secondary thumb.</param>
		/// <param name="fix" type="Boolean" optional="true" mayBeNull="true">Internal use only. Application should use false, or null or do not include that parameter.</param>
		if(typeof val != 'number')
		{
			if(val == null || !val.substring)
				return;
			
			try{val = parseFloat(val);}
			catch(fix){return;}
		}
		id = id ? 1 : 0;
		if(fix)
			val = (val - this._min) * 100 / (this._max - this._min);
		if(val < 0) val = 0;
		if(val > 100) val = 100;
		if(this._valsPerc[id] == val)
			return;
		
		if(this._fix2 == 0)
		{
			if(id == 1)
			{
				if(val < this._valsPerc[0])
					val = this._valsPerc[0];
			}
			else if(val > this._valsPerc[1])
				val = this._valsPerc[1];
		}
		if(this._fix2 == 1)
		{
			if(id == 1)
			{
				if(val < this._valsPerc[0])
				{
					this._valsPerc[0] = val;
					this._fixThumb(0);
				}
			}
			else if(val > this._valsPerc[1])
			{
				this._valsPerc[1] = val;
				this._fixThumb(1);
			}
		}
		this._valsPerc[id] = val;
		this._fixThumb(id);
		
		this._setSrc(0);
		this._setSrc(1);
		this._saveCS();
	},
	setValueAsDouble:function(val, id)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebSlider.setValueAsDouble">Sets value of main or secondary thumb from float point number.</summary>
		/// <param name="val" type="Number">New value in range from get_minValueAsDouble() to get_maxValueAsDouble(). In case of Date the milliseconds should be used.</param>
		/// <param name="id" type="Number">The id of thumb or track. 0 means main thumb, 1 means secondary thumb.</param>
		this.setValueAsPercent(val, id, true);
	},
	get_value:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebSlider.value">Gets sets main value as Object. That can be Number or Date object according to SliderValueType.</summary>
		return this.getValue(0);
	},
	set_value:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebSlider.value">Sets value for main thumb</summary>
		/// <param name="val">That can be Number or Date object according to SliderValueType.</param>
		this.setValueAsPercent(this.valueToDouble(val), 0, true);
	},
	get_secondaryValue:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebSlider.secondaryValue">Gets sets secondary value as Object. That can be Number or Date object according to SliderValueType.</summary>
		return this.getValue(1);
	},
	set_secondaryValue:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebSlider.secondaryValue">Sets value for secondary thumb</summary>
		/// <param name="val">That can be Number or Date object according to SliderValueType.</param>
		this.setValueAsPercent(this.valueToDouble(val), 1, true);
	},
	getValue:function(id, perc)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebSlider.getValue">Gets main or secondary value as Object.</summary>
		/// <param name="id" type="Number">The id of thumb or track. Value 0 means main thumb, 1 means secondary thumb.</param>
		/// <param name="perc" type="Number" optional="true" mayBeNull="true">Internal use only. Application should use null or do not include that parameter.</param>
		/// <returns>Value of thumb or track. That can be Number or Date object according to SliderValueType.</returns>
		return this.doubleToValue(this.getValueAsDouble(id, perc));
	},
	getValueAsDouble:function(id, perc)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebSlider.getValueAsDouble">Gets main or secondary value as Number.</summary>
		/// <param name="id" type="Number">The id of thumb or track. Value 0 means main thumb, 1 means secondary thumb.</param>
		/// <param name="perc" type="Number" optional="true" mayBeNull="true">Internal use only. Application should use null or do not include that parameter.</param>
		/// <returns type="Number">Number in range from get_minValueAsDouble() to get_maxValueAsDouble(). In case of Date the milliseconds are returned.</returns>
		return this.percentToValue((perc == null) ? this._valsPerc[id ? 1 : 0] : perc, true);
	},
	getValueAsPercent:function(id)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebSlider.getValueAsPercent">Gets main or secondary value as percent.</summary>
		/// <param name="id" type="Number">The id of thumb or track. Value 0 means main thumb, 1 means secondary thumb.</param>
		/// <returns type="Number">Number in range from 0 to 100.</returns>
		return this._valsPerc[id ? 1 : 0];
	},
	doubleToValue:function(val)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebSlider.doubleToValue">Converts value as Number to Object.</summary>
		/// <param name="val" type="Number">Value to convert. That should Number in range from get_minValueAsDouble() to get_maxValueAsDouble(). In case of Date the milliseconds should be used.</param>
		/// <returns>Number or Date object according to SliderValueType.</returns>
		if(this._type == 1)
			return val;
		val = Math.round(val);
		if(this._type == 3)
			return new Date(val - this._dateShift);
		return val;
	},
	valueToDouble:function(val)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebSlider.valueToDouble">Converts value to Number object.</summary>
		/// <param name="val">Value to convert. That should be Number or Date object according to SliderValueType.</param>
		/// <returns type="Number">Number in range from get_minValueAsDouble() to get_maxValueAsDouble(). In case of Date the milliseconds are returned.</returns>
		if(this._type != 3)
		{
			if(!val) return 0;
			if(typeof val != 'number')
				val = parseFloat('' + val);
			var x = '' + val;
			x = (x.length == 0) ? 0 : x.charCodeAt(0);
			return (x == 45 || (x > 47 && x < 58)) ? val : 0;
		}
		if(!val.getTime)
		{
			if(typeof val == 'number')
				val = ('' + val != 'NaN') ? new Date(Math.floor(val)) : new Date();
			else
				val = Date.parse('' + val);
		}
		return val.getTime() + this._dateShift;
	},
	
	valueToPercent:function(val, dbl)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebSlider.valueToPercent">Converts value to percent.</summary>
		/// <param name="val">Value to convert.</param>
		/// <param name="dbl" type="Boolean" optional="true" mayBeNull="true">Internal use only. Application should use false, or null, or do not include that parameter.</param>
		/// <returns type="Number">Number in range from 0 to 100.</returns>
		val = ((dbl ? val : this.valueToDouble(val)) - this._min) * 100 / (this._max - this._min);
		return (val > 100) ? 100 : ((val < 0) ? 0 : val);
	},
	
	percentToValue:function(val, dbl)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebSlider.percentToValue">Converts number as percent to number or object.</summary>
		/// <param name="val" type="Number">Value to convert from percent in range from 0 to 100 to Number or Date.</param>
		/// <param name="dbl" type="Boolean" optional="true" mayBeNull="true">Internal use only. Application should use false, or null, or do not include that parameter.</param>
		/// <returns>Number or Date object according to SliderValueType.</returns>
		val = this._min + (this._max - this._min) * val / 100;
		return dbl ? val : this.doubleToValue(val);
	},
	get_minValueAsDouble:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebSlider.minValueAsDouble">Gets minimum value as number. In case of Date the milliseconds are returned.</summary>
		/// <value type="Number">Minimum value</value>
		return this._min;
	},
	get_maxValueAsDouble:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebSlider.maxValueAsDouble">Gets maximum value as number. In case of Date the milliseconds are returned.</summary>
		/// <value type="Number">Maximum value</value>
		return this._max;
	},
	getButtonElem:function(id)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebSlider.getButtonElem">Gets reference to IMG html element which renders plus or minus button.</summary>
		/// <param name="id" type="Number" optional="true" mayBeNull="true">Use 0 or null to get minus button, use 1 to get plus button.</param>
		/// <returns domElement="true" mayBeNull="true">Reference to html element.</returns>
		return this._elements[(id == 1) ? 1 : 0];
	},
	getThumbElem:function(id)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebSlider.getThumbElem">Gets reference to IMG or DIV html element which renders main or secondary thumb.</summary>
		/// <param name="id" type="Number" optional="true" mayBeNull="true">Use 0 or null to get main thumb, use 1 to get secondary thumb.</param>
		/// <returns domElement="true">Reference to html element. If thumb is invisible, then DIV is returned, otherwise,- IMG.</returns>
		return this._elements[(id == 1) ? 3 : 2];
	},
	getTrackElem:function(id)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebSlider.getTrackElem">Gets reference to DIV html element which renders track bar and value-track bars.</summary>
		/// <param name="id" type="Number" optional="true" mayBeNull="true">Use -1 or null to get track bar container, use 0 to get child-track for main value, use 1 to get child track for secondary value.</param>
		/// <returns domElement="true" mayBeNull="true">Reference to html element.</returns>
		return this._elements[(id == null || id == -1) ? 4 : ((id == 1) ? 6 : 5)];
	},
	getTrackEdgeElem:function(id)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebSlider.getTrackEdgeElem">Gets reference to DIV html element which renders edges of track bar.</summary>
		/// <param name="id" type="Number" optional="true" mayBeNull="true">Use 0 or null to get left edge of horizontal slider or top edge of vertical slider, use 1 to get right (or bottom) edge.</param>
		/// <returns domElement="true">Reference to html element.</returns>
		return this._elements[(id == 1) ? 14 : 13];
	},
	getLabelElem:function(id)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebSlider.getLabelElem">Gets reference to DIV html element which renders label with value of thumb or secondary thumb.</summary>
		/// <param name="id" type="Number" optional="true" mayBeNull="true">Use 0 or null to get label for main value, use 1 to get label for secondary.</param>
		/// <returns domElement="true" mayBeNull="true">Reference to html element.</returns>
		return this._elements[(id == 1) ? 12 : 11];
	},
	_vertAdjust:function(event)
	{
		var me = this, elem = this._element;
		
		
		
		if(!elem) if((me = this._me) == null && event)
			if((me = event.currentTarget) != null)
				me = me._me;
		elem = me ? me._element : null;
		if(!elem || !me._vertAdjust)
			return;
		var init = !me._once, width = elem.offsetWidth;
		if(width == 0)
			return;
		var ok = 0, i = 2, size = me._sizeElem, align = me._align, track = me.getTrackElem();
		while(i-- > 0)
		{
			var but = me.getButtonElem(i);
			if(!but)
				break;
			var oWidth = but.offsetWidth, oHeight = but.offsetHeight;
			if(but._oHeight != oHeight)
				ok = but._oHeight = oHeight;
			if(but._oWidth != oWidth)
				ok = but._oWidth = oWidth;
			but._oWidth = but.offsetWidth;
			
			if(but.complete || but.readyState == 'complete')
				but.onreadystatechange = but.onload = null;
			else if(init)
			{
				
				but.onload = but.onreadystatechange = me._vertAdjust;
				but._me = me;
			}
		}
		if(!init && ok < 1) return;
		
		var tbl = size.childNodes[0];
		if(tbl.nodeName != 'TABLE')
			tbl = size.childNodes[1];
		var left = 0, width0 = tbl.offsetWidth;
		tbl.style.marginLeft = '0px';
		if(align == '0') if((width -= width0) > 1)
			left = width >> 1;
		if(align == '4')
			left = width - width0;
		if(align == '1')
			left = ((width - track.offsetWidth) >> 1) - track.offsetLeft;
		tbl.style.marginLeft = left + 'px';
		var perc = elem.style.height.indexOf('%') > 0;
		
		if(Sys.Browser.agent === Sys.Browser.Opera || track.offsetHeight < track.parentNode.offsetHeight / 2)
		{
			
			me._usePX = new Array();
			
			
			var tds = null;
			try
			{
				
				if(typeof tbl.rows == 'object')
					tds = tbl.rows[0].cells;
			}catch(i){}
			if(!tds) try
			{
				
				tds = tbl.firstChild.firstChild.childNodes;
			}catch(i){}
			i = (tds && tds[0] && tds[0].nodeName == 'TD') ? tds.length : 0;
			
			me._usePX[i] = track.parentNode;
			while(i--)
			{
				var r = tds[i].childNodes;
				
				me._usePX[i] = (r[0].nodeName == 'DIV') ? r[0] : r[1];
			}
			
			window.setTimeout('try{ig_controls["' + me._id + '"]._onResize();}catch(e){}', 2);
		}
		me._onResize(perc);
		if(perc && init)
			$addHandlers((Sys.Browser.agent == Sys.Browser.InternetExplorer) ? elem : window, {'resize':me._onResize}, me);
	},
	
	
	_onTimer:function(init, focus)
	{
		var elem = this._element;
		
		if(this._once || !elem)
			return true;
		var width = elem ? elem.offsetWidth : 0;
		if(width == 0)
			return false;
		var size = this._sizeElem, track = this.getTrackElem();
		if(this._vert)
			this._vertAdjust();
		this._fixThumb(0);
		this._fixThumb(1);
		
		
		var evts, ie = $util.ieTouchType();
		if (!ie)
		{
			evts = {dblclick:this._onDblclick, mousedown:this._onMouseDown, mouseover:this._onMouseOver, mouseout:this._onMouseOut, touchstart:this._onTStart, touchmove:this._onTMove, touchend:this._onTEnd};
		}
		else if (ie == 'pointer')
		{
			evts = {pointerdown:this._onMSStart, pointermove:this._onMSMove, pointerup:this._onMSEnd};
			this._ie11pointer = true;
			this._pointerUpName = 'pointerup';
			elem.style.touchAction = 'none';
		}
		else
		{
			evts = {MSPointerDown:this._onMSStart, MSPointerMove:this._onMSMove, MSPointerUp:this._onMSEnd};
			this._pointerUpName = 'MSPointerUp';
			elem.style.msTouchAction = 'none';
		}
		$addHandlers(elem, evts, this);
		var foc = this._focusable;
		if(foc)
			$addHandlers(foc, {keydown:this._onKey, focus:this._onFocus, blur:this._onBlur}, this);
		if(init === true)
			this._raiseClientEvent('Initialize');
		this._once = true;
		
		try
		{
			if(foc && document.activeElement == foc)
				this._onFocus();
			else if(focus)
				this.focus();
		}catch(e){}
		this._raiseClientEvent('Loaded');
		return true;
	},
	
	
	_getCS:function(){ return this.getValueAsDouble(0) + '|' + this.getValueAsDouble(1) + '|' + (this._enabled[2] ? 1 : 0) + '|' + (this._enabled[0] ? 1 : 0) + '|' + (this._enabled[1] ? 1 : 0) + '|' + ((this._focus >= 0) ? 1 : 0); },
	
	_saveCS:function()
	{
		if(this._input && this._once)
			this._input.value = this._getCS();
	},
	
	_saveAdditionalClientState:function()
	{
		return this._getCS();
	},
	
	
	_setLabelState:function(id)
	{
		if(!this._float)
			return;
		var elem = this._floatElem;
		
		if(id == null)
		{
			
			this._floatElem = null;
			
			id = 0;
		}
		
		else
		{
			if(id < 2) if((id = this._focus) < 2)
				id = 2;
			if((elem = this.getLabelElem(id - 2)) == null)
				elem = this.getLabelElem((id + 1) & 1);
			
			this._floatElem = elem;
			
			id = 1;
		}
		
		if(elem)
			elem.className = this._floatCss[id];
	},
	
	
	
	_getAct:function(id, dbl){return this._acts.charCodeAt(id + (dbl ? 5 : 1)) - 48;},
	
	
	
	_setSrc:function(id, press, ie11)
	{
		
		var i = 0, elem = this._elements[id];
		
		if(!elem || !elem.src || (!ie11 && this._skipSrc))
			return;
		
		
		
		if(!this._enabled[2] || (id < 2 && this._isEnd(id)) || (id > 1 && !this._enabled[id - 2]))
			i = 4;
		
		else if(this._curMouseDown == id || press)
			i = 3;
		
		else if(this._curMouseOver == id)
			i = 1;
		
		else if(this._focus == id || (this._focus > 0 && id < 2))
			i = 2;
		var src = this._imgs[id * 5 + i];
		
		
		if(!src || (elem._src == src && !ie11)) return;
		elem._src = elem.src = src;
		if (ie11)
			return;
		
		if(elem._cur && (elem._state == 4 || i == 4))
			elem.style.cursor = (i == 4) ? 'default' : elem._cur;
		elem._state = i;
		
		if (id > 1 && $util.IsIE11Plus && this._vert)
		{
			var me = this;
			
			me._skipSrc = true;
			me._setSrc(0, false, true);
			me._setSrc(1, false, true);
			setTimeout(function()
			{
				me._setSrc(0, false, true);
				me._setSrc(1, false, 1);
			}, 0);
			setTimeout(function()
			{
				delete me._skipSrc;
				me._setSrc(0, false, true);
				me._setSrc(1, false, 2);
			}, 20);
		}
	},
	
	
	_isEnd:function(id)
	{
		
		var i = this._is2 ? 2 : 1;
		while(i-- > 0)
			if(this._valsPerc[i] != id * 100)
				break;
		
		this._elements[id]._end = i < 0;
		return i < 0;
	},
	
	_getSize:function(){return this._vert ? this._sizeElem.offsetHeight : this._sizeElem.offsetWidth;},
	
	
	
	_fixChange:function(val, old)
	{
		var delta = this._smallPerc;
		if(delta <= 0 || !this._snap)
			return val;
		return (delta / 2 > Math.abs(val - old)) ? -1 : old + delta * Math.floor((val - old + delta / 2) / delta);
	},
	
	
	
	
	
	_move:function(e, id, val, fakePress, fix)
	{
		
		
		if(!this._enabled[id])
			return false;
		var old = this._valsPerc[id];
		if(e)
		{
			
			val = Math.floor(this._vert ? e.clientY : e.clientX) - this._mouseStart;
			if(this._vert)
				val = -val;
			val = this._valsPerc[id] + val * 100 / this._getSize();
			old = this._valCurPerc;
			if((val = this._fixChange(val, old)) == -1)
				return false;
		}
		
		if(val < 0)
			val = 0;
		if(val > 100)
			val = 100;
		
		if(val == old || val == this._valsPerc[id])
			return false;
		var up = (val - this._valsPerc[id]) > 0;
		var old2 = 0, val2 = val, id2 = (id + 1) & 1;
		
		if(!fix) fix = this._fix2;
		if(fix < 2)
		{
			
			
			if(!this._enabled[id2])
				fix = 0;
			old2 = this._valsPerc[id2];
			
			if((id == 0 && old2 >= val) || (id == 1 && old2 <= val))
				id2 = -1;
			
			else if(fix == 0)
				return false;
		}
		else id2 = -1;
		
		
		var args = this._raiseClientEvent('ValueChanging', 'SliderValueChanging', e, null, val, old, id, this);
		if (!this._element)
			return;
		
		if(args)
		{
			if(args.get_cancel())
				return false;
			val = val2 = args.get_newValueAsPercent();
			
			if(id2 >= 0)
			{
				old2 = this._valsPerc[id2];
				
				args = this._raiseClientEvent('ValueChanging', 'SliderValueChanging', e, null, val2, old2, id2, this);
				if (!this._element || (args && args.get_cancel()))
					return false;
				val2 = args.get_newValueAsPercent();
			}
			
			if(fix < 2) if((id == 0 && val2 < val) || (id == 1 && val2 > val))
				val2 = val;
		}
		
		
		this._fixThumb(id, this._valCurPerc = val);
		if(e)
			
			this._changed1 = old;
		else
		{
			this._valsPerc[id] = val;
			
			args = this._raiseClientEvent('ValueChanged', 'SliderValueChanged', e, null, val, old, id, this);
			if (!this._element)
				return;
		}
		
		if(id2 >= 0)
		{
			this._fixThumb(id2, this._valsPerc[id2] = val2, true);
			if(!e)
			{
				
				args = this._raiseClientEvent('ValueChanged', 'SliderValueChanged', e, null, val2, old2, id2, this);
				if (!this._element)
					return;
			}
			
			else if(this._changed2 == null)
				this._changed2 = old2;
		}
		if(fakePress)
		{
			
			if(this._pressID)
				this._onFakePress();
			if(!this._fakePressHandler)
				this._fakePressHandler = Function.createDelegate(this, this._onFakePress);
			this._pressID = window.setInterval(this._fakePressHandler, 150);
			this._setSrc(up ? 1 : 0, true);
		}
		else
		{
			
			this._setSrc(0);
			this._setSrc(1);
		}
		if(!e)
			this._saveCS();
		return true;
	},
	
	
	
	_fixThumb:function(id, val, same)
	{
		
		if(val == null)
			val = this._valsPerc[id];
		if(val < 0.001) val = 0;
		if(val > 99.999) val = 100;
		var old = val, elem = this.getThumbElem(id);
		if(!elem)
			return;
		val = (this._vert ? (100 - val) : val) + '%';
		if(this._vert)
			elem.style.top = val;
		else
			elem.style.left = val;
		
		elem = this.getLabelElem(id);
		if(!elem && id > 0)
			elem = this.getLabelElem(0);
		if(elem)
		{
			var val1 = this.getValue(id, old);
			var str = this._format(val1), val2 = val1, pos = val;
			
			if(this._bothValsLbl)
			{
				pos = old;
				if(!same)
				{
					pos = (pos + this._valsPerc[(id + 1) & 1]) / 2;
					val2 = this.getValue((id + 1) & 1);
				}
				pos = (this._vert ? (100 - pos) : pos) + '%';
				str = this._formatStr.replace('{' + id + '}', str);
				str = str.replace('{' + ((id + 1) & 1) + '}', this._format(val2));
				if(id == 1)
				{
					var v = val1;
					val1 = val2;
					val2 = v;
				}
			}
			else
				str = this._formatStr.replace('{0}', str);
			
			var args = this._raiseClientEvent('FormatValueLabel', 'SliderFormatValueLabel', null, null, val1, val2, str, id);
			if (!this._element)
				return;
			elem.innerHTML = args ? args.get_label() : str;
			if(this._float)
				if(this._vert)
					elem.style.top = pos;
				else
					elem.style.left = pos;
		}
		
		elem = this.getTrackElem(id);
		if(elem) if(this._vert)
		{
			elem.style.top = val;
			if(this._usePX && id == 0)
				old += 0.7;
			elem.style.height = old + '%';
		}
		else
			elem.style.width = val;
	},
	_format:function(val)
	{
		if(this._type < 3)
		{
			var dec = this._dec;
			var i = dec;
			
			
			
			
			while(i-- > 0)
				val = val * 10;
			val = '' + Math.round(val);
			if(dec == 0 || val == '0')
				return val;
			i = val.length;
			
			while(i <= dec)
			{
				val = '0' + val;
				i++;
			}
			
			while(dec > 0 && val.charAt(i - 1) == '0')
			{
				val = val.substring(0, --i);
				dec--;
			}
			
			return (dec == 0) ? val : (val.substring(0, i - dec) + this._sep + val.substring(i - dec));
		}
		if(this._type == 3)
		{
			var v = this._dateFormat;
			v = v.replace('yy', val.getFullYear());
			var field = val.getFullYear() % 100;
			v = v.replace('y', (field < 10) ? '0' + field : field);
			v = v.replace('M', val.getMonth() + 1);
			v = v.replace('d', val.getDate());
			v = v.replace('h', val.getHours());
			field = val.getMinutes();
			v = v.replace('m', (field < 10) ? '0' + field : field);
			field = val.getSeconds();
			v = v.replace('s', (field < 10) ? '0' + field : field);
			field = val.getMilliseconds();
			if(field < 10) field = '00' + field;
			else if(field < 100) field = '0' + field;
			return v.replace('f', field);
		}
		return '' + val;
	},
	
	
	
	
	
	
	_shift:function(val, down, swap, both, fakePress)
	{
		if(val == 3)
			val = 100;
		else
			val = (val == 2) ? this._largeKey : this._smallKey;
		
		var id = this._focus - 2;
		down = down != 0;
		if(id < 0)
			id = 0;
		
		if(this._is2)
		{
			if(both)
			{
				var v1 = this._valsPerc[0], v2 = this._valsPerc[1];
				if(down)
				{
					if(val > v1) val = v1;
					if(val > v2) val = v2;
				}
				else
				{
					if(val + v1 > 100) val = 100 - v1;
					if(val + v2 > 100) val = 100 - v2;
				}
				if(!this._move(null, id, this._valsPerc[id] + (down ? -val : val), false, 2))
					return false;
			}
			if(both || swap)
				id = (id + 1) & 1;
		}
		return this._move(null, id, this._valsPerc[id] + (down ? -val : val), fakePress);
	},
	
	
	
	
	
	_otherDown:function(e, elem, id, dbl, vert)
	{
		
		
		var css = elem.className, re = e.rawEvent;
		if(!re) re = e;
		
		var val = vert ? re.offsetY : re.offsetX;
		if(val == null)
			val = vert ? e.offsetY : e.offsetX;
		if(val == null)
			val = vert ? re.layerY : re.layerX;
		
		this._mouseID = (id > 12) ? 4 : id;
		if(!css)
		{
			if(id != 4) return;
			val += vert ? elem.offsetTop : elem.offsetLeft;
		}
		
		
		
		if(vert && (id == 5 || id == 6))
			val += elem.offsetTop;
		
		var lbl = false;
		
		var margin = this._mouseID - 7;
		
		var tick = css.indexOf('TickM') > 3;
		var ticks = css.indexOf('TicksHolder') > 3;
		
		if(margin < 0 && !tick && !ticks && id < 4)
		{
			css = elem.parentNode.className;
			if((lbl = (css && css.indexOf('LabelsHolder') > 3)) == false)
				return;
		}
		var perc = val, percTick = val;
		
		
		
		
		if(tick || lbl)
			perc += (vert ? elem.offsetTop : elem.offsetLeft);
		
		perc *= 100 / this._getSize();
		if(ticks || tick || lbl)
			this._mouseID = lbl ? 11 : 10;
		
		var old = val * 2;
		
		var percTick = parseFloat(vert ? elem.style.top : elem.style.left);
		
		if(tick)
		{
			
			if(vert && old > elem.offsetHeight)
				percTick += parseFloat(elem.style.height);
			if(!vert && old > elem.offsetWidth)
				percTick += parseFloat(elem.style.width);
		}
		
		if(id > 12)
			percTick = perc = (id == 13) ? 0 : 100;
		this._mouseTick = vert ? (100 - percTick) : percTick;
		this._mousePerc = vert ? (100 - perc) : perc;
		
		
		
		if(margin >= 0)
			id = 3;
		else if(lbl)
			id = 2;
		else
			id = (id > 3) ? 0 : 1;
		
		
		var act = this._getAct(id, dbl);
		if(act == 0 || (ticks && act == 1))
			return;
		
		if(margin >= 0)
		{
			
			this._shift(act + 1, margin - 1, e.shiftKey, e.ctrlKey);
			return;
		}
		
		
		if(act == 1 && (tick || lbl))
			val = percTick;
		else
			val = perc;
		if(vert)
			val = 100 - val;
		
		id = 0;
		var val1 = this._valsPerc[0], val2 = this._valsPerc[1];
		
		if(this._is2)
			
			if(!this._enabled[0] || (val1 == val2 && val < val1) || (val1 != val2 && Math.abs(val - val2) < Math.abs(val - val1)))
				if(this._enabled[1])
					id = 1;
		
		if((val = this._fixChange(val, this._valsPerc[id])) == -1)
			return;
		
		this._move(null, id, val);
	},
	
	
	
	_setState:function(s1, s2, s3, skipImg)
	{
		this._setCss(this._element, 0, s1, s2, s3);
		this._setCss(this.getTrackElem(), 5, s1, s2, s3);
		if(this._trackRange)
			this._setCss(this.getTrackElem(0), 5, s1, s2, s3);
		
		if(!skipImg)
		{
			this._setSrc(0);
			this._setSrc(1);
		}
	},
	
	
	
	
	_setCss:function(elem, id, s1, s2, s3)
	{
		var css = this._css;
		if(!css || !elem) return;
		var cs = css[s1 + id];
		if(!cs && s2) cs = css[s2 + id];
		if(s1 > 0) cs = css[id] + ' ' + cs;
		if(cs != elem.className)
			elem.className = cs;
	},
	_fixZ:function()
	{
		
		var z = this._zIndex, foc = this._focus;
		if(z && foc > 1)
		{
			
			this._elements[foc].style.zIndex = z + 1;
			this._elements[(foc == 2) ? 3 : 2].style.zIndex = z;
		}
	},
	
	_onKey:function(e)
	{
		
		if(!this._enabled[2]) return;
		
		this._raiseClientEvent('KeyDown', null, e);
		if (!this._element)
			return;
		var foc = this._focus, val = 0, down = 0, key = e.keyCode, shift = e.shiftKey;
		
		if(key == 9)
		{
			if(!this._is2 || foc < 0) return;
			this._tabs += (shift ? -1 : 1);
			
			
			
			if(this._tabs < -1 || this._tabs > 1 || !this._enabled[(foc + 1) & 1])
				return;
			$util.preventDefaults(e);
			//$util.cancelEvent(e);
			
			this._focus = (foc == 2) ? 3 : 2;
			this._setSrc(foc);
			this._setSrc(this._focus);
			this._fixZ();
			return;
		}
		if(this._curMouseDown >= 0)
			return;
		if(key == 38 || key == 39) val = 1;
		if(key == 37 || key == 40) down = val = -1;
		if(key == 33) val = 2;
		if(key == 34) down = val = 2;
		if(key == 35) val = 3;
		if(key == 36) down = val = 3;
		if(val != 0)
			this._shift(val, down, shift, e.ctrlKey, this.getButtonElem(0) != null);
	},
	
	_onFocus:function(e)
	{
		
		if(!this._enabled[2]) return;
		
		this._tabs = 0;
		if(this._focus < 0)
		{
			var id = this._curMouseDown;
			if(id < 2)
			{
				
				id = this._lastFocus;
				if(this._lastBlur < (new Date()).getTime() || id < 2)
					
					id = this._enabled[0] ? 2 : 3;
			}
			this._setSrc(this._focus = id);
			this._setState(this._hasMouse ? 3 : 1, 1, this._hasMouse ? 2 : 0);
			this._fixZ();
		}
		
		this._raiseClientEvent('Focus', null, e);
	},
	
	_onBlur:function(e)
	{
		
		if(!this._enabled[2]) return;
		var id = this._focus;
		if(id < 0)
			return;
		
		this._lastFocus = id;
		this._lastBlur = (new Date()).getTime();
		this._focus = -1;
		this._setSrc(id);
		this._setState(this._hasMouse ? 2 : 0);
		
		this._raiseClientEvent('Blur', null, e);
	},
	
	_onMouseOver:function(e)
	{
		
		if(!this._enabled[2] || !e) return;
		var elem = e.target;
		if(elem && !elem._unsel)
			elem._unsel = elem.unselectable = 'on';
		
		if(this._curMouseDown > 1 || !elem)
			return;
		if(!this._hasMouse)
		{
			this._hasMouse = true;
			this._setState((this._focus < 0) ? 2 : 3, 2, (this._focus < 0) ? 0 : 1, true);
		}
		
		var id = -1;
		while(++id < 4)
			if(elem == this._elements[id])
				break;
		
		if(id > 3 || elem._end)
			return;
		
		
		if(id > 1 && !this._enabled[id - 2])
			return;
		this._curMouseOver = id;
		this._setSrc(id);
		this._setLabelState(id);
		
		var name = (id < 2) ? 'Button' : 'Thumb';
		this._raiseClientEvent(name + 'MouseOver', 'Slider' + name + 'Mouse', e, null, id);
	},
	
	_onMouseOut:function(e)
	{
		
		if(!this._enabled[2] || !e || this._MSpointer)
			return;
		var elem = e.target;
		if(this._hasMouse && $util.isOut(e, this._element))
		{
			this._hasMouse = false;
			this._setState((this._focus < 0) ? 0 : 1, 0, 0, true);
		}
		
		if(this._curMouseDown > 1)
			return;
		var id = this._curMouseOver;
		this._curMouseOver = -1;
		if(this._curMouseDown >= 0)
			this._onEnd();
		else
		{
			this._setSrc(id);
			this._setLabelState();
		}
		
		var name = (id < 2) ? 'Button' : 'Thumb';
		this._raiseClientEvent(name + 'MouseOut', 'Slider' + name + 'Mouse', e, null, id);
	},
	
	_onDblclick:function(e)
	{
		this._onMouseDown(e, true);
	},
	focus:function(delay)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebSlider.focus">Sets focus to slider.</summary>
		/// <value type="Boolean">True: call input.focus() using setTimeout</value>
		var foc = this._focusable;
		if(!foc || this._focus >= 0)
			return;
		if(delay)
			window.setTimeout(function()
			{
				try
				{
					foc.focus();
				}catch(ex){}
			}, 0);
		else try
		{
			foc.focus();
		}catch(ex){}
	},
	
	_onMouseDown:function(e, dbl)
	{
		
		if(!this._enabled[2] || !e) return;
		var elem = e.target;
		if(!elem)
			return;
		
		if(!this._stepHandler)
		{
			this._stepHandler = Function.createDelegate(this, this._onStep);
			this._endHandler = Function.createDelegate(this, this._onEnd);
		}
		var delay = document.hasFocus && !document.hasFocus();
		if(!delay)
			$util.cancelEvent(e);
		
		this._onFakePress();
		
		this._changed1 = this._changed2 = null;
		
		
		var id = 15;
		while(id-- > 0)
		{
			if(elem == this._elements[id])
				break;
			
			if(id == 13) id = 9;
		}
		var thumb = id == 2 || id == 3;
		
		
		if(thumb)
		{
			
			
			if(!this._enabled[id - 2])
				return;
			this._curMouseDown = id;
		}
		
		this._lastBlur += 200;
		var foc = this._focus;
		
		if(foc < 0)
			this.focus(delay);
		
		else if(thumb && foc != id && this._focusable)
		{
			
			this._tabs = 0;
			this._focus = id;
			
			this._setSrc(foc);
			this._fixZ();
		}
		
		if(elem._end) return;
		
		if(id < 0 || id > 3)
		{
			this._otherDown(e, elem, id, dbl, this._vert);
			if((id = this._mouseID) < 4) return;
			
			var arg = 'Button', name = 'Margin';
			if(id > 9)
			{
				arg = name = 'Tickmark';
				if(id == 11) name += 'Label';
			}
			else if(id < 7)
				arg = name = 'Track';
			
			this._raiseClientEvent(name + (dbl ? 'DoubleClick' : 'MouseDown'), 'Slider' + arg + 'Mouse', e, null, id, this._mousePerc, this._mouseTick);
			return;
		}
		if(dbl)
		{
			if(id < 2 && new Date().getTime() - this._mdTime > 150 && ($util.IsIE6 || $util.IsIE7 || $util.IsIE8))
				this._shift(1, (id + 1) & 1, e.shiftKey, e.ctrlKey);
			return;
		}
		this._mdTime = new Date().getTime();
		
		this._curMouseDown = id;
		
		if(id < 2)
		{
			
			this._shift(1, (id + 1) & 1, this._stepShift = e.shiftKey, this._stepCtrl = e.ctrlKey);
			
			this._stepID = window.setInterval(this._stepHandler, this._step = 160);
		}
		this._setSrc(id);
		
		var y = Math.floor(e.clientY), x = Math.floor(e.clientX);
		
		this._mouseStart = this._vert ? y : x;
		
		var width = this._element.offsetWidth, height = this._element.offsetHeight;
		elem = this._sizeElem;
		if(this._vert)
		{
			
			x -= width / 2;
			
			y -= elem.offsetTop + this._valsPerc[id - 2] / 100 * elem.offsetHeight;
		}
		else
		{
			
			x -= elem.offsetLeft + this._valsPerc[id - 2] / 100 * elem.offsetWidth;
			
			y -= height / 2;
		}
		this._rect = {x1:x, y1:y, x2:x + width, y2:y + height};
		if(id > 1)
		{
			
			this._valCurPerc = this._valsPerc[id - 2];
			if (!this._hasMove)
				$addHandler(document, 'mousemove', this._stepHandler);
			this._hasMove = true;
		}
		if (!this._hasUp)
			$addHandler(document, 'mouseup', this._endHandler); 
		this._hasUp = true;
		
		var name = (id < 2) ? 'Button' : 'Thumb';
		this._raiseClientEvent(name + 'MouseDown', 'Slider' + name + 'Mouse', e, null, id);
	},
	_onT:function(e)
	{
		$util.cancelEvent(e);
		var t = e.rawEvent.touches;
		if(t && t[0])
		{
			e.clientX = t[0].pageX;
			e.clientY = t[0].pageY;
		}
		e.button = 0;
	},
	_onTStart:function(e)
	{
		this._onT(e);
		this._onMouseOver(e);
		this._onMouseDown(e);
	},
	_onTMove:function(e)
	{
		this._onT(e);
		this._stepHandler(e);
	},
	_onTEnd:function(e)
	{
		this._onT(e);
		this._endHandler(e);
		this._onMouseOut(e);
		this._onEnd(e);
	},
	_onMST:function(e, re)
	{
		e.clientX = re.pageX;
		e.clientY = re.pageY;
		$util.cancelEvent(e);
		e.button = 0;
	},
	_onMSStart:function(e)
	{
		var re = e.rawEvent;
		this._onMST(e, re);
		var src = this._MSsrc = re.target;
		
		if (this._ie11pointer && src.setPointerCapture)
			src.setPointerCapture(this._MSpointer = re.pointerId);
		else if (src.msSetPointerCapture)
			src.msSetPointerCapture(this._MSpointer = re.pointerId);
		this._MSupHandler = this._MSupHandler || Function.createDelegate(this, this._onMSEnd);
		if (!this._MSupOn)
			$addHandler(document, this._pointerUpName, this._MSupHandler);
		this._MSupOn = true;
		// fake events expected by on mousedown to prepare for drag
		this._onMouseOver(e);
		this._onMouseDown(e);
	},
	_onMSMove:function(e)
	{
		if(!this._MSpointer)
			return;
		var re = e.rawEvent;
		this._onMST(e, re);
		// fake events expected by on mousemove while drag
		this._stepHandler(e);
	},
	_onMSEnd:function(e)
	{
		var src = this._MSsrc, p = this._MSpointer, re = e.rawEvent;
		delete this._MSpointer;
		delete this._MSsrc;
		if (this._MSupOn)
			$removeHandler(document, this._pointerUpName, this._MSupHandler);
		delete this._MSupOn;
		if(!p)
			return;
		
		if (this._ie11pointer && src.releasePointerCapture)
			src.releasePointerCapture(p);
		else if (src.msReleasePointerCapture)
			src.msReleasePointerCapture(p);
		this._onMST(e, re);
		// fake events expected by on mouseup while drag
		this._endHandler(e);
		this._onMouseOut(e);
		this._onEnd(e);
	},
	
	
	_onStep:function(e)
	{
		
		var id = this._curMouseDown;
		
		if(!this._enabled[2] || id < 0) return;
		
		if(id < 2)
		{
			
			this._shift(1, (id + 1) & 1, this._stepShift, this._stepCtrl);
			
			id = Math.ceil(--this._step * 0.075);
			if(id > 1 && this._step % 10 < id)
			{
				window.clearInterval(this._stepID);
				this._stepID = window.setInterval(this._stepHandler, this._step = id * 10);
			}
			return;
		}
		
		var r = this._rect, y = Math.floor(e.clientY), x = Math.floor(e.clientX), elem = e ? e.target : null;
		
		if(!elem || elem.nodeName == 'HTML')
			r = null;
		
		this._curMouseOver = (elem == this._elements[id]) ? id : -1;
		
		while(elem && elem != this._element)
			elem = elem.parentNode;
		
		if(!r || (!elem && (x < r.x1 || y < r.y1 || x > r.x2 || y > r.y2)))
		{
			this._onEnd();
			return;
		}
		$util.cancelEvent(e);
		
		this._move(e, this._curMouseDown - 2);
	},
	
	
	_onEnd:function(e)
	{
		
		var id = this._curMouseDown;
		
		if(!this._enabled[2] || id < 0) return;
		if(id > 1)
		{
			this._valsPerc[id - 2] = this._valCurPerc;
			if (this._hasMove)
				$removeHandler(document, 'mousemove', this._stepHandler);
			delete this._hasMove;
			if(this._changed1 != null)
				
				this._raiseClientEvent('ValueChanged', 'SliderValueChanged', e, null, this._valsPerc[id - 2], this._changed1, id - 2, this);
			if(this._changed2 != null)
				
				this._raiseClientEvent('ValueChanged', 'SliderValueChanged', e, null, this._valsPerc[(id + 1) & 1], this._changed2, (id + 1) & 1, this);
			if (!this._element)
				return;
			this._saveCS();
		}
		else if(this._stepID)
		{
			window.clearInterval(this._stepID);
			this._stepID = null;
		}
		
		this._curMouseDown = -1;
		this._setSrc(id);
		if(this._curMouseOver < 0)
			this._setLabelState();
		if(id > 1)
		{
			
			this._setSrc(0);
			this._setSrc(1);
		}
		if (this._hasUp)
			$removeHandler(document, 'mouseup', this._endHandler);
		delete this._hasUp;
	},
	
	
	
	_onFakePress:function()
	{
		if(!this._pressID)
			return;
		window.clearInterval(this._pressID);
		this._pressID = null;
		
		this._setSrc(0);
		this._setSrc(1);
	},
	
	_onResize:function(perc)
	{
		
		var edge = this._elements[10], elem = this._element;
		if(!edge)
			return;
		var height = elem.clientHeight;
		
		
		var i = -1, divs = this._usePX, size = this._sizeElem;
		if(divs) while(++i + 1 < divs.length)
			if(divs[i])
				divs[i].style.height = '100%';
		if(!height)
			height = elem.offsetHeight - $util.getOffset($util.getRuntimeStyle(elem));
		
		var style = size.style;
		var bot = 0, init = $util.toInt(style.height, 0);
		
		while(init > 10 && (bot = edge.offsetTop) < size.offsetHeight)
			style.height = (init -= 10) + '%';
		
		var dif = height - bot;
		if(height > 3 && dif != 0)
		{
			
			init += dif / height * 100;
			style.height = ((init > 1) ? init : 1) + '%';
		}
		
		
		if(i > 1) height = divs[i].offsetHeight;
		while(i-- > 0)
			divs[i].style.height = height + 'px';
	},
	dispose:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebSlider.dispose">Disposes object and event handlers.</summary>
		
		if (this._timerOn)
			ig_ui_timer(this, true);
		if(this._element)
			$clearHandlers(this._element);
		if(this._focusable)
			$clearHandlers(this._focusable);
		$IG.WebSlider.callBaseMethod(this, 'dispose');
	}
}
$IG.WebSlider.registerClass('Infragistics.Web.UI.WebSlider', $IG.ControlMain);

$IG.WebSlider.find = function (clientID)
{
	///<summary>Finds WebSlider by its client ID.</summary>
	///<param name="clientID" type="String">Client ID of the control to look for.</param>
	///<returns type="Infragistics.Web.UI.WebSlider">Reference to the WebSlider control object that corresponds to specified client ID.</returns>
};

$IG.WebSlider.from = function (obj)
{
	///<summary>Casts passed in object to the WebSlider type.</summary>
	///<param name="obj">Object to convert to the WebSlider type.</param>
	///<returns type="Infragistics.Web.UI.WebSlider">Reference to the same object that is passed in, only type converted to the WebSlider type.</returns>
};

$IG.SliderButtonMouseEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.SliderButtonMouseEventArgs">Class used as EventArgs while raising events related to mouse over plus/minus buttons and thumbs of WebSlider.</summary>
	$IG.SliderButtonMouseEventArgs.initializeBase(this);
}
$IG.SliderButtonMouseEventArgs.prototype =
{
	
	
	isMargin:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SliderButtonMouseEventArgs.isMargin">Checks which button is involved in event.</summary>
		/// <returns type="Boolean">True means minus button, false- plus button.</returns>
		return this._props[2] >= 7;
	},
	isMinus:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SliderButtonMouseEventArgs.isMinus">Checks which button is involved in event.</summary>
		/// <returns type="Boolean">True means minus button, false- plus button.</returns>
		return this._props[2] == 0 || this._props[2] == 7;
	}
}
$IG.SliderButtonMouseEventArgs.registerClass('Infragistics.Web.UI.SliderButtonMouseEventArgs', $IG.EventArgs);

$IG.SliderThumbMouseEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.SliderThumbMouseEventArgs">Class used as EventArgs while raising events related to mouse over thumbs of WebSlider.</summary>
	$IG.SliderThumbMouseEventArgs.initializeBase(this);
}
$IG.SliderThumbMouseEventArgs.prototype =
{
	
	
	isSecondary:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SliderThumbMouseEventArgs.isSecondary">Checks which thumb is involved in event.</summary>
		/// <returns type="Boolean">True means secondary thumb, false- main thumb.</returns>
		return this._props[2] == 3;
	}
}
$IG.SliderThumbMouseEventArgs.registerClass('Infragistics.Web.UI.SliderThumbMouseEventArgs', $IG.EventArgs);

$IG.SliderTrackMouseEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.SliderTrackMouseEventArgs">Class used as EventArgs while raising events related to mouse over track bar of WebSlider.</summary>
	$IG.SliderTrackMouseEventArgs.initializeBase(this);
}
$IG.SliderTrackMouseEventArgs.prototype =
{
	
	
	get_isValue:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderTrackMouseEventArgs.isValue">Checks if mouse event belongs to main value track. True means that mouse was clicked on value track element.</summary>
		/// <value type="Boolean">True: main value track</value>
		return this._props[2] == 5;
	},
	get_isSecondaryValue:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderTrackMouseEventArgs.isSecondaryValue">Checks if mouse event belongs to secondary value track. True means that mouse was clicked on secondary value track element.</summary>
		/// <value type="Boolean">True: secondary value track</value>
		return this._props[2] == 6;
	},
	
	get_percent:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderTrackMouseEventArgs.percent">Gets percent between edge of track bar and location of mouse.</summary>
		/// <value type="Number">Value in range from 0 to 100.</value>
		return this._props[3];
	}
}
$IG.SliderTrackMouseEventArgs.registerClass('Infragistics.Web.UI.SliderTrackMouseEventArgs', $IG.EventArgs);

$IG.SliderTickmarkMouseEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.SliderTickmarkMouseEventArgs">Class used as EventArgs while raising events related to mouse over tickmarks and tickmark labels of WebSlider.</summary>
	$IG.SliderTickmarkMouseEventArgs.initializeBase(this);
}
$IG.SliderTickmarkMouseEventArgs.prototype =
{
	
	
	get_isLabel:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderTickmarkMouseEventArgs.isLabel">Checks if mouse event belongs to tickmark or tickmark label. True means that mouse was clicked on label, false: mouse was clicked on tickmark.</summary>
		/// <value type="Boolean">True: mouse is over label</value>
		return this._props[2] == 11;
	},
	
	get_percent:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderTickmarkMouseEventArgs.percent">Gets percent between edge of track bar (working area) and location of mouse.</summary>
		/// <value type="Number">Value in range from 0 to 100.</value>
		return this._props[3];
	},
	
	get_tickPercent:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderTickmarkMouseEventArgs.tickPercent">Gets percent between edge of track bar (working area) and a tickmark (or tickmark label) which is closest to location of mouse. Note: that value can be slightly different from value of tickmark or its label due to rounding.</summary>
		/// <value type="Number">Value in range from 0 to 100.</value>
		return this._props[4];
	}
}
$IG.SliderTickmarkMouseEventArgs.registerClass('Infragistics.Web.UI.SliderTickmarkMouseEventArgs', $IG.EventArgs);


$IG.SliderValueChangingEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.SliderValueChangingEventArgs">Class used as EventArgs while raising events before value change in WebSlider.</summary>
	$IG.SliderValueChangingEventArgs.initializeBase(this);
}
$IG.SliderValueChangingEventArgs.prototype =
{
	
	get_newValueAsPercent:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderValueChangingEventArgs.newValueAsPercent">Gets sets new value as percent.</summary>
		/// <value type="Number">Value in range from 0 to 100.</value>
		return this._props[2];
	},
	get_oldValueAsPercent:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderValueChangingEventArgs.oldValueAsPercent">Gets old value as percent.</summary>
		/// <value type="Number">Value in range from 0 to 100.</value>
		return this._props[3];
	},
	get_newValue:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderValueChangingEventArgs.newValue">Gets sets new value as Object. Number or Date object according to SliderValueType.</summary>
		return this._props[5].percentToValue(this._props[2]);
	},
	get_oldValue:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderValueChangingEventArgs.oldValue">Gets old value as Object. Number or Date object according to SliderValueType.</summary>
		return this._props[5].percentToValue(this._props[3]);
	},
	get_isSecondary:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderValueChangingEventArgs.isSecondary">Checks if event belongs to main or secondary value. True: secondary value, false: main value.</summary>
		/// <value type="Boolean">True: secondary value</value>
		return this._props[4] == 1;
	},
	set_newValue:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderValueChangingEventArgs.newValue">Sets new value</summary>
		/// <param name="val">That can be Number or Date object according to SliderValueType.</param>
		this.set_newValueAsPercent(this._props[5].valueToPercent(val));
	},
	set_newValueAsPercent:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderValueChangingEventArgs.newValueAsPercent">Sets new value</summary>
		/// <param name="val" type="Number">That can be Number or Date object according to SliderValueType.</param>
		if(!val || val < 0)
			val = 0;
		this._props[2] = (val > 100) ? 100 : val;
	}
}
$IG.SliderValueChangingEventArgs.registerClass('Infragistics.Web.UI.SliderValueChangingEventArgs', $IG.CancelEventArgs);


$IG.SliderValueChangedEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.SliderValueChangedEventArgs">Class used as EventArgs while raising events after value change in WebSlider.</summary>
	$IG.SliderValueChangedEventArgs.initializeBase(this);
}
$IG.SliderValueChangedEventArgs.prototype =
{
	
	get_newValueAsPercent:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderValueChangedEventArgs.newValueAsPercent">Gets new value as percent.</summary>
		/// <value type="Number">Value in range from 0 to 100.</value>
		return this._props[2];
	},
	get_oldValueAsPercent:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderValueChangedEventArgs.oldValueAsPercent">Gets old value as percent.</summary>
		/// <value type="Number">Value in range from 0 to 100.</value>
		return this._props[3];
	},
	get_newValue:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderValueChangedEventArgs.newValue">Gets new value as Object. Number or Date object according to SliderValueType.</summary>
		return this._props[5].percentToValue(this._props[2]);
	},
	get_oldValue:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderValueChangedEventArgs.oldValue">Gets old value as Object. Number or Date object according to SliderValueType.</summary>
		return this._props[5].percentToValue(this._props[3]);
	},
	get_isSecondary:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderValueChangedEventArgs.isSecondary">Checks if event belongs to main or secondary value. True: secondary value, false: main value.</summary>
		/// <value type="Boolean">True: secondary value</value>
		return this._props[4] == 1;
	}
}
$IG.SliderValueChangedEventArgs.registerClass('Infragistics.Web.UI.SliderValueChangedEventArgs', $IG.PostBackEventArgs);


$IG.SliderFormatValueLabelEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.SliderFormatValueLabelEventArgs">Class used as EventArgs while raising events which allow to format value label in WebSlider.</summary>
	$IG.SliderFormatValueLabelEventArgs.initializeBase(this);
}
$IG.SliderFormatValueLabelEventArgs.prototype =
{
	
	get_value:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderFormatValueLabelEventArgs.value">Gets value to format as Object. Number or Date object according to SliderValueType.</summary>
		return this._props[2];
	},
	get_otherValue:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderFormatValueLabelEventArgs.otherValue">Gets the other value to format as Object. Number or Date object according to SliderValueType. That can be used only when label shows 2 values, like range of values.</summary>
		return this._props[3];
	},
	get_label:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderFormatValueLabelEventArgs.label">Gets sets value for label as String.</summary>
		/// <value type="String">Value of label</value>
		return this._props[4];
	},
	set_label:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderFormatValueLabelEventArgs.label">Sets value for label</summary>
		/// <param name="val" type="String">Value for label</param>
		this._props[4] = val;
	},
	get_isSecondary:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderFormatValueLabelEventArgs.isSecondary">Checks if event was triggered by change of main or secondary value. True: event was triggered by change of secondary value, false: change of main value.</summary>
		/// <value type="Boolean">True: secondary value</value>
		return this._props[5] == 1;
	}
}
$IG.SliderFormatValueLabelEventArgs.registerClass('Infragistics.Web.UI.SliderFormatValueLabelEventArgs', $IG.EventArgs);
