/*
* igWebDataGridDeleting.js
* Version 14.2.20142.1028
* Copyright(c) 2001-2014 Infragistics, Inc. All Rights Reserved.
*/


$IG.RowDeleting = function(obj, objProps, control, parentCollection)
{
	///<summary locid="T:J#Infragistics.Web.UI.RowDeleting">
	///Deleting behavior object of the grid.
	///</summary>
	$IG.RowDeleting.initializeBase(this, [obj, objProps, control, parentCollection]);

	this._gridElement = this._grid._element;
	this._container = control._elements["container"];
	this._rows = this._owner.get_rows();
	
	this._gridElementKeyDownHandler = Function.createDelegate(this, this._onKeydownHandler);
	this._grid._addElementEventHandler(this._grid._element, "keydown", this._gridElementKeyDownHandler);
	
	var elem = this._grid._container, props = this._get_clientOnlyValue('rd');
	props = props ? props.split(',') : null;
	if (!elem || !props || props.length < 4)
		return;
	this._rd_props = props;
	this._mouseoverFn = Function.createDelegate(this, this._onMouseover);
	this._grid._addElementEventHandler(elem, "mouseover", this._mouseoverFn);
	this._mouseoutFn = Function.createDelegate(this, this._onMouseout);
	this._grid._addElementEventHandler(elem, "mouseout", this._mouseoutFn);
}

$IG.RowDeleting.prototype =
{

	
	deleteRows: function (rows)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowDeleting.deleteRows">
		/// Takes an array of rows for deletion.
		/// </summary>
		/// <param name="rows" type="Array" elementType="Infragistics.Web.UI.GridRow">Array of rows to be deleted.</param>
		for (var i = 0; i < rows.length; i++)
			this._rows.remove(rows[i], true);
		this._commit();
	},
	hideButton: function (outEvt)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowDeleting.hideButton">
		/// Hide delete button.
		/// </summary>
		/// <param name="outEvt">Internal use only.</param>
		var but = this._button;
		if (!but || !this._tr || (outEvt && !this._mouseOut))
			return;
		if (but.parentNode)
			but.parentNode.removeChild(but);
		delete this._grid._delButtonOwner;
		delete this._tr;
		this.__raiseClientEvent('DeleteButtonHidden', $IG.DeleteRowButtonEventArgs, [this._row, but]);
		delete this._row;
	},
	

	
	_commit: function ()
	{
		this.hideButton();
		var editing = this._editing;
		if (!editing._batchUpdating)
			editing.commit();
		else
			editing._commitDeletes(false);
	},
	













	// return true if add=false and elem has css
	_fixCss: function (elem, css, add)
	{
		// 0-button css
		// 1-button hover css
		// 2-button pressed css
		css = elem ? this._rd_props[css] : null;
		if (!css)
			return;
		css = ' ' + css;
		var old = elem.className || '';
		if (add && old.indexOf(css) < 0)
			elem.className = old + css;
		if (!add && old.indexOf(css) >= 0)
		{
			elem.className = old.replace(css, '');
			return true;
		}
	},
	_createButton: function ()
	{
		var me = this, but = this._button = document.createElement('SPAN');
		but.id = '_delete_button';
		but.onmouseover = function ()
		{
			me._fixPos(but);
			me._fixCss(but, 1, true);
		};
		but.onmouseout = function ()
		{
			me._fixPos(but, true);
			me._fixCss(but, 1);
			me._fixCss(but, 2);
		};
		but.onmousedown = function ()
		{
			me._fixCss(but, 2, true);
		};
		but.onmouseup = function ()
		{
			if (!me._fixCss(but, 2) || !me._row)
				return;
			me._rows.remove(me._row, true);
			me._commit();
		};
		// 4-"ButtonHtml"
		if (this._rd_props[4])
			but.innerHTML = this._rd_props[4];
		me._fixCss(but, 0, true);
		return but;
	},
	
	_fixPos: function (e, out)
	{
	    


		var tr, heightTD, heightBut, grid = this._grid, but = this._button, elem = grid._container, me = this, rows = grid.get_rows();
		if (!e || !grid || !elem)
			return;
		if (this.getEditingOn())
		{
			if (this._tr)
				this.hideButton();
			return;
		}
		while (e)
		{
			if (e == but)
			{
				if (out)
				{
					
					this._mouseOut = true;
					setTimeout(function ()
					{
						if (me._mouseOut)
							me.hideButton(true);
					}, 0 );
				}
				else
					delete this._mouseOut;
				return;
			}
			// find last TR within TABLE
			if (e.nodeName == 'TR')
			{
				if ($util._isXAttrContains(e, 'rowIsland'))
					return;
				tr = e;
			}
			if (!heightTD && (e.nodeName == 'TD' || e.nodeName == 'TH'))
				heightTD = e.offsetHeight;
			e = e.parentNode;
			// end of search
			if (e == elem)
				break;
		}
		if (!tr || !e)
			return this._onMouseout();
		delete this._mouseOut;
		if (tr == this._tr)
			return;
		
		
		var row = $util.resolveMarkedElement(tr);
		row = row ? parseInt(row[1]) : -1;
	    


		row = (isNaN(row) || row < 0) ? null : rows.get_row(row);
		if (row)
		{
			but = but || this._createButton();
			e = this.__raiseClientEvent('DeleteButtonDisplaying', $IG.DeleteRowButtonEventArgs, [row, but]);
			if (e && e.get_cancel())
				row = null;
		}
		if (!row)
			return this._onMouseout();
		this._row = row;
		this._tr = tr;
		grid._delButtonOwner = this;
		var scrollTop = elem.scrollTop,
			
			m_grid = grid._getTopGrid(),
			m_elem = m_grid && m_grid != grid ? m_grid._container : null;
		if (m_elem)
			scrollTop += m_elem.scrollTop;
		var parent = elem.parentNode, trTop = tr.firstChild.offsetTop - scrollTop + 1;
		if (but.parentNode != parent)
			parent.insertBefore(but, elem);
		heightBut = but.offsetHeight;
		if (!heightTD)
			heightTD = heightBut + 10;
		if (heightTD < heightBut)
			heightTD = heightBut;
		this._fixCss(but, 1);
		this._fixCss(but, 2);
		// 3-"ToolTip"
		if (this._rd_props[3])
			but.title = this._rd_props[3].replace('{0}', row.get_index());
		but.style.marginTop = but.style.marginLeft = '';
		var p1 = $util.getPosition(elem), p2 = $util.getPosition(but);
		
		var leftShift = p1.x - p2.x - but.offsetWidth - 10,
			gWidth = Math.min(elem.clientWidth, tr.offsetWidth),
			
			m_gWidth = m_elem ? m_elem.clientWidth : 0;
		if (m_gWidth > 10)
		{
			
			gWidth = Math.min(gWidth, m_gWidth);
			
			p2 = $util.getPosition(m_elem);
			p1.x -= p2.x;
			
			if (p1.x > 5 && m_gWidth - gWidth > p1.x)
				p1.x = grid._level || 0;
			leftShift -= p1.x;
		}
		but.style.marginTop = Math.floor(trTop + (heightTD - heightBut) / 2) + 'px';
		but.style.marginLeft = (leftShift + gWidth) + 'px';
		this.__raiseClientEvent('DeleteButtonDisplayed', $IG.DeleteRowButtonEventArgs, [row, but]);
	},
	

	
	_onMouseover: function (evt)
	{
		this._fixPos(evt.target);
	},
	_onMouseout: function ()
	{
		var me = this;
		
		me._mouseOut = true;
		setTimeout(function(){ me.hideButton(true); }, 1);
	},
	_onKeydownHandler: function (evnt)
	{
		
		if (this.getEditingOn())
			return;
		var key = evnt.keyCode;

		var isSelectionEnabled = this._selection == null ? false : true;

		if (key == Sys.UI.Key.del)
		{
			
			






			if (isSelectionEnabled)
			{
				var rowsToBeDeleted = new $IG.GridAffectedItems();
				//Get a reference to the selected rows collection.
				var selectedRows = this._selection.get_selectedRows();
				if (selectedRows.get_length() > 0)
				{
					evnt.preventDefault();
					evnt.stopPropagation();

					var grid = selectedRows._grid;
					var rows = grid.get_rows();

					var numRows = selectedRows.get_length();
					for (var i = numRows - 1; i >= 0; i--)
					{
						var rowID = selectedRows.getItemID(i);
						var row = rows.get_rowFromIDPair(rowID);
						if (row)
							rowsToBeDeleted.add(row);
						else
							rowsToBeDeleted.add(rowID);
					}

					selectedRows.clear();
					if (this._activation)
                    {
                        if (this._editing._batchUpdating)
                            this._prevActiveCell = this._activation.get_activeCell();
						this._activation.set_activeCell(null, false);
                    }

					if (rowsToBeDeleted.get_length() > 0)
					{
					

						//this._deleteRows(rowsToBeDeleted/*, grid._enableAjax*/);
						
						for (var i = 0; i < rowsToBeDeleted.get_length(); i++)
							this._rows.remove(rowsToBeDeleted.getItem(i), true);
						this._commit();
					}
				}
			}
		}

	},

	


















































































	

	

	_initializeComplete: function ()
	{
		//Get a reference to the activation interface.
		this._activation = this._grid.get_behaviors().getBehaviorFromInterface($IG.IActivationBehavior);

		//Get a reference to the selection interface.
		this._selection = this._grid.get_behaviors().getBehaviorFromInterface($IG.ISelectionBehavior);

		//Get a reference to the editing interface.
		this._editing = this._grid.get_behaviors().getBehaviorFromInterface($IG.IEditingBehavior);
		
		



	},

	dipose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowDeleting.dipose">
		/// Disposes of the Row Deleting behavior.
		/// </summary>
		var grid = this._grid, elem = this._gridElement;
		if (!grid || !elem || !this._gridElementKeyDownHandler)
			return;
		delete this._gridElementKeyDownHandler;
		grid._removeElementEventHandler(elem, "keydown", this._gridElementKeyDownHandler);
		this.hideButton();
		elem = grid._container;
		if (elem && this._mouseoverFn)
		{
			grid._removeElementEventHandler(elem, "mouseover", this._mouseoverFn);
			grid._removeElementEventHandler(elem, "mouseout", this._mouseoutFn);
		}
		$IG.RowDeleting.callBaseMethod(this, 'dispose');
	}
	
}
$IG.RowDeleting.registerClass('Infragistics.Web.UI.RowDeleting', $IG.GridBehavior, $IG.IRowDeletingBehavior);

$IG.DeleteRowButtonEventArgs = function (params)
{
	/// <summary locid="T:J#Infragistics.Web.UI.DeleteRowButtonEventArgs">
	/// Event arguments object used by events related to delete-button of RowDeleting behavior of WebDataGrid.
	/// </summary>
	$IG.DeleteRowButtonEventArgs.initializeBase(this);
	this._row = params[0];
	this._button = params[1];
	this._props[0] = $util._browser_evt;
}
$IG.DeleteRowButtonEventArgs.prototype =
{
	getRow: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.DeleteRowButtonEventArgs.getRow">
		/// Returns row where delete button is displayed.
		/// </summary>
		/// <returns type="GridRow">Reference to Infragistics.Web.UI.GridRow object</returns>
		return this._row;
	},
	getButton: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.DeleteRowButtonEventArgs.getButton">
		/// Returns reference to html element, which represents delete button.
		/// </summary>
		/// <returns domElement="true">Reference to html element</returns>
		return this._button;
	}
}
$IG.DeleteRowButtonEventArgs.registerClass('Infragistics.Web.UI.DeleteRowButtonEventArgs', $IG.CancelEventArgs);

































