/*
* igWebDataGridSorting.js
* Version 14.2.20142.1028
* Copyright(c) 2001-2014 Infragistics, Inc. All Rights Reserved.
*/




$IG.GridColumn.prototype._get_sortIndicator = function()
{
	if(typeof(this._sortIndicator) != "undefined")
		return this._sortIndicator;
		
	for(var i=0; i<this._headerElement.childNodes.length; i++)
	{
		var childNode = this._headerElement.childNodes[i];
		if(childNode.getAttribute && childNode.getAttribute("img"))
		{
			this._sortIndicator = childNode;
			break;
		}
	}
	
	return this._sortIndicator;
}

$IG.Sorting = function(obj, objProps, control, parentCollection, hierarchical)
{
	/// <summary locid="T:J#Infragistics.Web.UI.Sorting">
	/// Sorting behavior object of the grid. 
	/// </summary>
	$IG.Sorting.initializeBase(this, [obj, objProps, control, parentCollection]);

	this._hierarchical = hierarchical;
	this._sortedColumns=[];

	var sortedCols = this._get_value($IG.SortingProps.SortedColumns);
	if(sortedCols)
		for(var i = 0; i<sortedCols.length; i++)
		{
		    var column = this._owner._columns.get_columnFromKey(sortedCols[i][0]);
		    if (column) {
		        this._sortedColumns[this._sortedColumns.length] = column;
		        column._sortDirection = sortedCols[i][1];
		    }
		}

	this._sortingMode = this._get_clientOnlyValue("sm");

	this._header = control._elements["header"];

	this._mergeClassBase = this._get_clientOnlyValue("cmc");
	this._mergedCellVisible = this._mergeClassBase + "Visible";
	this._enableCellMerging = this._get_clientOnlyValue("ecm");
	if (this._grid.get_enableClientRendering())
	{
		this._onDataBoundHandler = Function.createDelegate(this, this._onDataBound);
		this._grid._gridUtil._registerEventListener(this._grid, "DataBound", this._onDataBoundHandler);
	}
	this._hasMergedCells = this._get_clientOnlyValue("hmc");
	if (this._hasMergedCells)
	{
		this._onGridScrollTopChangedHandler = Function.createDelegate(this, this._onScrollTopChanged);
		this._grid._gridUtil._registerEventListener(this._grid, "ScrollTopChanged", this._onGridScrollTopChangedHandler);
		if (this._hierarchical)
		{
			this._onRowExpandedHandler = Function.createDelegate(this, this._onRowExpanded);
			this._grid._gridUtil._registerEventListener(this._grid, "RowExpanded", this._onRowExpandedHandler);
			this._onRowCollapsedHandler = Function.createDelegate(this, this._onRowCollapsed);
			this._grid._gridUtil._registerEventListener(this._grid, "RowCollapsed", this._onRowCollapsedHandler);
			this._mergeExpandedClass = this._get_clientOnlyValue("mce");
		}
	}
}

$IG.Sorting.prototype =
{
	__getSortingColumnSettingByKey: function (key)
	{
		return this._sortingColumnSettings._getObjectByAdr(key);
	},
	get_sortingMode: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.Sorting.sortingMode">
		///Returns the sorting mode. Corresponds to the server's SortingMode enumeration: 0 - Single, 1 - Multi.
		///</summary>
		///<value type="Number" integer="true"></value>
		return this._sortingMode;
	},

	dispose: function ()
	{
		///<summary locid="M:J#Infragistics.Web.UI.Sorting.dispose">
		/// Disposes of the Sorting behavior.
		///</summary>
		if (!this._grid)
			return;
		this._grid._removeElementEventHandler(this._header, "click", this.__headerMouseClickEventHandler);

		







		this.__headerMouseClickEventHandler = null;
		




		if (this._header)
			$clearHandlers(this._header);
		this._header = null;

		delete this._sortedColumns;
		this._sortingColumnSettings.dispose();

		if (this._grid.get_enableClientRendering() && this._onDataBoundHandler)
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "DataBound", this._onDataBoundHandler);
			delete this._onDataBoundHandler;
			delete this._enableCellMerging;
		}
		if (this._moreRowsReceivedHandler)
		{
			this._grid._gridUtil._unregisterEventListener(this._virtualScrolling, "ReceivedMoreRows", this._moreRowsReceivedHandler);
			this._moreRowsReceivedHandler = null;
			delete this._virtualScrolling;
		}
		delete this._mergeClassBase;
		delete this._mergedCellVisible;
		if (this._hasMergedCells)
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "ScrollTopChanged", this._onGridScrollTopChangedHandler);
			this._onGridScrollTopChangedHandler = null;
			if (this._hierarchical)
			{
				this._grid._gridUtil._unregisterEventListener(this._grid, "RowExpanded", this._onRowExpandedHandler);
				this._onRowCollapsedHandler = null;
				this._grid._gridUtil._unregisterEventListener(this._grid, "RowCollapsed", this._onRowCollapsedHandler);
				this._onRowCollapsedHandler = null;
			}
			delete this._mergeExpandedClass;
		}
		delete this._hasMergedCells;
		delete this._hierarchical;
		if (this._cellValueChangedListener)
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "CellValueChanged", this._cellValueChangedListener);
			this._cellValueChangedListener = null;
		}
		if (this._rowDeletedBatchListener)
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "RowDeletedBatch", this._rowDeletedBatchListener);
			this._rowDeletedBatchListener = null;
		}
		if (this._batchUpdateUndoneListener)
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "BatchUpdateUndone", this._batchUpdateUndoneListener);
			this._batchUpdateUndoneListener = null;
		}
		delete this._mergedChangedCells;
		$IG.Sorting.callBaseMethod(this, "dispose");
	},

	_applySortIndicator: function (column, sortDirection)
	{
		column._sortDirection = sortDirection;
		var si = column._get_sortIndicator();
		if (sortDirection == 0)
		{
			if (si)
				column._headerElement.removeChild(si);
			delete column._sortIndicator;
			return;
		}
		if (!si)
			si = document.createElement("IMG");
		column._headerElement.appendChild(si);		

		column._sortIndicator = si;
		var src;
		var alt;
		if (sortDirection == 1)
		{
			src = this._get_clientOnlyValue("aiu");
			alt = this._get_clientOnlyValue("asc");
		}
		else
		{
			src = this._get_clientOnlyValue("diu");
			alt =this._get_clientOnlyValue("des");
		}
		$(si).attr("border", 0).attr("alt", alt).attr("title", alt).attr("src", src).css("marginLeft", "5px").attr("img", "1");
	},

	applySortIndicator: function (column, sortDirection)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Sorting.applySortIndicator">
		/// Could be used only for client-side sorting when EnableClientRendering property is set to true.
		/// This method will display the correct sort indicator for the given column,
		/// depending on the value of the sortDirection.
		/// </summary>
		/// <param name="column" type="Infragistics.Web.UI.GridColumn">The column to apply the sort indicator to.</param>		
		/// <param name="sortDirection" type="Numer">Sort direction- 0 - None, 1 - Ascending, 2 - Descending.</param>

		if (!this._grid.get_enableClientRendering())
			return;
		if (column && column.get_headerElement())
		{
			this._applySortIndicator(column, sortDirection);
		}
	},
	get_sortedColumnsInfo: function (column, key, sortDirection, singleSorting)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Sorting.sortedColumnsInfo">
		/// Returns a json array, with the column names and the sort directions
		/// the WebDataGrid is being sorted by. Could be used only
		/// for client-side sorting when EnableClientRendering property is set to true.
		/// The column parameter indicates the column WebDataGrid is sorted by, key parameter
		/// gives the column name, sortDirection shows the direction of sorting,
		/// it could be ascending or descending and singleSorting is a parameter
		/// of type bool, it's true value indicates that the last sorting is 
		/// perform by a single column, the false value means sorting by multiple columns.
		/// </summary>
		/// <param name="column" type="Infragistics.Web.UI.GridColumn">The column being sorted.</param>
		/// <param name="key" type="String">The key of the column.</param>
		/// <param name="sortDirection" type="Numer">Sort direction- 0 - None, 1 - Ascending, 2 - Descending.</param>
		/// <param name="singleSorting" type="Boolean">Whether to sort by a single column or allow multiple to be sorted.</param>
		/// <returns type="Array" elementType=""></returns>

		if (!this._grid.get_enableClientRendering())
			return;

		var sortParams;
		var result = [];
		var sortingMode = this._get_clientOnlyValue("sm");

		if (column && key)
		{
			if (sortingMode != 1)
				singleSorting = true;

			column._sortDirection = sortDirection;

			if (!singleSorting)
			{
				var index = this._sortedColumns.length;

				for (var i = 0; i < this._sortedColumns.length; i++)
				{
					if (key == this._sortedColumns[i]._key)
					{
						index = i;
						break;
					}
				}

				this._sortedColumns[index] = column;
			}
			else
			{
				sortParams = this._sortedColumns;

				for (var i = 0; i < sortParams.length; i++)
				{
					var gridColumn = this._sortedColumns[i];
					if (gridColumn.get_key() != key)
					{
						gridColumn._sortedDirection = 0;
						this._applySortIndicator(gridColumn, 0);
					}
				}

				this._sortedColumns = [];
				this._sortedColumns.length = 0;
				this._sortedColumns[0] = column;
			}
		}

		sortParams = this._sortedColumns;
		this._hasMergedCells = false;

		for (var i = 0; i < sortParams.length; i++)
		{
			result[i] = { "KeyColumn": sortParams[i]._key, "SortDirection": sortParams[i]._sortDirection };
			this._applySortIndicator(sortParams[i], sortParams[i]._sortDirection);
			var colSetting = this.__getSortingColumnSettingByKey(sortParams[i]._key);
			var mergeCells = (this._enableCellMerging && colSetting == null) || (colSetting != null && colSetting.get_mergeCells());
			if (!this._hasMergedCells && mergeCells && !sortedCol.get_isTemplated() && !sortedCol.get_isCheckbox())
				this._hasMergedCells = true;
		}
		if (this._hasMergedCells && this._onGridScrollTopChangedHandler == null)
		{
			this._onGridScrollTopChangedHandler = Function.createDelegate(this, this._onScrollTopChanged);
			this._grid._gridUtil._registerEventListener(this._grid, "ScrollTopChanged", this._onGridScrollTopChangedHandler);
		}
		else if (!this._hasMergedCells && this._onGridScrollTopChangedHandler != null) 
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "ScrollTopChanged", this._onGridScrollTopChangedHandler);
			this._onGridScrollTopChangedHandler = null;
		}

		return result;
	},

	get_sortedColumns: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Sorting.sortedColumns">
		/// Returns an array with the columns that are currently sorted.
		/// </summary>
		/// <value type="Array" elementType=""></value>
		




		return this._sortedColumns;
	},

	_onMouseClick: function (evnt)
	{
		
		if (this.getEditingOn())
			return;
		var trgt = evnt.target;
		if (trgt.tagName == "IMG")
		{
			if (trgt.getAttribute("chkState") != null)
				return;
			trgt = trgt.parentNode;
		}
		if (trgt.tagName == "TH")
		{
			var index = trgt.getAttribute("idx");
			var fieldKey = trgt.getAttribute("key");
			if (this._isGroupedColumn(fieldKey))
			{
				this._owner._changeGroupedColumnDirection(fieldKey);
				return;
			}
			else
			{
				var column = (fieldKey ? this._owner._columns.get_columnFromKey(fieldKey) : this._owner._columns._items[parseInt(index, 10)]);
				if (column)
				{
					var sortingColumnSetting = this.__getSortingColumnSettingByKey(fieldKey);
					if (sortingColumnSetting != null && !sortingColumnSetting.get_sortable())
						return;

					var sortDirection = this.getSortDirection(column);
					sortDirection++;
					if (sortDirection > 2) sortDirection = 1;
					
					this._sortColumnInternal(column, sortDirection, !(this.get_sortingMode() == 1 && (evnt.ctrlKey || ($util.IsMac && evnt.rawEvent && evnt.rawEvent.metaKey))));
				}
			}
		}
	},

	clear: function ()
	{
		///<summary locid="M:J#Infragistics.Web.UI.Sorting.clear">
		///Clears the sorted columns collection and removes the sort indicators 
		///off the headers. The order of the rows remains unchanged.
		///</summary>

		// First parameter is assumed to be a no post back flag.
		// Not in the param list so it is not documented.
		var noPost = arguments[0];

		var i = this._sortedColumns.length - 1;
		while (i >= 0)
			this._removeSortedColumn(this._sortedColumns[i--]);

		this._owner._actionList.add_transaction(new $IG.SortingAction("Clear", this.get_name(), this));
		if (!noPost)
		{
			if (!this._owner._enableAjax)
				this._owner._postAction(1);
			else
			{
				var eventArgs = new $IG.SortingEventArgs(this, null, 0, true);
				eventArgs._props[1] = 2;
				this._owner._postAction(eventArgs);
			}
		}
	},

	_sortColumnInternal: function (column, sortDirection, clear)
	{
		var eventArgs = new $IG.SortingEventArgs(this, column, sortDirection, clear);
		this._owner._raiseSenderClientEventStart(this, this._clientEvents["ColumnSorting"], eventArgs);
		if (!eventArgs.get_cancel())
		{
			column = eventArgs.get_column();
			sortDirection = eventArgs.get_sortDirection();
			clear = eventArgs.get_clear();
			if (column != null && sortDirection > 0 && sortDirection < 3)
			{
				this.sortColumn(column, sortDirection, clear, true);
				this._owner._raiseClientEventEnd(eventArgs);
			}
		}
	},

	applySort: function ()
	{
		///<summary locid="M:J#Infragistics.Web.UI.Sorting.applySort">
		///Post back to the server to apply sorted columns.
		///</summary>
		if (!this._owner._enableAjax)
			this._owner._postAction(1);
		else
		{
			var eventArgs = new $IG.SortingEventArgs(this, null, 0, false);
			eventArgs._props[1] = 2;
			this._owner._postAction(eventArgs);
		}
	},

	addSortColumn: function (column, sortDirection)
	{
		///<summary locid="M:J#Infragistics.Web.UI.Sorting.addSortColumn">
		///Add a column to be sorted without posting back to the server.
		///</summary>
		///<param name="column" type="Infragistics.Web.UI.GridColumn">
		///Reference to the column that needs to be sorted.
		///</param>
		///<param name="sortDirection" type="Number" integer="true">
		///Sorting direction. Corresponds to the server's SortDirection enumeration: 0 - None, 1 - Ascending, 2 - Descending.
		///</param>
		this.sortColumn(column, sortDirection, false, true);
	},

	sortColumn: function (column, sortDirection, clear)
	{
		///<summary locid="M:J#Infragistics.Web.UI.Sorting.sortColumn">
		///Sorts a column.
		///</summary>
		///<param name="column" type="Infragistics.Web.UI.GridColumn">
		///Reference to the column that needs to be sorted.
		///</param>
		///<param name="sortDirection" type="Number" integer="true">
		///Sorting direction. Corresponds to the server's SortDirection enumeration: 0 - None, 1 - Ascending, 2 - Descending.
		///</param>
		///<param name="clear" type="Boolean">
		///Determines if previously sorted columns must be cleared.
		///</param>

		
		if (this.getEditingOn())
			return;
		if (column)
			this._validateColumnNotGrouped(column.get_key());

		// Fourth parameter is assumed to be a no post back flag.
		// Not in the param list so it is not documented.
		var noPost = arguments[3];

		var colSortDir = this.getSortDirection(column);

		if (typeof (sortDirection) == "undefined")
		{
			sortDirection = colSortDir + 1;
			if (sortDirection > 2)
				sortDirection = 1;
		}

		if (sortDirection < 1 || sortDirection > 2)
			return;

		if (clear)
			this.clear(true);

		



























		if (clear || colSortDir == 0)
			this._sortedColumns[this._sortedColumns.length] = column;
		column._sortDirection = sortDirection;
		this._owner._actionList.add_transaction(new $IG.SortingAction("Sort", this.get_name(), this, this._sortedColumns, column.get_idPair()));
		if (!noPost)
		{
			if (!this._owner._enableAjax)
				this._owner._postAction(1);
			else
			{
				var eventArgs = new $IG.SortingEventArgs(this, column, sortDirection, clear);
				eventArgs._props[1] = 2;
				this._owner._postAction(eventArgs);
			}
		}
	},

	_removeSortedColumn: function (column)
	{
		







		
		if (this.getEditingOn())
			return;
		column._sortIndicator = null;
		column._sortDirection = 0;
		var i = this._sortedColumns.length - 1;
		while (i >= 0)
		{
			if (this._sortedColumns[i] == column)
				break;
			i--;
		}
		if (i == this._sortedColumns.length - 1)
			this._sortedColumns.pop();
		else if (i == 0)
			this._sortedColumns.shift();
		else if (i > 0)
			this._sortedColumns = this._sortedColumns.slice(0, i - 1).concat(this._sortedColumns.slice(i + 1, this._sortedColumns.length - 1));
	},

	getSortDirection: function (column)
	{
		///<summary locid="M:J#Infragistics.Web.UI.Sorting.getSortDirection">
		///Returns a column's sort direction. The method can be used to check if the column is sorted.  
		///The returned value corresponds to the server's SortDirection enumeration: 0 - None, 1 - Ascending, 2 - Descending.
		///</summary>
		///<param name="column" type="Infragistics.Web.UI.GridColumn">A reference to the column to get the sort direction for.
		///</param>
		///<returns type="Number" integer="true"></returns>
		if (typeof (column._sortDirection) == "undefined")
			return 0;
		return column._sortDirection;
	},

	_validateColumnNotGrouped: function (columnKey)
	{
		if (this._isGroupedColumn(columnKey))
			throw "Column '" + columnKey + "' cannot be added to the SortedColumns collection, because this column is currently grouped by.";
	},

	_isGroupedColumn: function (columnKey)
	{
		if (this._hierarchical && this._owner)
		{
			var band = this._owner._get_band();
			if (band)
			{
				var groupedColumn = band.get_groupingSettings().get_groupedColumns().getItemFromKey(columnKey);
				if (groupedColumn)
					return true;
			}
		}
		return false;
	},
	
	_onScrollTopChanged: function (args)
	{
		var grid = this._grid;
		var scrollTop = grid.get_scrollTop();
		if (scrollTop === this._lastScrollTop)
			return;
		var offset = this._offset ? this._offset : 0;
		var goingUp = scrollTop > (this._lastScrollTop ? this._lastScrollTop : 0);
		var increment = goingUp ? 1 : -1;
		var rows = this._hierarchical && this._grid.get_groupRows().get_length() > 0 ? this._grid.get_groupRows() : this._grid.get_rows();
		var row = this._topRowEl ? this._topRowEl : rows.get_row(0).get_element();
		var i = 0;
		while ((row) && (goingUp ? offset < scrollTop : offset + row.offsetHeight > scrollTop))
		{
			if (i > 0)
			{
				if (goingUp)
				{
					row = row.nextSibling;
					if (row && row.nodeName == "#comment")
						row = row.nextSibling;
				}
				else
				{
					row = row.previousSibling;
					if (row && row.nodeName == "#comment")
						row = row.previousSibling;
				}
			}
			i++;
			if (row && row.nodeName != "#comment")
				offset += row.offsetHeight * increment;
		}
		var rowObj = row ? this._grid._gridUtil.getRowFromCellElem(row.childNodes[0]) : null;
		if (rowObj && rowObj._get_rowType && rowObj._get_rowType() == "GroupedRow")
			rowObj = null;
		this._topRowEl = row;
		if (rowObj != this._topRow)
		{
			var sortedCols = this.get_sortedColumns();
			for(var c = 0; c < sortedCols.length; ++c)
			{
				if (this._topRow && this._topRow._element)
				{
					var prevCell = this._topRow.get_cell(sortedCols[c].get_index());
					if(prevCell.get_element().className.indexOf(this._mergeClassBase) > -1)
						$util.removeCompoundClass(prevCell.get_element(), this._mergedCellVisible);
				}
				if (rowObj)
				{
					var cell = rowObj.get_cell(sortedCols[c].get_index());
					if(cell.get_element().className.indexOf(this._mergeClassBase) > -1 && cell.get_element().className.indexOf(this._mergedCellVisible) == -1)
						$util.addCompoundClass(cell.get_element(), this._mergedCellVisible);
				}
			
			}
			this._topRow = rowObj;
		}
		this._offset = offset - (this._topRowEl ? increment * this._topRowEl.offsetHeight : 0);
		this._lastScrollTop = scrollTop;
	},

	_moreRowsReceived: function (args)
	{
		this._lastScrollTop = this._offset = this._topRow = this._topRowEl = null;
		this._offset = this._grid._elements.dataTbl.style.marginTop ? parseInt(this._grid._elements.dataTbl.style.marginTop.replace('px', '')) : 0;
		this._onScrollTopChanged();
	},
	
	_onDataBound: function (args)
	{
		var mergingData = new Object();
		var mergedCount = 0, firstCell = null, lastCell = null, mergedCount = 0;
		var rowObj = null;
		var rows = this._grid.get_rows();
		var rowCount = rows.get_length();
		var sortedCols = this.get_sortedColumns();
		var columnValues;
		var mergeCss = this._mergeClassBase;
		var hasMergedCol = false;

		for (var x = 0; x < rowCount; ++x)
		{
			rowObj = rows.get_row(x);
			for(var c = 0; c < sortedCols.length; ++c)
			{
				var sortedCol = sortedCols[c];
				var columnKey = sortedCol._key;
				var colSetting = this.__getSortingColumnSettingByKey(columnKey);
				var mergeCells = (this._enableCellMerging && colSetting == null) || (colSetting != null && colSetting.get_mergeCells());
				if (!mergeCells || sortedCol.get_isTemplated() || sortedCol.get_isCheckbox())
					continue;
				hasMergedCol = true;
				var cell = rowObj.get_cell(sortedCol.get_index());
				if (mergingData[columnKey] !=null)
				{
					firstCell = mergingData[columnKey]["firstCell"];
					lastCell = mergingData[columnKey]["lastCell"];
					prevCell = mergingData[columnKey]["prevCell"];
					mergedCount = mergingData[columnKey]["mergedCount"];
					mergeCss = this._mergeClassBase;
					var firstVal = firstCell.get_value(), thisVal = cell.get_value();
					if (!this._grid._gridUtil._valuesAreEqual(firstVal, thisVal))
					{
						$util.addCompoundClass(firstCell.get_element(), mergeCss);
						$util.addCompoundClass(firstCell.get_element(), mergeCss + "Top");
						if (mergedCount > 1)
							$util.addCompoundClass(lastCell.get_element(), mergeCss + "Bottom");
						columnValues = new Object();
						columnValues["firstCell"] = cell;
						columnValues["lastCell"] = cell;
						columnValues["prevCell"] = cell;
						columnValues["mergedCount"] = 1;
						mergingData[columnKey] = columnValues;
					}
					else
					{
						mergingData[columnKey]["lastCell"] = cell;
						$util.addCompoundClass(cell.get_element(), mergeCss);
						mergingData[columnKey]["mergedCount"]++;
					}
				}
				else
				{
					columnValues = new Object();
					columnValues["firstCell"] = cell;
					columnValues["lastCell"] = cell;
					columnValues["prevCell"] = cell;
					columnValues["mergedCount"] = 1;
					mergingData[columnKey] = columnValues;
				}
			}
			if (!hasMergedCol)
				break;
		}

		for (var key in mergingData)
		{
			if (mergingData.hasOwnProperty(key))
			{
				var columnData = mergingData[key];
				firstCell = columnData["firstCell"];
				lastCell = columnData["lastCell"];
				mergedCount = columnData["mergedCount"];
				mergeCss = this._mergeClassBase;
				$util.addCompoundClass(firstCell.get_element(), mergeCss);
				$util.addCompoundClass(firstCell.get_element(), mergeCss + "Top");
				if (mergedCount > 1)
					$util.addCompoundClass(lastCell.get_element(), mergeCss + "Bottom");
			}
		}
		
		for (var cellIdKey in this._mergedChangedCells)
		{
			if (this._mergedChangedCells.hasOwnProperty(cellIdKey))
			{
				var cellId = Sys.Serialization.JavaScriptSerializer.deserialize(cellIdKey);
				delete cellId.rowIDPair.index;
				delete cellId.columnIDPair.index;
				var cell = rows.get_cellFromIDPair(cellId);
				if (cell)
				{
					cell._mergedSpot = this._mergedChangedCells[cellIdKey];
					delete this._mergedChangedCells[cellIdKey];
					this._mergedChangedCells[Sys.Serialization.JavaScriptSerializer.serialize(cell.get_idPair())] = cell._mergedSpot;
				}
			}
		}
	},
	
	_onRowExpanded: function (args)
	{
		if(args && args.row && !(args.row._get_rowType && args.row._get_rowType() == "GroupedRow"))
		{
			var sortedCols = this.get_sortedColumns();
			var row = args.row, nextRow = this._grid.get_rows().get_row(row.get_index() + 1);
			for (var c = 0; c < sortedCols.length; ++c)
			{
				var cell = row.get_cell(sortedCols[c].get_index());
				if(cell.get_element().className.indexOf(this._mergeClassBase) > -1 && cell.get_element().className.indexOf(this._mergeExpandedClass) == -1)
					$util.addCompoundClass(cell.get_element(), this._mergeExpandedClass);
				
				var nextCell = nextRow ? nextRow.get_cell(sortedCols[c].get_index()) : null;
				var firstVal = cell.get_value(), thisVal = nextCell ? nextCell.get_value() : null;
				if (nextCell && this._grid._gridUtil._valuesAreEqual(firstVal, thisVal)
					&& nextCell.get_element().className.indexOf(this._mergeClassBase) > -1 && nextCell.get_element().className.indexOf(this._mergeExpandedClass) == -1)
					$util.addCompoundClass(nextCell.get_element(), this._mergeExpandedClass);
			}
		}
	},
	_onRowCollapsed: function (args)
	{
		if(args && args.row && !(args.row._get_rowType && args.row._get_rowType() == "GroupedRow"))
		{
			var sortedCols = this.get_sortedColumns();
			var row = args.row, nextRow = this._grid.get_rows().get_row(args.row.get_index() + 1);;
			for (var c = 0; c < sortedCols.length; ++c)
			{
				var cell = row.get_cell(sortedCols[c].get_index());
				$util.removeCompoundClass(cell.get_element(), this._mergeExpandedClass);
				if (nextRow && !nextRow.get_expanded())
					$util.removeCompoundClass(nextRow.get_cell(sortedCols[c].get_index()).get_element(), this._mergeExpandedClass);
			}
		}
	},

	
	_cellValueChanged: function (args)
	{
		var cell = args.cell, key = cell.get_column().get_key(), sortedCols = this.get_sortedColumns(), mergedSpot;
		for (var c = 0; c < sortedCols.length; ++c) 
		{
			var sortedCol = sortedCols[c];
			var columnKey = sortedCol._key;
			if (key == columnKey)
			{
				var colSetting = this.__getSortingColumnSettingByKey(columnKey);
				var mergeCells = (this._enableCellMerging && colSetting == null) || (colSetting != null && colSetting.get_mergeCells());
				if (mergeCells && !sortedCol.get_isTemplated() && !sortedCol.get_isCheckbox())
				{
					this._grid._gridUtil._adjustMergingCellValueChanged(cell, this._mergeClassBase);
					if (this._mergedChangedCells)
					{
						if (cell._mergedSpot)
							this._mergedChangedCells[Sys.Serialization.JavaScriptSerializer.serialize(cell.get_idPair())] = cell._mergedSpot;
						else
							delete this._mergedChangedCells[Sys.Serialization.JavaScriptSerializer.serialize(cell.get_idPair())];
					}
				}
				break;
			}
		}
	},

	_rowDeletedBatch: function (args)
	{
		var sortedCols = this.get_sortedColumns();
		var rowObj = args.row, index = rowObj.get_index(), isTop, isBottom;

		for (var c = 0; c < sortedCols.length; ++c) 
		{
			var sortedCol = sortedCols[c];
			var columnKey = sortedCol._key;
			var colSetting = this.__getSortingColumnSettingByKey(columnKey);
			var mergeCells = (this._enableCellMerging && colSetting == null) || (colSetting != null && colSetting.get_mergeCells());
			if (!mergeCells || sortedCol.get_isTemplated() || sortedCol.get_isCheckbox())
				continue;
			var cell = rowObj.get_cell(sortedCol.get_index());
			this._grid._gridUtil._splitMergingForCell(cell, this._mergeClassBase);
			if (cell._mergedSpot && this._mergedChangedCells)
				this._mergedChangedCells[Sys.Serialization.JavaScriptSerializer.serialize(cell.get_idPair())] = cell._mergedSpot;
		}
	},

	_batchUpdateUndone: function (args)
	{
		var operation = args.type;
		switch (operation)
		{
			case $IG.RowUpdateType.Edit: // edited
				var row = args.row;
				for (var x = 0; x < args.cellIndeces.length; ++x)
				{
					var cell = row.get_cell(args.cellIndeces[x]);
					if (cell._mergedSpot)
					{
						var newArgs = { "cell": cell, oldValue: null };
						this._cellValueChanged(newArgs);
					}
				}
				break;
			case $IG.RowUpdateType.Delete: // deleted
				var row = args.row, mergedSpot;
				for (var x = 0; x < row.get_cellCount(); ++x)
				{
					var cell = row.get_cell(x);
					if (mergedSpot = cell._mergedSpot)
					{
						var index = row.get_index(), thisVal = cell.get_value(), nextRow, nextCell, nextVal, merge = -1;
						if (mergedSpot != "top")
						{
							nextRow = this._grid.get_rows().get_row(index - 1);
							nextCell = nextRow.get_cell(cell.get_index());
							nextVal = nextCell.get_value();
							if (this._grid._gridUtil._valuesAreEqual(thisVal, nextVal) && nextRow._updated != $IG.RowUpdateStatus.Deleted)
								merge++;
						}
						nextRow = this._grid.get_rows().get_row(index + 1);
						if (nextRow)
						{
							nextCell = nextRow.get_cell(cell.get_index());
							nextVal = nextCell.get_value();
							if (this._grid._gridUtil._valuesAreEqual(thisVal, nextVal) && nextRow._updated != $IG.RowUpdateStatus.Deleted)
								merge += 2;
						}
						
						if (merge > -1)
						{
							this._grid._gridUtil._reMergeForCell(cell, this._mergeClassBase, merge);
							if (this._mergedChangedCells)
								delete this._mergedChangedCells[Sys.Serialization.JavaScriptSerializer.serialize(cell.get_idPair())];
						}
					}
				}
				break;
			case $IG.RowUpdateType.Add: // added
				break;
		}
	},

	
	_initializeComplete: function ()
	{
		var isColumnSorted = this._get_clientOnlyValue("ics");

		if (this._clientEvents["ColumnSorted"] && isColumnSorted)
		{
			
			var sortedColumnKey = this._get_clientOnlyValue("lsck");
			var sortedColumn = this._owner._columns.get_columnFromKey(sortedColumnKey);
			var sortDirection = this.getSortDirection(sortedColumn);

			var args = new $IG.SortedEventArgs(sortedColumn, sortDirection);
			this._owner._raiseSenderClientEvent(this, this._clientEvents["ColumnSorted"], args);
		}
		this.__headerMouseClickEventHandler = Function.createDelegate(this, this._onMouseClick);

		if (this._header)
			this._grid._addElementEventHandler(this._header, "click", this.__headerMouseClickEventHandler);
		this._virtualScrolling = this._parentCollection.get_virtualScrolling();
		if (this._virtualScrolling)
		{
			this._moreRowsReceivedHandler = Function.createDelegate(this, this._moreRowsReceived);
			this._virtualScrolling._addReceivedMoreRowsEventHandler(this._moreRowsReceivedHandler);
		}

		var editing = this._grid.get_behaviors().getBehaviorFromInterface($IG.IEditingBehavior);
		
		if (editing)
		{
			this._cellValueChangedListener = Function.createDelegate(this, this._cellValueChanged);
			this._grid._gridUtil._registerEventListener(this._grid, "CellValueChanged", this._cellValueChangedListener);
			if (editing && editing._batchUpdating)
			{
				this._rowDeletedBatchListener = Function.createDelegate(this, this._rowDeletedBatch);
				this._grid._gridUtil._registerEventListener(this._grid, "RowDeletedBatch", this._rowDeletedBatchListener);
				this._batchUpdateUndoneListener = Function.createDelegate(this, this._batchUpdateUndone);
				this._grid._gridUtil._registerEventListener(this._grid, "BatchUpdateUndone", this._batchUpdateUndoneListener);
			}
			if (this._grid.get_enableClientRendering())
				this._mergedChangedCells = new Object();
		}
	},

	_createCollections: function (collectionsManager)
	{
		this._sortingColumnSettings = collectionsManager.register_collection(0, $IG.SortingColumnSettings);
		var collectionItems = collectionsManager._collections[0];
		for (var columnKey in collectionItems)
			this._sortingColumnSettings._addObject($IG.SortingColumnSetting, null, columnKey);
	}
	
}

$IG.Sorting.registerClass('Infragistics.Web.UI.Sorting', $IG.GridBehavior);


$IG.SortingProps = new function()
{
	var count = $IG.GridBehaviorProps.Count;
	this.SortedColumns = [count++, 0];
	this.Count = count;
};



$IG.SortingAction = function(type, ownerName, object, value, tag)
{
	$IG.SortingAction.initializeBase(this, [type, ownerName, object, value, tag]);
}

$IG.SortingAction.prototype =
{
	get_value:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Sorting.value">
		/// Event arguments object passed into the ColumnSorting event handler.
		/// </summary>
		var sortedCols = $IG.SortingAction.callBaseMethod(this, 'get_value');
		var serverSortCols = [];
		var count = sortedCols ? sortedCols.length : 0;
		for (var colIndex = 0; colIndex < count; ++colIndex)
		{
			var col = sortedCols[colIndex];
			serverSortCols[serverSortCols.length] = {id:col.get_idPair(), sortDirection:this._object.getSortDirection(col)};
		}
		return serverSortCols;
	}
}

$IG.SortingAction.registerClass('Infragistics.Web.UI.SortingAction', $IG.GridAction);



$IG.SortingEventArgs = function(sorting, column, sortDirection, clear)
{
	/// <summary locid="T:J#Infragistics.Web.UI.SortingEventArgs">
	/// Event arguments object passed into the ColumnSorting event handler.
	/// </summary>
	
	// First parameter of the event args object associated with the 
	// behavior must be a reference to the behavior itself. This is essencial
	// for proper async call back handling.
	
	$IG.SortingEventArgs.initializeBase(this, [sorting]);
	this._column = column;
	if(column != null)
		this._props[2] = column.get_idPair();
	this._props[3] = sortDirection;
	this._props[4] = clear;
}
$IG.SortingEventArgs.prototype =
{
	get_column:function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.SortingEventArgs.column">
		///Returns the column object which is being sorted
		///</summary>
		///<value type="Infragistics.Web.UI.GridColumn"></value>
		return this._column;
	},
	set_column:function(value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.SortingEventArgs.column">
		///Returns the column object which is being sorted
		///</summary>
		///<param name="value" type="Infragistics.Web.UI.GridColumn">The new column that will be sorted</param>
		if(typeof(value.get_key) == "undefined")
			throw "First parameter must be of the type 'Infragistics.Web.UI.GridColumn'.";
		this._column = value;
		this._props[2] = value.get_key();
	},

	get_sortDirection:function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.SortingEventArgs.sortDirection">
		///Returns the sorting direction that will be applied to the column
		///</summary>
		///<value type="Infragistics.Web.UI.GridColumn"></value>
		return this._props[3];
	},
	set_sortDirection:function(value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.SortingEventArgs.sortDirection">
		///Sets the sorting direction that will be applied to the column
		///</summary>
		///<value type="Infragistics.Web.UI.GridColumn">The new sort direction to apply to the column</value>
		this._props[3] = value;
	},

	get_clear:function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.SortingEventArgs.clear">
		///Returns whether to clear previous columns' sortings when sorting the next column
		///</summary>
		///<value type="Boolean"></value>
		return this._props[4];
	},
	set_clear:function(value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.SortingEventArgs.clear">
		///Sets whether to clear previous columns' sortings when sorting the next column
		///</summary>
		///<param name="value" type="Boolean"></param>
		this._props[4] = value;
	}
}
$IG.SortingEventArgs.registerClass('Infragistics.Web.UI.SortingEventArgs', $IG.CancelBehaviorEventArgs);



$IG.SortedEventArgs = function(column, sortDirection)
{
	/// <summary locid="T:J#Infragistics.Web.UI.SortedEventArgs">
	/// Event arguments object passed into the ColumnSorted event handler.
	/// </summary>

	$IG.SortedEventArgs.initializeBase(this);
	this._column = column;
	this._sortDirection = sortDirection;
}
$IG.SortedEventArgs.prototype =
{
	get_column:function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.SortedEventArgs.column">
		///Returns the column object which has been sorted.
		///</summary>
		///<value type="Infragistics.Web.UI.GridColumn"></value>
		return this._column;
	},

	get_sortDirection:function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.SortedEventArgs.sortDirection">
		///Returns the sorting direction that has been applied to the column.
		///</summary>
		///<value type="Infragistics.Web.UI.GridColumn"></value>
		return this._sortDirection;
	}
}
$IG.SortedEventArgs.registerClass('Infragistics.Web.UI.SortedEventArgs', $IG.EventArgs);



$IG.SortingColumnSettings = function(control, clientStateManager, index, manager)
{
	/// <summary locid="T:J#Infragistics.Web.UI.SortingColumnSettings">
	/// A collection of SortingColumnSetting objects.
	/// </summary>
	$IG.SortingColumnSettings.initializeBase(this, [control, clientStateManager, index, manager]);
}
$IG.SortingColumnSettings.prototype = 
{
	getItemFromColumnKey:function(columnKey)
	{
		///<summary locid="M:J#Infragistics.Web.UI.SortingColumnSettings.getItemFromColumnKey">
		///Returns the SortingColumnSetting with the specified column key
		///</summary>
		///<value type="Infragistics.Web.UI.SortingColumnSetting"></value>
		var sortingSetting = this._getObjectByAdr(columnKey);
		
		if (!sortingSetting && this._control._grid.get_columns().get_columnFromKey(columnKey))
		{
			 sortingSetting= this._control.__createSortingSetting();
			 
			 var clientState = sortingSetting._csm.get_clientState();
			 
			 this._addExistingObject( sortingSetting,  columnKey , clientState);
		}                 
		return sortingSetting;
	}
}
$IG.SortingColumnSettings.registerClass('Infragistics.Web.UI.SortingColumnSettings', $IG.ObjectCollection);


$IG.SortingColumnSetting = function(adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.SortingColumnSetting">
	/// SortingColumnSetting object of the grid. 
	/// </summary>
	$IG.SortingColumnSetting.initializeBase(this, [adr, element, props, owner, csm]);
	
	this.__isDirty=false;
}
$IG.SortingColumnSetting.prototype =
{
	__set_property:function(propName, value, fireEvent)
	{        
		if (fireEvent)
		{
			


			if (this.onPropertyChanging)
			{
				this.onPropertyChanging(propName);
			}
		}
		this._set_value(propName,value);
	},
	dispose:function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.SortingColumnSetting.dispose">
		/// For internal use.
		///</summary>
		$IG.SortingColumnSetting.callBaseMethod(this,"dispose");
	},
//    get_columnKey:function()
//    {
//        ///<summary locid="P:J#Infragistics.Web.UI.SortingColumnSetting.columnKey">
//        /// Returns the column key value from the SortingColumnSetting object.
//        ///</summary>
//        return this._get_value($IG.SortingColumnSettingProps.ColumnKey,"");
//    },
//    _set_columnKey:function(value)
//    {
//        this.__set_property($IG.SortingColumnSettingProps.ColumnKey,value,false);
//    },
	get_sortable:function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.SortingColumnSetting.sortable">
		/// Returns the Sortable value from the SortingColumnSetting object.
		///</summary>
		///<value type="Boolean"></value>
		return this._get_value($IG.SortingColumnSettingProps.Sortable,true);
	},
	set_sortable:function(value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.SortingColumnSetting.sortable">
		/// Sets the Sortable value from the SortingColumnSetting object.
		///</summary>
		///<param name="value" type="Boolean">The new sortable value for the column</param>
		this.__set_property($IG.SortingColumnSettingProps.Sortable,value,true);
	},
	get_mergeCells:function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.SortingColumnSetting.mergeCells">
		/// Returns the MergeCells value from the SortingColumnSetting object.
		///</summary>
		///<value type="Boolean"></value>
		return this._get_value($IG.SortingColumnSettingProps.MergeCells,false);
	},
	onPropertyChanging:function(propName)
	{    
	}
}
$IG.SortingColumnSetting.registerClass('Infragistics.Web.UI.SortingColumnSetting',  $IG.ColumnSetting);


$IG.SortingColumnSettingProps = new function()
{
	var count           = $IG.ColumnSettingProps.Count;
	//this.ColumnKey      = [count++, ""];
	this.Sortable		= [count++, true];
	this.MergeCells		= [count++, false];
	this.Count          = count;
};
