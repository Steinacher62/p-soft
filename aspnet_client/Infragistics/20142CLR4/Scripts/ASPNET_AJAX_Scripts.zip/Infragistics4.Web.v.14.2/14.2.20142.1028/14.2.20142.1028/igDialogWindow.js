/*
* igDialogWindow.js
* Version 14.2.20142.1028
* Copyright(c) 2001-2014 Infragistics, Inc. All Rights Reserved.
*/


//vs 081012
Type.registerNamespace('Infragistics.Web.UI');



$IG.DialogWindowProps = new function()
{
	var count = $IG.LayoutControlProps.Count;
	this.WindowState = [count++, 0];
	this.Left = [count++, ''];
	this.Top = [count++, ''];
	this.Width = [count++, ''];
	this.Height = [count++, ''];
	this.InitialLocation = [count++, 0];
	this.Moveable = [count++, 1];
	this.MaintainLocationOnScroll = [count++, 0];
	this.Modal = [count++, 0];
	this.AsyncUpdate = [count++, 1];
	this.LastWindowState = [count++, 0];
	this.Count = count;
};

$IG.HeaderProps = new function()
{
	var count = $IG.ControlObjectProps.Count;
	this.CaptionText = [count++, ''];
	this.ImageUrl = [count++, ''];
	this.MinimizedWidth = [count++, 100];
	this.Count = count;
};



$IG.DialogWindowState = function ()
{
	/// <field name="Normal" type="Number" integer="true" static="true">Dialog in normal state.</field> 
	/// <field name="Minimized" type="Number" integer="true" static="true">Dialog in minimized state.</field> 
	/// <field name="Maximized" type="Number" integer="true" static="true">Dialog in maximized state.</field> 
	/// <field name="Hidden" type="Number" integer="true" static="true">Dialog in hidden state.</field> 
}
$IG.DialogWindowState.prototype = 
{
   Normal:0, 
   Minimized:1,
   Maximized:2,
   Hidden:3
};
$IG.DialogWindowState.registerEnum("Infragistics.Web.UI.DialogWindowState");



$IG.WebDialogWindow = function(elem)
{
	/// <summary locid="T:J#Infragistics.Web.UI.WebDialogWindow">Class which implements client side functionality of WebDialogWindow.</summary>
	/// <param name="elem" domElement="true" mayBeNull="false">Reference to html element.</param>
	$IG.WebDialogWindow.initializeBase(this, [elem]);

	$IG.WebDialogWindow.find = $find;
	$IG.WebDialogWindow.from = $IG._from;
}

$IG.WebDialogWindow.prototype =
{
	_thisType:'dialog',

	
	_responseComplete:function(cb, response, obj)
	{
		
		var cont = response ? response.context : null;
		if(!cont || cont.length < 2)
			return;
		
		$IG.WebDialogWindow.callBaseMethod(this, '_responseComplete', [cb, response, obj]);
		
		var div = document.createElement('DIV');
		div.innerHTML = cont[1];
		var id = this.get_id(), name = this.get_name(), i = div.childNodes.length;
		while(i-- > 0)
		{
			var node = div.childNodes[i];
			
			if(node.id == id)
			{
				
				var body = this._get_asyncUpdate() ? null : this._findBody(node);
				if(body)
				{
					var elem, old = null, elems = body.childNodes;
					i = elems ? elems.length : 0;
					
					if(i != 1 || elems[0].nodeName != 'IFRAME')
					{
						
						while(i-- > 0)
							body.removeChild(elems[i]);
						elems = this._body2.childNodes;
						i = elems.length;
						
						while(i-- > 0)
						{
							this._body2.removeChild(elem = elems[i]);
							body.insertBefore(elem, old);
							old = elem;
						}
					}
				}
				
				this._element.swapNode(node);
				break;   
			}
		}
		
		this.dispose();
		$create($IG.WebDialogWindow, {'id':id, 'name':name, 'props':eval(cont[0])}, null, null, $get(id));
	},
	
	_findBody:function(elem)
	{
		if ($util._isXAttrContains(elem, ':mkr:16'))
			return elem;
		var elems = elem.childNodes;
		var i = elems ? elems.length : 0;
		while(i-- > 0)
			if((elem = this._findBody(elems[i])) != null)
				return elem;
		return null;
	},
	
	initialize:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDialogWindow.initialize">Initializes instance of WebDialogWindow.</summary>
		$IG.WebDialogWindow.callBaseMethod(this, 'initialize');
		
		
		
		this._body2 = this._elements[16];
		this._ie = Sys.Browser.agent == Sys.Browser.InternetExplorer;
		this._safari = Sys.Browser.agent === Sys.Browser.Safari;
		
		this._postAct = 0;
		var back = this._getBackState(0);
		
		this._suspendVis = this._isVis();
		this._modalCss = this._get_clientOnlyValue("mbc");
		var elem = this._element;
		if(this._get_clientOnlyValue("ub")) try
		{
			var e = elem, par = e.parentNode;
			while (e = e.parentNode)
				if (e.nodeName == 'FORM' || e.nodeName == 'BODY')
					break;
			if (e && e != par)
			{
				par.removeChild(elem);
				e.appendChild(elem);
			}
		}
		catch(elem){}
		if(this._contentPane)
			this._contentPane._DIV = this._body2;
		if(this._onTimer(true))
			delete this._onTimer;
		else
		{
			ig_ui_timer(this);
			this._timerOn = 1;
		}
		
		if(back)
		{
			back = back.split(',');
			if(back.length > 5)
			{
				
				this.setSize(back[4], back[5]);
				this.set_top(back[3]);
				this.set_left(back[2]);
				this._set_lastWindowState(parseInt(back[1]));
				this.set_windowState(parseInt(back[0]));
			}
		}
		if(!this._ready)
			this._raiseClientEvent('Initialize');
	},
	
	_get_modal:function(){return this._get_value($IG.DialogWindowProps.Modal);},
	_get_asyncUpdate:function(){return this._get_value($IG.DialogWindowProps.AsyncUpdate);},
	get_enabled:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.enabled">Checks if control is enabled.</summary>
		/// <value type="Boolean">True: dialog is enabled</value>
		return this._getFlags().getEnabled();
	},
	
	_isVis:function(){return this._element ? this._element.style.display != 'none' : false;},
	
	_setVis:function(show)
	{
		var elem = this._element;
		
		if(!this._suspendVis || !show || !elem)
			$util.display(elem, !show);
		else
			elem.style.display = '';
	},
	_onTimer:function(init, play)
	{
		if(this._painted)
			return true;		
		var elem = this._element;
		var width = elem ? elem.offsetWidth : 0;
		if(width == 0)
			return false;
		this._painted = true;		
		if(!this._header)
			this._header = new $IG.Header(null, null, null, this);
		
		
		
		
		
		
		
		this._header._init(this._elements, elem);		
		var rp = this._get_clientOnlyValue('rp');
		if(rp && rp.length > 1)
		{
			rp = this._resizer = $create($IG.ResizeBehavior,{'pairs':rp,'id':this.get_id()+'.r','control':this},null,null,elem);
			rp._prefix = 'Resizer';
			if(rp.get_minimumWidth() == 0)
				rp.set_minimumWidth(this._header._minWidth);
			if(rp.get_minimumHeight() == 0)
				rp.set_minimumHeight(this._header.get_height() + (this._elements[15] ? 25 : 15));
		}
		else if(!this._get_isMinimized() && !this._get_isMaximized() && !this._get_isClosed())
			this.onResize(2, null, play);
		//
		this._headerMoveable(true);
		if(!this._get_isClosed())
			this.set_windowState(this.get_windowState())
		
		if(this._suspendVis && this._isVis())
			this._element.style.visibility = 'visible';
		
		this._suspendVis = false;
		this._inModal = false;
		this._ready = true;
		if(init === true)
			this._raiseClientEvent('Initialize');
		this._raiseClientEvent('Loaded');
		return true;			
	},
	_play:function()
	{
		
	},

	_addHandlers:function() 
	{
		$IG.WebDialogWindow.callBaseMethod(this, '_addHandlers');
	},

	_createObject:function(element, obj)
	{
		if(obj == 'header')
		{
			this._header = new $IG.Header(obj, element, this._objectsManager.get_objectProps(0), this);
			this._objectsManager.register_object(0, this._header);
		}
		if(obj == 'body')
		{
			this._body = element;
			this._contentPane = new $IG.LayoutPane(obj, element, this._objectsManager.get_objectProps(1), this);
			this._objectsManager.register_object(1, this._contentPane);
		}
	},
	
	get_contentPane:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.contentPane">Gets reference to Infragistics.Web.UI.LayoutPane.</summary>
		/// <value type="Infragistics.Web.UI.LayoutPane">Reference to content pane.</value>
		return this._contentPane;
	},
	
	_get_resizeAreaElem:function()
	{
		var pane = this.get_contentPane();
		if(pane != null)
			return pane._DIV;
	
	}, 
	
	get_header:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.header">Gets reference to Infragistics.Web.UI.Header or null.</summary>
		/// <value type="Infragistics.Web.UI.Header" mayBeNull="true">Reference to header.</value>
		return this._ready ? this._header : null;
	},

	
	get_resizer:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.resizer">Gets reference to Infragistics.Web.UI.ResizeBehavior if resizing is enabled.</summary>
		/// <value type="Infragistics.Web.UI.ResizeBehavior" mayBeNull="true">Reference to resizer.</value>
		return this._resizer;
	},
	
	
	canResize:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDialogWindow.canResize">Checks if control can be resized.</summary>
		/// <returns type="Boolean">True: dialog in normal state and it can be resized.</returns>
		return (this.get_windowState() == $IG.DialogWindowState.Normal)
	},	
	
	set_initialLocation:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.initialLocation">Sets the initial location of WebDialogWindow relative to window of browser.</summary>
		/// <param name="val" type="Number" integer="true">Value of 0 means manual, value of 1 means centered</param>
		this._set_value($IG.DialogWindowProps.InitialLocation, val);
		if(val == 1 && this._painted && this._header._mover &&  !this._get_isMaximized())
			this._header._mover.setAbsPos(this.get_left(), this.get_top(), true, this.get_maintainLocationOnScroll(), this._get_modal());
	},
	get_initialLocation:function()
	{ 
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.initialLocation">Gets sets the initial location of WebDialogWindow relative to window of browser.</summary>
		/// <value type="Number">Value of 0 means manual, value of 1 means centered.</value>
		return this._get_value($IG.DialogWindowProps.InitialLocation);
	},

	set_moveable:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.moveable">Sets the ability to drag control by mouse.</summary>
		/// <param name="val" type="Boolean">True: control can be dragged by mouse</param>
		this._set_value($IG.DialogWindowProps.Moveable, val);
		this._headerMoveable(val);
	},
	get_moveable:function()
	{ 
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.moveable">Gets sets the ability to drag control by mouse as Boolean.</summary>
		/// <value type="Boolean">True: control can be dragged by mouse</value>
		return this._get_value($IG.DialogWindowProps.Moveable, true) && this.get_enabled();
	},

	set_maintainLocationOnScroll:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.maintainLocationOnScroll">Sets the ability to keep relative location of dialog while window is resized or scrolled.</summary>
		/// <param name="val" type="Boolean">True: location of dialog is kept relative while scroll</param>
		this._set_value($IG.DialogWindowProps.MaintainLocationOnScroll, val);
		this._headerMoveable(val);
	},
	get_maintainLocationOnScroll:function()
	{ 
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.maintainLocationOnScroll">Gets sets the ability to keep relative location of dialog while window is resized or scrolled.</summary>
		/// <value type="Boolean">True: location of dialog is kept relative while scroll.</value>
		return this._get_value($IG.DialogWindowProps.MaintainLocationOnScroll) == 1;
	},

	get_width:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.width">Gets sets width of dialog as String. It can be pixels or percents.</summary>
		/// <value type="String">Width of control in units</value>
		return this._get_value($IG.DialogWindowProps.Width);
	},
	set_width:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.width">Sets width of dialog.</summary>
		/// <param name="val" type="String">Width of control in % or px units as string</param>
		this.setSize(val);
	},
	get_height:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.height">Gets sets height of dialog as String. It can be pixels or percents.</summary>
		/// <value type="String">Height of control in units</value>
		return this._get_value($IG.DialogWindowProps.Height);
	},
	set_height:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.height">Sets height of dialog.</summary>
		/// <param name="val" type="String">Height of control in % or px units as string</param>
		this.setSize(null, val);
	},
	setSize:function(width, height, evt)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDialogWindow.setSize">Sets width and height of dialog.</summary>
		/// <param name="height" type="String" optional="true" mayBeNull="true">Height of dialog as pixels or percents.</param>
		/// <param name="width" type="String" optional="true" mayBeNull="true">Width of dialog as pixels or percents.</param>
		/// <param name="evt" type="Boolean" optional="true" mayBeNull="true">Request to do not adjust appearance.</param>
		if(width)
			this._set_value($IG.DialogWindowProps.Width, width);
		if(height)
			this._set_value($IG.DialogWindowProps.Height, height);
		this._setVS();
		if(evt)
			return;
		var elem = this._element;
		if(width)
			elem.style.width = width;
		if(height)
			elem.style.height = height;
		if(!this._painted)
			return;
		if(this._resizer)
			this._resizer.setSize(elem.offsetWidth, elem.offsetHeight);
		else
			this.onResize();
		if(this._header._mover)
			this._header._mover._onScrollSize();
	},
	get_left:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.left">Gets sets location of left edge of dialog as String. The set method may have optional second param: true means do not adjust appearance.</summary>
		/// <value type="String">Left of control in units</value>
		return this._get_value($IG.DialogWindowProps.Left);
	},
	set_left:function(val, mouse)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.left">Sets location of left edge of dialog.</summary>
		/// <param name="val" type="String">Left edge of control in % or px units as string</param>
		/// <param name="mouse" type="Boolean" optional="true" mayBeNull="true">Internal use only</param>
		this._set_value($IG.DialogWindowProps.Left, val);
		if(!mouse)
			this._element.style.left = this._toUnit(val);
		this._setVS();
	},
	get_top:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.top">Gets sets location of top edge of dialog as String. The set method may have optional second param: true means do not adjust appearance.</summary>
		/// <value type="String">Top of control in units</value>
		return this._get_value($IG.DialogWindowProps.Top);
	},
	set_top:function(val, mouse)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.top">Sets location of top edge of dialog.</summary>
		/// <param name="val" type="String">Top edge of control in % or px units as string</param>
		/// <param name="mouse" type="Boolean" optional="true" mayBeNull="true">Internal use only</param>
		this._set_value($IG.DialogWindowProps.Top, val);
		if(!mouse)
			this._element.style.top = this._toUnit(val);
		this._setVS();
	},
	
	
	
	
	_setVS:function()
	{
		
		this._setBackState(0, this._saveAdditionalClientState());
	},
	
	_saveAdditionalClientState:function()
	{
		
		return this.get_windowState() + ',' + this._get_lastWindowState() + ',' + this.get_left() + ',' + this.get_top() + ',' + this.get_width() + ',' + this.get_height() + ',' + this._postAct;
	},
	_toUnit:function(val)
	{
		var num = val ? parseFloat(val) : 0;
		return (!num || isNaN(num)) ? '0px' : ((typeof val == 'number' || val == '' + num) ? val + 'px' : val);
	},
	
	
	onResize:function(e, height, play)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDialogWindow.onResize">Implementation of IResizable. Internal use only.</summary>
		/// <param name="e">Internal use.</param>
		/// <param name="height">Internal use.</param>
		/// <param name="play">Internal use.</param>
		var body = this._body, elem = this._element;
		if(!body || !elem)
			return;
		var v, dif, width, style = elem.style;
		
		
		if(height)
		{
			style.width = e;
			style.height = height;
			e = null;
		}
		if(e == 2 && this._clientWidth != null)
			return;
		height = elem.offsetHeight;
		if(height == 0)
			return;
		
		if(e)
			this.setSize(style.width, style.height, true);
		var fire = this._shift1h == null;
		
		if(fire)
		{
			this._ready = true;
			style = $util.getRuntimeStyle(elem);
			
			this._shift1w = $util.getOffset(style, true);
			this._shift1h = $util.getOffset(style);
			this._shift2h = this._shift2w = 0;
			
			
			var i = 9, elems = this._elements;
			while(++i < 16)
			{
				style = $util.getRuntimeStyle(elem = this._elements[i]);
				
				if(i == 11)
				{
					this._bodyTD = elem;
					continue;
				}
				if(!style)
					continue;
				elem.style.margin = '0px';
				
				if(i == 10 || i == 12)
				{
					v = $util.toIntPX(style, 'width', 0, elem);
					
					
					this._shift2w += v;
					this._shift2w += $util.getOffset(style, true);
				}
				
				if(i == 13)
				{
					v = $util.toIntPX(style, 'height', 0, elem);
					if(v < 5 && this._safari)
						v = elem.offsetHeight;
					
					
					this._shift2h += v;
					this._shift2h += $util.getOffset(style);
				}
			}
			
			elem = this._body2;
			style = $util.getRuntimeStyle(elem);
			this._shift3h = $util.toIntPX(style, 'marginTop') + $util.toIntPX(style, 'marginBottom');
			this._shift3w = $util.toIntPX(style, 'marginLeft') + $util.toIntPX(style, 'marginRight');
			this._shift4h = $util.getOffset(style);
			this._shift4w = $util.getOffset(style, true);
		}
		
		height -= this._shift1h + this._header.get_height();
		if(height < 0)
			height = 0;
		
		if((width = elem.offsetWidth - this._shift1w) < 0)
			width = 0;
		body.style.height = height + 'px';
		
		elem = this._bodyTD;
		body = this._body2;
		
		if((height -= this._shift2h) < 0)
			height = 0;
		elem.style.height = height + 'px';
		
		if((height -= this._shift3h) < 0)
			height = 0;
		v = this._shift4h;
		var heightS = height - v;
		if(heightS < 0)
			heightS = 0;
		body.style.height = heightS + 'px';
		
		if(v > 0 && body.offsetHeight < height)
		{
			body.style.height = height + 'px';
			if((dif = elem.offsetHeight - body.offsetHeight) > 0)
			{
				body.style.height = (height += dif) + 'px';
			}
		}
		height = body.offsetHeight - v;
		
		if((width -= this._shift2w) < 0)
			width = 0;
		elem.style.width = width + 'px';
		var widthTD = elem.offsetWidth;
		
		v = this._shift4w;
		body.style.width = '';
		if((dif = body.offsetWidth - widthTD) > 0)
		{
			body.style.width = '100%';
			if((dif = body.offsetWidth - widthTD) > 0)
				body.style.width = Math.floor(100 - dif / widthTD * 100) + '%';
		}
		
		if(v > 0 && (body.offsetWidth + this._shift3w) < width)
		{
			body.style.width = width + 'px';
		}
		width = body.offsetWidth - v;
		if(height < 0)
			height = 0;
		if(width < 0)
			width = 0;
		
		if(this._clientWidth === width && this._clientHeight === height)
			return;
		this._clientWidth = width;
		this._clientHeight = height;
		if(fire)
			this._contentPane._onInit();
		if(play)
			this._play();
		
		$util.raiseLayoutEvent(this);
	},

	
	getLayoutManager:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDialogWindow.getLayoutManager">Implementation of LayoutManager. Internal use only.</summary>
		/// <returns type="Infragistics.Web.UI.WebDialogWindow">Reference to this.</returns>
		return this;
	},
	
	getClientWidth:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDialogWindow.getClientWidth">Implementation of LayoutManager. Internal use only.</summary>
		/// <returns type="Number">Width of client area.</returns>
		return this._clientWidth;
	},
	
	getClientHeight:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDialogWindow.getClientHeight">Implementation of LayoutManager. Internal use only.</summary>
		/// <returns type="Number">Height of client area.</returns>
		return this._clientHeight;
	},
	
	getBody:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDialogWindow.getBody">Implementation of LayoutManager. Internal use only.</summary>
		/// <returns domElement="true">Reference to div element which used as content pane.</returns>
		var v = this._body2; return v ? v : this._body;
	},
	
	
	findChild:function(id)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDialogWindow.findChild">Find html element which id ends-up with "id".</summary>
		/// <param name="id" type="String">The trailing part of id of element to search for.</param>
		/// <returns domElement="true" mayBeNull="true">Reference to html element or null.</returns>
		return $util.findChild(this.getBody(), id);
	},
	
	_get_isMinimized:function(){return (this.get_windowState() == $IG.DialogWindowState.Minimized);},
	_get_isMaximized:function(){return (this.get_windowState() == $IG.DialogWindowState.Maximized);},
	_get_isClosed:function(){return (this.get_windowState() == $IG.DialogWindowState.Hidden);},
	get_windowState:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.windowState">Gets sets the current state of dialog as Number. Value corresponds to WindowState enum on server.
		/// The set method may contain second param: true means request to raise client event.
		/// </summary>
		/// <value type="Number" integer="true">One of constants defined in Infragistics.Web.UI.DialogWindowState.</value>
		return this._get_value($IG.DialogWindowProps.WindowState);
	},	    
	set_windowState:function(state, fire)
	{   
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.windowState">Sets current state of dialog.</summary>
		/// <param name="state" type="Number" integer="true">One of constants defined in Infragistics.Web.UI.DialogWindowState</param>
		/// <param name="fire" type="Boolean" optional="true" mayBeNull="true">True: request to raise client event</param>
		var lastState = this._get_lastWindowState(), newState = state, restoreMax = restoreMin = false;
		var currentState = this._get_value($IG.DialogWindowProps.WindowState);	    
		if(state == $IG.DialogWindowState.Normal)
		{
			if(currentState ==  $IG.DialogWindowState.Hidden)
			{
				if(lastState == $IG.DialogWindowState.Maximized)
				{
					state = $IG.DialogWindowState.Maximized;		        
					restoreMax = true;
				}
				else if(lastState == $IG.DialogWindowState.Minimized)
				{
					restoreMin = true;
					state = $IG.DialogWindowState.Minimized;	
				}
			}
			else if(currentState == $IG.DialogWindowState.Minimized && lastState == $IG.DialogWindowState.Maximized)
				state = $IG.DialogWindowState.Maximized;		        
		}
		
		if(state != currentState)
		{
			if(fire)
			{
				var args =  this._raiseClientEvent('WindowStateChanging', 'WindowStateCancel', null, null, currentState, state);
				if (!this._element)
					return;
				if(args == null || !args.get_cancel())
				{
					this._updateWindowState(state, currentState, lastState, restoreMax, restoreMin);
					
					this._postAct = 1;
					this._raiseClientEvent("WindowStateChanged", "PostBack", null, null);
					
					this._postAct = 0;
				}
				return;
			}	            
		}
		this._updateWindowState(state, currentState, lastState, restoreMax, restoreMin);	            
	},
	
	show:function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDialogWindow.show">
		/// Displays the WebDialogWindow by adjusting the WindowState to $IG.DialogWindowState.Normal
		///</summary>
		this.set_windowState($IG.DialogWindowState.Normal);
	},
	hide:function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDialogWindow.hide">
		/// Hides the WebDialogWindow by adjusting the WindowState to $IG.DialogWindowState.Hidden
		///</summary>
		this.set_windowState($IG.DialogWindowState.Hidden);
	},	
	_updateWindowState:function(state, currentState, lastState, restoreMax, restoreMin)
	{
		if(restoreMax || restoreMin)
			this._setNormal(state, restoreMax, restoreMin);
		this._set_value($IG.DialogWindowProps.WindowState, state);
		if(state == $IG.DialogWindowState.Maximized)
			this._setMaximized(currentState);
		else if(state == $IG.DialogWindowState.Minimized)
		{
			
			this._skipAbs = this.get_initialLocation() != 1 && currentState == 0;
			this._setMinimized(currentState);
		}
		else if(state == $IG.DialogWindowState.Hidden)
		{
			if(currentState == $IG.DialogWindowState.Maximized)
				this._setRestoreMax();
			this._setClosed(); 
		}
		else if(state == $IG.DialogWindowState.Normal)
		{		        
			if(currentState == $IG.DialogWindowState.Maximized)
				this._setRestoreMax();
			else if(currentState == $IG.DialogWindowState.Minimized)
			{
				
				this._skipAbs = this.get_initialLocation() != 1;
				this._setRestoreMin(lastState);
			}
			else
				this._setNormal(state);
		}
		
		this._skipAbs = null;
		if(state != currentState)
			this._set_lastWindowState(currentState)
		for(var i = 0; i < this._header._buttons.length; i++)
			this._header._buttons[i]._ensureState();
		if(this._resizer)
			this._resizer.enabled = (state == $IG.DialogWindowState.Normal);
		this._setVS();
	},
	
	_get_lastWindowState:function(){return this._get_value($IG.DialogWindowProps.LastWindowState);},	
	_set_lastWindowState:function(val){this._set_value($IG.DialogWindowProps.LastWindowState, val);},	
	 
	_setRestoreMax:function(isTemp)
	{
		var max = this._maxOld;
		if(max)
		{
			var htm = max.htm;
			this._header._resizeLsnr(false);
			var style = this._element.style;
			style.width = max.w;
			style.height = max.h;
			var pos = max.pos;
			if(pos == null)
				pos = 'absolute';
			style.position = pos;
			style.left = max.x;
			style.top = max.y;
			style.zIndex = max.zi;
			htm.scrollLeft = max.x2;
			htm.scrollTop = max.y2;
			if(htm.style)
				htm.style.overflow = max.over;
			if(!isTemp)
				this._maxOld = null;
			this.onResize();
			this._headerMoveable(true);
		}
		this._hideResizer(false);		
	},
	
	_setRestoreMin:function(lastState)	
	{
		$util.display(this._body);
		var style = this._element.style;
					
		if(lastState != $IG.DialogWindowState.Maximized)
		{
			style.width = this._header._ownerWidth;
			style.height = this._header._ownerHeight;		    
			this._hideResizer(false);	    
			this.onResize();
			this._header._ownerSize();	  	        
			
			if(!this._skipAbs)
				this._headerMoveable(true);
		}
	},
	
	_setMaximized:function(currentState)
	{   
		if(currentState == $IG.DialogWindowState.Minimized)
			this._setRestoreMin();
		var body = this._body;
		if(!body)
			return;
		var style = this._element.style;
		this._hideResizer(true);

		this._headerMoveable(false);
			
		var htm = $util.getHTML();
		
		if(!this._maxOld)
		{
			if(currentState == $IG.DialogWindowState.Minimized)
				this._maxOld = max = {x:this.get_left(), y:this.get_top(), w:this.get_width(), h:this.get_height(), pos:null, zi:style.zIndex, htm:htm, x2:htm.scrollLeft, y2:htm.scrollTop};
			else
				this._maxOld = max = {x:style.left, y:style.top, w:style.width, h:style.height, pos:style.position, zi:style.zIndex, htm:htm, x2:htm.scrollLeft, y2:htm.scrollTop};
		 }   
		
		htm.scrollLeft = htm.scrollTop = 0;
		if(htm.style)
		{
			max.over = htm.style.overflow;
			htm.style.overflow = 'hidden';
		}
		style.position = 'absolute';
		style.left = style.top = '0px';
		style.zIndex = 100000;
		var point = $util.getPosition(this._element);
		if(point.x != 0)
			style.left = (-point.x) + 'px';
		if(point.y != 0)
			style.top = (-point.y) + 'px';
		this._header._onResize();
		this._header._resizeLsnr(true);		
	},
	
	_setMinimized:function(currentState)
	{   
		if(currentState == $IG.DialogWindowState.Maximized)
			this._setRestoreMax(true)
		var body = this._body;
		this._header._ownerSize();
		$util.display(body, true);
		var style = this._element.style;
		this._hideResizer(true);
		style.width = this._header._minWidth + 'px';
		style.height = this._header.get_height() + 'px';				
	},
	
	_setClosed:function()
	{
		this._setVis(false);
		this._headerMoveable(false);	
	},
	
	_setNormal:function(newState, restoreMax, restoreMin)
	{
		this._setVis(true);
		this._onTimer(false, true);
		if(restoreMax)
			this._setRestoreMax();
		if(restoreMin)
			this._setRestoreMin();
		if(newState == $IG.DialogWindowState.Normal) 
		{
			this.onResize();
			this._headerMoveable(true);
			this._hideResizer(false);	
		}
		this._play();
	},
	
	_hideResizer:function(hide)
	{   
		if(this._resizer)
			$util.display(this._resizer._handDad, hide);
	},
	
	_headerMoveable:function(moveable)
	{
		this._header._moveable(moveable, this._get_isMaximized());
	},
	
	
	_onSubmitOtherHandler:function(e)
	{
		if(this._contentPane)
			this._contentPane._onSubmit();
		$IG.WebDialogWindow.callBaseMethod(this, '_onSubmitOtherHandler', [e]);
	},

	dispose:function()
	{
		
		if (this._timerOn)
			ig_ui_timer(this, true);
		if(this._header)
			this._header.dispose();
		if(this._resizer)
			this._resizer.dispose();
		/// <summary locid="M:J#Infragistics.Web.UI.WebDialogWindow.dispose">Disposes object and event handlers.</summary>
		$IG.WebDialogWindow.callBaseMethod(this, 'dispose');
		this._header = this._resizer = this._contentPane = null;
	}
}

$IG.WebDialogWindow.registerClass('Infragistics.Web.UI.WebDialogWindow', $IG.ControlMain);

$IG.WebDialogWindow.find = function (clientID)
{
	///<summary>Finds WebDialogWindow by its client ID.</summary>
	///<param name="clientID" type="String">Client ID of the control to look for.</param>
	///<returns type="Infragistics.Web.UI.WebDialogWindow">Reference to the WebDialogWindow control object that corresponds to specified client ID.</returns>
};

$IG.WebDialogWindow.from = function (obj)
{
	///<summary>Casts passed in object to the WebDialogWindow type.</summary>
	///<param name="obj">Object to convert to the WebDialogWindow type.</param>
	///<returns type="Infragistics.Web.UI.WebDialogWindow">Reference to the same object that is passed in, only type converted to the WebDialogWindow type.</returns>
};



$IG.Header = function(obj, element, props, control)
{
	var csm = obj ? new $IG.ObjectClientStateManager(props[0]) : null;
	$IG.Header.initializeBase(this, [obj, element, props, control, csm]);
	this._buttons = [];
}

$IG.Header.prototype =
{
	_height:null,

	get_minimizedWidth:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.minimizedWidth">Gets sets the width of the header when control is minimized. Value is Number.</summary>
		/// <value type="Number">Width of header in minimized state.</value>
		return this._get_value($IG.HeaderProps.MinimizedWidth);
	},
	set_minimizedWidth:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.minimizedWidth">Sets the width of the header when control is minimized</summary>
		/// <param name="val" type="Number" integer="true">Width of header in minimized state</param>
		this._set_value($IG.HeaderProps.MinimizedWidth, val);
		this.__updateMinWidth(); 
		if(this._owner._get_isMinimized())
			this._owner._setMinimized();
	},

	
	_ownerSize:function()
	{
		var ctl = this._owner;
		var elem = ctl._element;
		var v = ctl.get_height();
		if(v == '' && !this._ownerHeight)
		{
			if((v = elem.offsetHeight) == 0)
				v = 300;
			v = v + 'px';
		}
		if(v != '')
			this._ownerHeight = v;
		v = ctl.get_width();
		if(v == '' && !this._ownerWidth)
		{
			if((v = elem.offsetWidth) == 0)
				v = 400;
			v = v + 'px';
		}
		if(v != '')
			this._ownerWidth = v;
	},
	
	get_height:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.height">Gets the height of the header as Number.</summary>
		/// <value type="Number">Height of header.</value>
		var height = this._height;
		if(height !== null)
			return height;
		height = this._element;
		if(!height)
			return this._height = 0;
		return ((height = height.offsetHeight) != 0) ? (this._height = height) : 0;
	},
	
	getCaptionText:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDialogWindow.getCaptionText">Gets the text that will be displayed in the caption area of the header.</summary>
		/// <returns type="String">Text of header.</returns>
		return this._get_value($IG.HeaderProps.CaptionText);
	},
	
	setCaptionText:function(val)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDialogWindow.setCaptionText">Sets the text that will be displayed in the caption area of the header.</summary>
		/// <param name="val" type="String">Text of header.</param>
		var elem = this._getElem(1);
		if(!elem)
		{
			if(!val || !this._elems)return;
			this._elems[7].appendChild(this._elems[1] = elem = document.createElement('SPAN'));
		}
		elem.innerHTML = val; 
		this._set_value($IG.HeaderProps.CaptionText, val);
	},
	
	getImageUrl:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDialogWindow.getImageUrl">Gets the image url that will be displayed in the header.</summary>
		/// <returns type="String">Image url for header.</returns>
		return this._get_value($IG.HeaderProps.ImageUrl);
	},
	
	setImageUrl:function(val)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDialogWindow.setImageUrl">Sets the image url that will be displayed in the header.</summary>
		/// <param name="val" type="String">Image url for header.</param>
		var elem = this._getElem(0);
		if(!elem)
		{
			if(!val || !this._elems)return;
			this._elems[7].appendChild(this._elems[0] = elem = document.createElement('IMG'));
			elem.alt = 'dialog image';
		}
		elem.src = val; 
		this._set_value($IG.HeaderProps.ImageUrl, val);
	},
	
	_moveable:function(val, max)
	{
		var move = this._mover, ctl = this._owner;
		if(!move)
		{
			move = this._element;
			if(!val || !move) return;
			move = this._mover = $create($IG.DialogMoveBehavior,{"targetElement":ctl._element, "owner":this, "control":ctl}, null, null, move);
			
			move._noModalTI = ctl._get_clientOnlyValue('mh') == '1';
			move._ie = this._ie;
			move._prefix = 'Header';
			if(this._elems)
			{
				move._img = this._elems[0];
				move._lbl = this._elems[1];
			}
		}
		move.enabled = val && ctl.get_moveable();
		if(!val)
		{
			move.restore(max);
		}
		if(val)
			move.setAbsPos(ctl.get_left(), ctl.get_top(), ctl.get_initialLocation() > 0, ctl.get_maintainLocationOnScroll(), ctl._get_modal(), max);
	},
	
	_getElem:function(i)
	{
		var elem = this._elems;
		if(elem) elem = elem[i];
		return (elem && elem.nodeName) ? elem : null;
	},
	
	_setupButtons:function()
	{ 
		var but, elems = this._elems, om = this._objectManager, buts = this._buttons;
		if (!elems || !om || buts.length > 0)
			return;
		but = this._closeButton = new $IG.DialogButton("Close", elems["Close"], om.get_objectProps(0), this, null, $IG.DialogWindowState.Hidden);
		om.register_object(0, but);
		buts.push(but);
		but = this._maxButton = new $IG.DialogButton("Maximize", elems["Maximize"], om.get_objectProps(1), this, null,  $IG.DialogWindowState.Maximized);
		om.register_object(1, but);
		buts.push(but);
		but = this._minButton = new $IG.DialogButton("Minimize", elems["Minimize"], om.get_objectProps(2), this, null,  $IG.DialogWindowState.Minimized);
		om.register_object(2, but);
		buts.push(but);
	},

	
	
	
	_init:function(elems, elem)
	{
		this._elems = elems;   
		if(!this._objectManager)
			return;
		this._setupButtons();
		this._ownerSize();
		this.__updateMinWidth();
	},
	
	__updateMinWidth:function()
	{
		var width = 2, elem = this._element, elems = this._elems, td = null, i = this._buttons.length;
		while(i-- > 0)
		{
			var img = this._buttons[i].get_element();
			if(!img)continue;
			width += (img.offsetWidth || 23) + $util.toIntPX(null, 'marginLeft', 0, img) + $util.toIntPX(null, 'marginRight', 0, img);
			if(!td)
				td = img.parentNode;
		}
		var minWidth = this.get_minimizedWidth();
		
		if(td)
		{
			
			td.style.width = width + 'px';
			
			width += 2 * $util.getOffset($util.getRuntimeStyle(elem), true) + 1;
			
			if(elems[8])
				width += elems[8].offsetWidth + elems[9].offsetWidth;
			
			if(!minWidth || minWidth < width)
				minWidth = width;
		}
		this._minWidth = minWidth ? minWidth : 0;
	},
	
	
	_onResize:function(e)
	{
		var max = this._maxOld, ctl = this._owner;
		if(!max && !ctl)
			return;
		var win = $util.getWinRect();
		ctl.onResize((win.width - 2) + 'px', (win.height - 2) + 'px');
	},

	
	_resizeLsnr:function(on)
	{
		if(!on && !this._resizeOn)
			return;
		if(!this._onResizeFn)
			this._onResizeFn = Function.createDelegate(this, this._onResize);
		if(on === this._resizeOn)
			return;
		this._resizeOn = on;
		if(on)
			$addHandler(window, 'resize', this._onResizeFn);
		else
			$removeHandler(window, 'resize', this._onResizeFn);
	},

	getImageElement:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDialogWindow.getImageElement">Gets the reference to html element which shows image in the header.</summary>
		/// <returns domElement="true" mayBeNull="true">Reference to html element or null.</returns>
		return this._getElem(0);
	},
	getCaptionElement:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDialogWindow.getCaptionElement">Gets the reference to html element which shows caption text in the header.</summary>
		/// <returns domElement="true" mayBeNull="true">Reference to html element or null.</returns>
		return this._getElem(1);
	},
	getContentElement:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDialogWindow.getContentElement">Gets the reference to html element which shows content of header.</summary>
		/// <returns domElement="true" mayBeNull="true">Reference to html element or null.</returns>
		return this._getElem(7);
	},
	
	_createObjects:function(objectManager)
	{
		this._objectManager = objectManager;
	},

	dispose:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDialogWindow.dispose">Disposes object and event handlers.</summary>
		if(this._resizeLsnr)
			this._resizeLsnr(false);
		if(this._mover)
			this._mover.dispose();
		$IG.Header.callBaseMethod(this, 'dispose');
		this._mover = null;
	}
}
$IG.Header.registerClass('Infragistics.Web.UI.Header', $IG.UIObject);



$IG.DialogButton = function(obj, element, props, owner, csm, state)
{   
	this._state = state;    
	if(!csm)csm = new $IG.ObjectClientStateManager(props[0]);    
	$IG.DialogButton.initializeBase(this, [obj, element, props, owner, csm]);
	this._control = this._owner._owner;
	if(this._element)
		this._setupImage();   
}

$IG.DialogButton.prototype = 
{
	get_altText:function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.altText">
		/// Gets the alt text of the button.
		///</summary>
		/// <value type="String">Alt text</value>
		var alt = this._get_clientOnlyValue("a");
		return (alt == null)? "" : alt;
	},
	
	get_restoreAltText:function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDialogWindow.restoreAltText">
		/// Gets the restore alt text of the button.
		///</summary>
		/// <value type="String">Alt text for restore state</value>
		var alt = this._get_clientOnlyValue("ra");
		return (alt == null)? "" : alt;
	},
	_setupImage:function()
	{
		var elem = this._element;
		if(elem && elem.nodeName && this._control.get_enabled())
		{
			
			var evts, ie = $util.ieTouchType();
			if (!ie)
			{
				evts = {mousedown:this._onMouseDown, mouseover:this._onMouseOver, mouseout:this._onMouseOut, touchstart:this._onTStart, touchend:this._onTEnd};
				this._mouseUpName = 'mouseup';
			}
			else if (ie == 'pointer')
			{
				evts = {pointerdown:this._onMSStart, pointerup:this._onMSEnd};
				this._mouseUpName = 'pointerup';
				elem.style.touchAction = 'none';
			}
			else
			{
				evts = {MSPointerDown:this._onMSStart, MSPointerUp:this._onMSEnd};
				this._mouseUpName = 'MSPointerUp';
				elem.style.msTouchAction = 'none';
			}
			$addHandlers(elem, evts, this);
			this._onMouseUpFn = Function.createDelegate(this, this._onMouseUp);
			$addHandler(document, this._mouseUpName, this._onMouseUpFn);
		}
	},
	
	_ensureState:function()
	{
		this.setState((this._control.get_windowState() == this._state) ? "r" : $IG.ImageState.Normal);
	},
	_updateState:function(val1, val2)
	{
		var state = (this._control.get_windowState() == this._state);
		this._updateAlt(state);
		this.setState(state ? val2 : val1);
	},
	_updateAlt:function(state)
	{
		if(this._element)
		this._element.alt = state ? this.get_restoreAltText(): this.get_altText();
	},
	
	_changeState:function()
	{ 
		this._control.set_windowState( (this._control.get_windowState() == this._state) ? $IG.DialogWindowState.Normal :this._state, true);
	},  
	
	_onMouseDown:function(e)
	{
		if(e.button == 0)
		{
			$util.cancelEvent(e);
			this._updateState($IG.ImageState.Pressed, "rp");
			 this._mDown = true;
		}
	},
	_onMouseOver:function(e)
	{
		this._updateState($IG.ImageState.Hover, "rh");
	},
	_onMouseOut:function(e)
	{
		this._updateState($IG.ImageState.Normal, "r");
	},
	_onMouseUp:function(e)
	{
		if(!this._mDown)
			return;
		delete this._mDown;
		if(e.button)
			return;
		if(e.target == this._element)
		{
			this._changeState();
			this._updateState($IG.ImageState.Hover, "rh");
		}
		else
			this._updateState($IG.ImageState.Normal, "r");
	},
	_onTStart:function(e)
	{
		e.button = 0;
		this._onMouseOver(e);
		this._onMouseDown(e);
		$util.cancelEvent(e);
	},
	_onTEnd:function(e)
	{
		e.button = 0;
		this._onMouseUp(e);
		this._onMouseOut(e);
	},
	_onMSStart:function(e)
	{
		e.button = 0;
		this._onMouseOver(e);
		this._onMouseDown(e);
		$util.cancelEvent(e);
	},
	_onMSEnd:function(e)
	{
		e.button = 0;
		this._onMouseUp(e);
		this._onMouseOut(e);
	},
	dispose:function()
	{
		if(this._element)
			$clearHandlers(this._element);
		if(this._onMouseUpFn)
			$removeHandler(document, this._mouseUpName, this._onMouseUpFn);
		$IG.DialogButton.callBaseMethod(this, 'dispose');
		this._onMouseUpFn = null;
	}
}
$IG.DialogButton.registerClass('Infragistics.Web.UI.DialogButton', $IG.ImageObject);





$IG.DialogMoveBehavior = function(elem)
{
	/// <summary locid="T:J#Infragistics.Web.UI.DialogMoveBehavior">Class which implements move behavior of WebDialogWindow.</summary>
	/// <param name="elem" domElement="true">Reference to html element.</param>
	$IG.DialogMoveBehavior.initializeBase(this, [elem]);
}

$IG.DialogMoveBehavior.prototype =
{
	
	enabled:true,
	_fixTabOn:false,
	_scrollOn:false,
	_keyOn:false,
	_isModal:false, 
		
	_addHandlers:function()
	{
		this._mouseMoveHandler = Function.createDelegate(this, this._onMouseMove);
		this._mouseUpHandler = Function.createDelegate(this, this._onMouseUp);
		this._mouseOutHandler = Function.createDelegate(this, this._onDocMouseOut);
		var elem = this.get_element();
		
		var evts, ie = $util.ieTouchType();
		if (!ie)
		{
			evts = {mousedown:this._onMouseDown, mouseover:this._onMouseOver, mouseout:this._onMouseOut, touchstart:this._onTStart, touchmove:this._onTMove, touchend:this._onTEnd};
		}
		else if (ie == 'pointer')
		{
			evts = {pointerdown:this._onMSStart, pointermove:this._onMSMove, pointerup:this._onMSEnd};
			this._ie11pointer = true;
			this._pointerUpName = 'pointerup';
			elem.style.touchAction = 'none';
		}
		else
		{
			evts = {MSPointerDown:this._onMSStart, MSPointerMove:this._onMSMove, MSPointerUp:this._onMSEnd};
			this._pointerUpName = 'MSPointerUp';
			elem.style.msTouchAction = 'none';
		}
		$addHandlers(elem, evts, this);
	},

	get_targetElement:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DialogMoveBehavior.targetElement">Gets sets the reference to html element which is used as target.</summary>
		/// <returns domElement="true" mayBeNull="true">Reference to html element.</returns>
		return this._targetElement;
	},
	set_targetElement:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DialogMoveBehavior.targetElement">Sets the reference to html element which is used as target</summary>
		/// <param name="val" domElement="true">Html element</param>
		this._targetElement = val;
	},

	_onMouseOver:function(e)
	{
		if(this.enabled)
			
			this._raiseClientEvent(this._prefix + 'MouseOver', null, e);
	},
	_onMouseOut:function(e)
	{
		if(this.enabled)
			
			this._raiseClientEvent(this._prefix + 'MouseOut', null, e);
	},
	
	_onMouseDown:function(e)
	{
		if(e.button == 0 && this.enabled)
		{
			this._drag = 1;
			var elem = e.target;
			if(elem && !this._pointerUpName && !(elem != this._element && elem != this._img && elem != this._lbl && elem.nodeName != 'TD'))
			{
				e.target.unselectable = 'on';
				$util.cancelEvent(e);
				$addHandler(document, 'mousemove', this._mouseMoveHandler);
				$addHandler(document, 'mouseup', this._mouseUpHandler);
				$addHandler(document, 'mouseout', this._mouseOutHandler);
				this._hasDocE = 1;
			}
		}
		
		this._raiseClientEvent(this._prefix + 'MouseDown', null, e);
	},
	
	_onDocMouseOut:function(e)
	{
		var rect = $util.getWinRect(window);
		var x = e.clientX;
		var y = e.clientY;
		if((x < 0 || y < 0) || x > rect.width || y > rect.height)
			this._onMouseUp(e);
	}, 
	
	
	_onMouseMove:function(e)
	{
		if(!this.enabled || !this._drag) return;
		$util.cancelEvent(e);
		if(this._drag == 2)
		{
			this._moveWindow(e);
			return;
		}
		
		this._drag = 3;
		this.setAbsPos();
		
		this._drag = 2;
		this._mouseX = e.clientX;
		this._mouseY = e.clientY;
	},
	
	
	_onMouseUp:function(e)
	{
		if(!this.enabled || !this._drag) return;
		this._drag = null;
		if(this._hasDocE)
		{
			delete this._hasDocE;
			$removeHandler(document, 'mousemove', this._mouseMoveHandler);
			$removeHandler(document, 'mouseup', this._mouseUpHandler);
			$removeHandler(document, 'mouseout', this._mouseOutHandler);
		}
		
		
		this._raiseClientEvent(this._prefix + 'MouseUp', null, e);
		if (!this._element)
			return;
		
		var v, fix = null, x = this._x, y = this._y;
		
		
		if(x != null && y != null && this._moved)
		{
			this._moved = false;
			var d = this._owner;
			if(d)
				d = d._owner;
			if(d)
				
				d._postAct = 2;
			var args = this._raiseClientEvent('Moved', 'Move', e, null, x, y, this._xOld, this._yOld);
			if (!this._element)
				return;
			if(d)
				
				d._postAct = 0;
			var cancel = args ? args.get_cancel() : false;
			if(cancel)
			{
				fix = x = this._xOld;
				y = this._yOld;
			}
			else if(args)
			{
				if((v = args._x) != null)
					fix = x = v;
				if((v = args._y) != null)
					fix = y = v;
			}
			if(fix == null)
			{
				$util._setMouseBlock();
				return;
			}
			this.setLocation(x.length ? x : x + 'px', y.length ? y : y + 'px', cancel);						
		}
	},
	_onTStart:function(e)
	{
		e.button = 0;
		this._onMouseDown(e);
		$util.cancelEvent(e);
	},
	_onTMove:function(e)
	{
		var t = e.rawEvent.touches;
		if(t && t[0])
		{
			e.clientX = t[0].pageX;
			e.clientY = t[0].pageY;
		}
		e.button = 0;
		this._onMouseMove(e);
		$util.cancelEvent(e);
	},
	_onTEnd:function(e)
	{
		this._onMouseUp(e);
	},
	_onMSStart:function(e)
	{
		var re = e.rawEvent;
		e.button = 0;
		$util.cancelEvent(e);
		var src = this._MSsrc = e.target;
		
		if (this._ie11pointer && src.setPointerCapture)
			src.setPointerCapture(this._MSpointer = re.pointerId);
		else if (src.msSetPointerCapture)
			src.msSetPointerCapture(this._MSpointer = re.pointerId);
		this._MSupHandler = this._MSupHandler || Function.createDelegate(this, this._onMSEnd);
		if (!this._MSupOn)
			$addHandler(document, this._pointerUpName, this._MSupHandler);
		this._MSupOn = true;
		// fake events expected on mousedown to prepare for drag
		this._onMouseDown(e);
	},
	_onMSMove:function(e)
	{
		if(!this._MSpointer)
			return;
		var re = e.rawEvent;
		e.clientX = re.pageX;
		e.clientY = re.pageY;
		$util.cancelEvent(e);
		e.button = 0;
		// fake events expected on mousemove while drag
		this._onMouseMove(e);
	},
	_onMSEnd:function(e)
	{
		var p = this._MSpointer, src = this._MSsrc, re = e.rawEvent;
		if (this._MSupOn)
			$removeHandler(document, this._pointerUpName, this._MSupHandler);
		delete this._MSupOn;
		delete this._MSpointer;
		delete this._MSsrc;
		if(!p)
			return;
		
		if (this._ie11pointer && src.releasePointerCapture)
			src.releasePointerCapture(p);
		else if (src.msReleasePointerCapture)
			src.msReleasePointerCapture(p);
		// fake events expected on mouseup after drag
		this._onMouseUp(e);
	},
	
	
	
	_lsnr:function(scroll, key)
	{
		if(scroll != this._scrollOn)
		{
			this._scrollOn = scroll;
			if(!this._onScrollFn)
			{
				this._onScrollFn = Function.createDelegate(this, this._onScrollSize);
				this._onResizeFn = Function.createDelegate(this, this._onScrollSize);
			}
			if(scroll)
			{
				$addHandler(window, 'scroll', this._onScrollFn);
				$addHandler(window, 'resize', this._onResizeFn);
			}
			else
			{
				$removeHandler(window, 'scroll', this._onScrollFn);
				$removeHandler(window, 'resize', this._onResizeFn);
			}
		}
		if(key == this._keyOn)
			return;
		this._keyOn = key;
		var act = this._noModalTI;
		if(!this._onKeyFn)
		{
			this._onKeyFn = Function.createDelegate(this, this._onKey);
			this._onFocusFn = Function.createDelegate(this, this._onFocus);
			this._onDeactFn = Function.createDelegate(this, this._onDeact);
			if(act)
				this._onActFn = Function.createDelegate(this, this._onAct);
		}
		if(key)
		{
			$addHandler(document, 'keydown', this._onKeyFn);
			$addHandler(document, 'focus', this._onFocusFn);
			$addHandler(document, 'beforedeactivate', this._onDeactFn);
			if(act)
				$addHandler(document, 'beforeactivate', this._onActFn);
		}
		else
		{
			$removeHandler(document, 'keydown', this._onKeyFn);
			$removeHandler(document, 'focus', this._onFocusFn);
			$removeHandler(document, 'beforedeactivate', this._onDeactFn);
			if(act)
				$removeHandler(document, 'beforeactivate', this._onActFn);
		}
	},
	
	
	
	_onScrollSize:function(flag)
	{
		
		if(this._drag)
			return;
		
		var t1 = (new Date()).getTime(), t2 = this._resizeT;
		if (!t2)
			t2 = this._resizeT = t1;
		else if (t1 - t2 < 100)
			return;
		this._resizeT = t1;
		
		if(this._scroll && flag != 2)
			this.setAbsPos(this._xFixed, this._yFixed, this._center, this._scroll, this._isModal, false);
		if($util.IsIE)
		{
			$util._ie_srcl = this;
			window.setTimeout('try{$util._ie_srcl._resizeLid();}catch(i){}', 1);
		}
		else
			this._resizeLid();
	},
	_resizeLid:function()
	{
		$util._ie_srcl = null;
		var style = this._lid ? this._lid.style : this._lidStyle;
		if(!style || style.display == 'none')
			return;
		style.display = 'none';
		var rect = $util.getWinRect();
		style.display = '';
		style.width = Math.max(rect.width + rect.x - 6, rect.maxWidth - 2) + 'px';
		style.height = Math.max(rect.height + rect.y - 6, rect.maxHeight - 2) + 'px';
	},
	
	
	_isChild:function(dad, elem)
	{
		if(!dad || !elem)
			return false;
		if(dad == elem)
			return true;
		var nodes = dad.childNodes;
		if(!nodes)
			return false;
		for(var i = 0; i < nodes.length; i++)
			if(this._isChild(nodes[i], elem))
				return true;
		return false;
	},
	
	
	
	
	_tabFoc:function(e, delay)
	{
		if(e)
			$util.cancelEvent(e);
		
		var elem = this._shiftKey ? this._maxTab2 : this._minTab2;
		
		if(!elem)
			elem = this._shiftKey ? this._maxTabI : this._minTabI;
		
		if(!elem || elem == this._lastTab)
			if((elem = this._anyTab1) == this._lastTab && this._anyTab2)
				elem = this._anyTab2;
		if(!elem)
			return;
		if(delay)
		{
			$util._tab_foc = elem;
			window.setTimeout('try{$util._tab_foc.focus();}catch(i){}',1);
		}
		else
			try{elem.focus();}catch(elem){}
	},
	
	
	_canTab:function(elem)
	{
		if(!elem.getAttribute)
			return false;
		
		var ti = elem.getAttribute('tabIndex');
		if(ti)
			ti = parseInt(ti);
		if(!isNaN(ti) && ti > 0)
			return true;
		for(var i = 0; i < 5; i++)
			if(elem.nodeName == this._tags[i])
				return true;
		return false;
	},
	
	
	_setTabElem:function(elem, foc)
	{
		var tab = this._lastTab;
		
		if((!tab && !foc) || this._lastTabTime + 100 < (new Date()).getTime())
			return;
		
		if(this._isChild(this._targetElement, elem))
			return;
		
		
		
		if(this._shiftKey)
		{
			
			if(!this._minTab2)
				this._minTab2 = tab;
		}
		
		else if(!this._maxTab2)
			
			this._maxTab2 = tab;
		this._tabFoc(null, foc);
	},
	
	
	_onDeact:function(e)
	{
		var to = e ? e.rawEvent : null, tab = this._lastTabTime, last = this._deAct, time = new Date().getTime();
		if(!to || (last && time - last < 50))
			return;
		this._deAct = time;
		if(tab && time - tab < 100 && $util.IsIE9Plus)
			return;
		
		this._setTabElem(to.toElement);//this._setTabElem(to.toElement, e);
	},
	_onAct:function(e)
	{
		var tab = this._lastTabTime, time = new Date().getTime();
		if(!(e = (e && tab && time - tab < 100) ? e.rawEvent : null))
			return;
		var elem = e.target ? e.target : e.srcElement;
		if(!elem)
			return;
		this._setTabElem(elem, true);
	},
	
	
	_onFocus:function(e)
	{
		var elem = (e && !this._deAct) ? e.target : null;
		if(!elem)
			return;
		this._setTabElem(elem, true);
		this._lastTab = null;
	},
	
	
	_onKey:function(e)
	{
		var div = this._targetElement, elem = e ? e.target : null;
		if(!elem || e.keyCode != 9)
			return;
		this._shiftKey = e.shiftKey;
		this._lastTabTime = (new Date()).getTime();
		if(!this._isChild(div, elem))
			return;
		if(!this._canTab(elem))
		{
			this._tabFoc(e);
			return;
		}
		this._lastTab = null;
		if(e.shiftKey)
		{
			
			if(elem == this._minTab2)
			{
				this._tabFoc(e);
				return;
			}
			
			if(this._isChild(div, elem))
				this._lastTab = elem;
		}
		else
		{
			
			if(elem == this._maxTab2)
			{
				this._tabFoc(e);
				return;
			}
			
			if(this._isChild(div, elem))
				this._lastTab = elem;
		}
	},
	
	
	_onFoc:function(e)
	{
		if(this._me)
			this._me._setTabElem();
	},
	
	
	
	_fixTabs:function(on, max)
	{
		var elem, ti, i = -1, stop = this._stop, tabs = this._oldTabs, elem0 = this._targetElement;
		on = on ? true : false;
		if(on == this._fixTabOn)
			return;
		this._fixTabOn = on;
		// get around bugs in IE: modify html by changing text of hidden element
		elem = document.getElementById(ti = '_dw_ie_ti_fix_');
		if (!elem)
		{
			elem = document.createElement('SPAN');
			elem.id = ti;
			elem.style.position = 'absolute';
			elem.style.display = 'none';
			document.body.appendChild(elem);
		}
		elem.innerHTML = elem.innerHTML ? '' : 'hi IE';
		if(!on)
		{
			if(!tabs)
				return;
			while(++i < tabs.length)
			{
				if((ti = tabs[i].i) == null)
					tabs[i].elem.removeAttribute('tabIndex');
				else
					tabs[i].elem.tabIndex = ti;
			}
			if(stop)
				stop.style.display = 'none';
			return;
		}
		if(!tabs)
		{
			tabs = this._oldTabs = new Array();
			this._tags = ['INPUT','SELECT','TEXTAREA','BUTTON','A','IFRAME','AREA','DIV','EMBED','OBJECT'];
		}
		else
			Array.clear(tabs);
		if(!stop && !max)
		{
			this._stop = stop = document.createElement('INPUT');
			stop.alt = 'last';
			var style = stop.style;
			style.padding = style.border = style.width = style.height = '0px';
			style.position = 'absolute';
			stop.tabIndex = 10000;
			elem0.insertBefore(stop, elem0.firstChild);
			stop.onfocus = this._onFoc;
			stop._me = this;
		}
		if(stop)
			stop.style.display = '';
		
		
		var lenAll, lenMy, ti1 = 0, ti2 = 0, j = i = 0, tags = this._tags, doTI = !this._noModalTI;
		
		
		for(var t = 0; t < tags.length; t++)
		{
			var elemsAll = doTI ? document.getElementsByTagName(tags[t]) : [1];
			if((lenAll = elemsAll ? elemsAll.length : 0) < 1)
				continue;
			var elemsMy = this._targetElement.getElementsByTagName(tags[t]);
			lenMy = elemsMy ? elemsMy.length : 0;
			while(lenAll-- > 0)
			{
				elem = elemsAll[lenAll];
				j = lenMy;
				var loop = 1;
				while(j-- > 0 && loop) if((elem = doTI ? elem : elemsMy[j]) == elemsMy[j])
				{
					loop = !doTI;
					if(elem == stop || elem.disabled || elem.type == 'hidden')
						continue;
					
					ti = elem.getAttribute ? elem.getAttribute('tabIndex') : null;
					if(!ti)
						ti = 0;
					else if((ti = parseInt(ti)) < 0)
						continue;
					if(t < 5 || ti > 0)
					{
						
						if(!this._anyTab1)
							this._anyTab1 = elem;
						
						
						else if(!this._anyTab2)
							this._anyTab2 = elem;
						
						if(!this._minTabI)
						{
							this._minTabI = elem;
							ti1 = ti;
						}
						if(ti1 > ti) 
						{
							this._minTabI = elem;
							ti1 = ti;
						}
					}
					if(ti < 1)
						continue;
					
					if(ti >= ti2)
					{
						ti2 = ti;
						this._maxTabI = elem;
					}
				}
				
				if(j < 0 && doTI && elem.getAttribute && (!elemsMy || elemsMy[0] != elem))
				{
					
					ti = elem.getAttribute('tabIndex');
					if(elem.type != 'hidden' && (!ti || parseInt(ti) > -1))
					{
						
						tabs[i++] = {elem:elem,i:ti};
						
						elem.tabIndex = -1;
					}
				}
			}
		}
		
		if(stop && ti2 >= stop.tabIndex)
			stop.tabIndex = ti2 + 1;
	},
	
	_modal:function(on)
	{
		if(!this._isModal)
			return;
		if(this._inModal == on)
			return;
		var style, elem = this._targetElement, lid = this._lid;
		if(!lid)
			lid = $util._modalLid;
		if(this._modalNest(lid, on))
		{
			if($util.IsIE && lid)
				$util._modalLid_me = on ? this : null;
			return;
		}
		var elem2, css = this._owner._owner;
		if(css)
			css = css._modalCss;
		if(on && !lid)
		{
			this._lid = lid = document.createElement($util.IsIE ? 'IFRAME' : 'DIV');
			if(!$util._modalLid)
				$util._modalLid = lid;
			style = lid.style;
			style.position = 'absolute';
			if($util.IsIE)
			{
				lid.textContent = 'Your browser does not support iframes';
				lid.frameBorder = 0;
				lid.scrolling = 'no';
				lid.src = elem2 = 'javascript:"<html></html>"';
			}
			else
				lid.innerHTML = '&nbsp;';
			if(css)
				lid.className = css;
			else
			{
				style.filter = 'alpha(opacity:30)';
				style.opacity = 0.3;
			}
			
			lid.unselectable = 'on';
			lid.tabIndex = -1;			
		}
		this._inModal = on;
		var div = elem.parentNode;
		this._fixTabs(on);
		style = lid.style;
		this._lidStyle = on ? style : null;
		lid._first = on ? this : null;
		if(on)
		{
			div.insertBefore(lid, elem);
			if($util.IsIE)
			{
				
				var doc = lid.contentWindow.document;
				
				if(elem2)
				{
					elem2 = '<div id="_modalLidDiv" tabindex="-1" unselectable="on" style="width:100%;height:100%;';
					if(css)
					{
						div = document.createElement('SPAN');
						div.style.position = 'absolute';
						div.className = css;
						document.body.appendChild(div);
						css = $util.getStyleValue(null, 'backgroundColor', div);
						document.body.removeChild(div);
						elem2 += 'background:'+(css || 'white');
					}
					doc.open();
					doc.write(elem2 + '"></div>');
					doc.close();
					css = doc.body;
					if (css)
						css.topMargin = css.bottomMargin = css.leftMargin = css.rightMargin = '0';
				}
				doc.onmousemove = doc.onmouseup = function()
				{
					var evt = this.parentWindow, me = $util._modalLid_me;
					evt = evt ? evt.event : null;
					if(!me || !evt || !doc)
						return;
					var res = me._control;
					if(res)
						res = res._resizer;
					evt = new Sys.UI.DomEvent(evt);
					if(evt.type == 'mousemove')
					{
						me._onMouseMove(evt);
						if(res)
							res._onMouseMove(evt);
						return;
					}
					me._onMouseUp(evt);
					if(res)
						res._onMouseUp(evt);
				};
			}
			lid._z = this._doZ(lid, elem);
			$util.display(lid);
			var pos = $util.getPosition(lid);
			style.marginLeft = -pos.x + 'px';
			style.marginTop = -pos.y + 'px';
			
			this._onScrollSize(2);
			if(!(div = this._minTabI))
				div = elem;
			if(div.offsetWidth > 1) try
			{
				div.focus();
			}catch(ex){}
		}
		else
		{
			$util.display(lid, false);
			style.marginLeft = style.marginTop = style.width = style.height = '0px';
			div = lid.parentNode;
			if(div)
				div.removeChild(lid);
			elem.style.zIndex = this._oldZ;
		}
		if($util.IsIE)
			$util._modalLid_me = on ? this : null;
	},
	
	
	_doZ:function(lid, elem, lidZ)
	{
		var z = this._newZ = $util.getStyleValue(null, 'zIndex', elem);
		if(this._oldZ == null)
			this._oldZ = z;
		if(!lidZ)
			lidZ = $util.toInt($util.getStyleValue(null, 'zIndex', lid), 0);
		if(lidZ < 10)
			lid.style.zIndex = lidZ = 99999;
		if($util.toInt(z, 0) <= lidZ)
			elem.style.zIndex = this._newZ = lidZ + 1;
		return lidZ;
	},
	
	
	
	
	
	_modalNest:function(lid, on)
	{
		var ctl = lid ? lid._first : null;
		if(!ctl)
			
			return false;
		var nest = lid._nest;
		if(!nest && !on)
			
			return false;
		
		if(!nest)
			lid._nest = nest = [ctl];
		var z, i = nest.length, elem = this._targetElement;
		if(i)
			nest[i - 1]._fixTabs(false);
		if(on)
		{
			
			this._doZ(lid, elem, lid._z);
			
			nest[i--] = this;
			z = this._oldZ;
			
			if($util.IsIE9PlusMode) setTimeout(function()
			{
				if(lid && lid.parentNode && lid.style && lid._nest && lid.style.display != 'none')
				{
					lid.style.display = 'none';
					lid.style.display = '';
				}
			}, 0);
			this._fixTabs(true);
		}
		else
		{
			this._fixTabs(false);
			
			if(--i < 2)
				lid._nest = null;
			
			else
				nest[i] = null;
			
			nest.length = i--;
			z = nest[i]._newZ;
			nest[i]._fixTabs(true);
		}
		this._inModal = on;
		
		elem = nest[i]._targetElement;
		
		elem.style.zIndex = z;
		
		return true;
	},
	
	
	
	
	
	setAbsPos:function(x, y, center, scroll, modal, max)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.DialogMoveBehavior.setAbsPos">Sets location. Internal use only.</summary>
		/// <param name="x" type="String" mayBeNull="true">Left edge in units.</param>
		/// <param name="y" type="String" mayBeNull="true">Top edge in units.</param>
		/// <param name="center" type="Boolean" mayBeNull="true">True: centered.</param>
		/// <param name="scroll" type="Boolean" mayBeNull="true">Request to scroll.</param>
		/// <param name="modal" type="Boolean" mayBeNull="true">Modal dialog.</param>
		/// <param name="max" type="Boolean" mayBeNull="true">Dialog maximized.</param>
		var elem = this._targetElement;
		var style = elem.style;
		this._position0 = style.position;
		if(style.position != 'absolute')
			style.position = 'absolute';
		var point = $util.getPosition(elem);
		
		if(!center && scroll && x === '')
		{
			x = point.x + 'px';
			y = point.y + 'px';
		}
		
		this._xFixed = this._leftOld = x;
		this._yFixed = this._topOld = y;
		
		if(center || scroll || modal)
		{
			this._center = center;
			this._scroll = scroll;
			if(modal)
				this._modal(this._isModal = modal);
			else
				this._fixTabs(max, max);
			this._lsnr(scroll || modal, modal);
		}
		else if(max != null)
			this._fixTabs(max, max);
		var win = $util.getWinRect();
		
		if(this._drag == 3)
			this._win = win;
		if(center || (scroll && x && y))
		{
			var len = (x && !center) ? x.length : 0;
			
			var w = win.width, h = win.height;
			
			if(len > 0)
			{
				var perc = x.indexOf('%') > 0;
				x = parseInt(x);
				
				if(perc)
					x = w * x / 100;
			}
			
			else if((x = (w - elem.offsetWidth) / 2) < 0)
				x = 0;
			len = (y && !center) ? y.length : 0;
			
			if(len > 0)
			{
				var perc = y.indexOf('%') > 0;
				y = parseInt(y);
				
				if(perc)
					y = Math.floor(h * y / 100);
			}
			
			else if((y = (h - elem.offsetHeight) / 2) < 0)
				y = 0;
			
			point.x = Math.floor(win.x + x);
			point.y = Math.floor(win.y + y);
		}
		
		style.left = point.x + 'px';
		style.top = point.y + 'px';
		var p = $util.getPosition(elem);
		
		this._shiftX = p.x - point.x;
		this._shiftY = p.y - point.y;
		this._control.set_left((point.x -= this._shiftX) + 'px', false);
		this._control.set_top((point.y -= this._shiftY) + 'px', false);
		
		this._xOld = point.x;
		this._yOld = point.y;
	},

	restore:function(max)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.DialogMoveBehavior.restore">Restore location. Internal use only.</summary>
		/// <param name="max" type="Boolean">Maximized flag.</param>
		if(this._isModal)
			this._modal(false);
		else
			this._fixTabs(max, max);
		this._lsnr(false, max && this._isModal);
	},

	
	
	
	setLocation:function(x, y, cancel)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.DialogMoveBehavior.setLocation">Sets location. Internal use only.</summary>
		/// <param name="x" type="String">Left edge.</param>
		/// <param name="y" type="String">Top edge.</param>
		/// <param name="cancel" type="Boolean">Request to cancel.</param>
		var style = this._targetElement.style;
		var ctl = this._control;
		style.left = x;
		style.top = y;
		if(ctl && ctl.set_left)
		{
			
			if(cancel)
			{
				x = this._leftOld;
				y = this._topOld;
			}
			
			else if(this._center)
			{
				var win = $util.getWinRect();
				
				x = (parseInt(x) - win.x + this._shiftX) + 'px';
				y = (parseInt(y) - win.y + this._shiftY) + 'px';
			}
			
			ctl.set_left(this._xFixed = x, true);
			ctl.set_top(this._yFixed = y, true);
		}
		if(cancel)
			style.position = this._position0;
	},

	_moveWindow:function(e)
	{
		var x = e.clientX, y = e.clientY;
		if(x < 0 || y < 0)
			return;
		
		var win = $util.getWinRect();
		if(e.target && e.target.id == '_modalLidDiv')
			win.x = win.y = 0;
		x += this._xOld - this._mouseX + win.x - this._win.x;
		y += this._yOld - this._mouseY + win.y - this._win.y;
		
		var args = this._raiseClientEvent('Moving', 'Move', e, null, x, y, this._xOld, this._yOld);
		if (!this._element || (args && args.get_cancel()))
			return;
		this._moved = true;
		$util._setMouseBlock(this._control.get_contentPane()._DIV);
		this._center = false;
		this.setLocation((this._x = x) + 'px', (this._y = y) + 'px');
	},

	dispose:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.DialogMoveBehavior.dispose">Disposes object and event handlers.</summary>
		if(this._lsnr)
		{
			this._lsnr(false, false);
			this._modal(false);
		}
		$util._setMouseBlock();
		$IG.DialogMoveBehavior.callBaseMethod(this, 'dispose');
	}
}
$IG.DialogMoveBehavior.registerClass('Infragistics.Web.UI.DialogMoveBehavior', $IG.Behavior);

$IG.WindowStateCancelEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.WindowStateCancelEventArgs">Class which used while raising events by WebDialogWindow.</summary>
	$IG.WindowStateCancelEventArgs.initializeBase(this);
}
$IG.WindowStateCancelEventArgs.prototype =
{
	get_currentWindowState: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WindowStateCancelEventArgs.currentWindowState">Gets the current window state of the dialog as Number. Value corresponds to WindowState enum on server.</summary>
		/// <value type="Number">One of constants defined in Infragistics.Web.UI.DialogWindowState.</value>
		return this._props[2];
	},
	
	get_newWindowState: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WindowStateCancelEventArgs.newWindowState">Gets the new window state of the dialog as Number. Value corresponds to WindowState enum on server.</summary>
		/// <value type="Number">One of constants defined in Infragistics.Web.UI.DialogWindowState.</value>
		return this._props[3];
	}
}
$IG.WindowStateCancelEventArgs.registerClass('Infragistics.Web.UI.WindowStateCancelEventArgs', $IG.CancelEventArgs);
